#!/usr/bin/env python3
"""
ADVANCED TERMUX AUTOMATION - FIXED VERSION
"""

import requests
import json
import time
import os
from datetime import datetime
from bs4 import BeautifulSoup

class AdvancedAutomation:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36',
        })
        print("🚀 Advanced Automation Started!")
    
    def safe_system_info(self):
        """Safe system information without root access"""
        print("\n💻 SYSTEM INFORMATION")
        print("=" * 40)
        
        try:
            # Current directory info (safe)
            cwd = os.getcwd()
            print(f"📂 Current directory: {cwd}")
            
            # Available disk space in current directory
            statvfs = os.statvfs('.')
            free_gb = (statvfs.f_bavail * statvfs.f_frsize) / (1024 * 1024 * 1024)
            total_gb = (statvfs.f_blocks * statvfs.f_frsize) / (1024 * 1024 * 1024)
            print(f"💽 Disk space: {free_gb:.1f}GB free of {total_gb:.1f}GB")
            
            # Python information
            import sys
            print(f"🐍 Python version: {sys.version.split()[0]}")
            
            # Current time
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"🕐 Current time: {current_time}")
            
        except Exception as e:
            print(f"⚠️  Limited system info available: {e}")
            print("💡 Running in restricted environment")
    
    def web_scraping_demo(self):
        """Demo web scraping with BeautifulSoup"""
        print("\n🌐 WEB SCRAPING DEMO")
        print("=" * 40)
        
        try:
            # Scrape example website
            url = "https://httpbin.org/html"
            response = self.session.get(url)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract information
            title = soup.find('h1')
            paragraphs = soup.find_all('p')
            
            print(f"📄 Page Title: {title.text if title else 'N/A'}")
            print(f"📝 Found {len(paragraphs)} paragraphs")
            
            # Show first paragraph
            if paragraphs:
                first_para = paragraphs[0].get_text()[:100] + "..." if len(paragraphs[0].get_text()) > 100 else paragraphs[0].get_text()
                print(f"📖 Sample: {first_para}")
                
        except Exception as e:
            print(f"❌ Scraping failed: {e}")
    
    def api_automation(self):
        """Advanced API automation"""
        print("\n🔄 API AUTOMATION")
        print("=" * 40)
        
        # Test multiple API endpoints
        endpoints = [
            ("IP Info", "https://httpbin.org/ip"),
            ("User Agent", "https://httpbin.org/user-agent"),
            ("Headers", "https://httpbin.org/headers"),
        ]
        
        for name, url in endpoints:
            try:
                start_time = time.time()
                response = self.session.get(url, timeout=15)
                end_time = time.time()
                response_time = end_time - start_time
                
                if response.status_code == 200:
                    data = response.json()
                    print(f"✅ {name}: Success ({response_time:.2f}s)")
                    # Show a sample of data
                    if name == "IP Info":
                        print(f"   🌐 Your IP: {data.get('origin', 'N/A')}")
                    elif name == "User Agent":
                        print(f"   🤖 Agent: {data.get('user-agent', 'N/A')[:50]}...")
                else:
                    print(f"❌ {name}: Failed - {response.status_code}")
            except Exception as e:
                print(f"❌ {name}: Error - {e}")
    
    def file_management(self):
        """Advanced file management"""
        print("\n💾 FILE MANAGEMENT")
        print("=" * 40)
        
        try:
            # Create project structure
            directories = ['data', 'logs', 'exports', 'backups']
            for directory in directories:
                os.makedirs(directory, exist_ok=True)
                print(f"📁 Created: {directory}/")
            
            # Create sample data files
            sample_data = {
                'project': 'Termux Advanced Automation',
                'created': datetime.now().isoformat(),
                'status': 'active',
                'features': ['web scraping', 'api calls', 'file management', 'safe system info'],
                'environment': 'Termux Android'
            }
            
            # Save as JSON
            with open('data/project_info.json', 'w') as f:
                json.dump(sample_data, f, indent=2)
            print("✅ Saved: data/project_info.json")
            
            # Save as text report
            with open('logs/automation_log.txt', 'w') as f:
                f.write("ADVANCED AUTOMATION LOG\n")
                f.write("=" * 30 + "\n")
                f.write(f"Generated: {datetime.now()}\n")
                f.write(f"Project: {sample_data['project']}\n")
                f.write(f"Features: {', '.join(sample_data['features'])}\n")
                f.write("Status: All tests completed successfully!\n")
            print("✅ Saved: logs/automation_log.txt")
            
            # Count project files
            file_count = 0
            for root, dirs, files in os.walk('.'):
                for file in files:
                    if not file.startswith('.'):  # Skip hidden files
                        file_count += 1
            
            print(f"📋 Total project files: {file_count}")
            
        except Exception as e:
            print(f"❌ File management failed: {e}")
    
    def performance_test(self):
        """Performance testing"""
        print("\n⚡ PERFORMANCE TEST")
        print("=" * 40)
        
        start_time = time.time()
        
        # Test multiple requests (faster endpoints)
        urls = [
            "https://httpbin.org/json",
            "https://httpbin.org/uuid",
            "https://httpbin.org/bytes/1024",  # 1KB of random data
        ]
        
        successful_requests = 0
        for url in urls:
            try:
                response = self.session.get(url, timeout=10)
                if response.status_code == 200:
                    successful_requests += 1
                    print(f"✅ {url.split('/')[-1]}: {response.status_code}")
                else:
                    print(f"❌ {url.split('/')[-1]}: {response.status_code}")
            except Exception as e:
                print(f"❌ {url.split('/')[-1]}: {e}")
        
        end_time = time.time()
        total_time = end_time - start_time
        
        print(f"\n📊 Performance Summary:")
        print(f"   Successful requests: {successful_requests}/{len(urls)}")
        print(f"   Total time: {total_time:.2f} seconds")
        if len(urls) > 0:
            print(f"   Average time per request: {total_time/len(urls):.2f} seconds")
    
    def create_readme(self):
        """Create project README file"""
        print("\n📖 CREATING PROJECT DOCUMENTATION")
        print("=" * 40)
        
        readme_content = "# Termux Automation Project\n\n"
        readme_content += "## Description\n"
        readme_content += "Advanced automation scripts running on Termux (Android)\n\n"
        readme_content += "## Features\n"
        readme_content += "- Web scraping with BeautifulSoup\n"
        readme_content += "- API automation and testing\n"
        readme_content += "- File management\n"
        readme_content += "- Performance monitoring\n\n"
        readme_content += "## Files Created\n"
        readme_content += "- `data/project_info.json` - Project configuration\n"
        readme_content += "- `logs/automation_log.txt` - Execution logs\n"
        readme_content += "- `exports/final_report.json` - Final test report\n\n"
        readme_content += "## Requirements\n"
        readme_content += "- Python 3.x\n"
        readme_content += "- requests\n"
        readme_content += "- beautifulsoup4\n\n"
        readme_content += "## Usage\n"
        readme_content += "```bash\npython demo_automation.py\n```\n\n"
        readme_content += "## Author\n"
        readme_content += "Generated by Termux Automation Bot\n"

        try:
            with open('README.md', 'w') as f:
                f.write(readme_content)
            print("✅ Created: README.md")
        except Exception as e:
            print(f"❌ Failed to create README: {e}")
    
    def run_complete_suite(self):
        """Run all automation tests"""
        print("=" * 60)
        print("🎯 ADVANCED TERMUX AUTOMATION SUITE")
        print("=" * 60)
        
        tests = [
            self.safe_system_info,
            self.web_scraping_demo,
            self.api_automation,
            self.file_management,
            self.performance_test,
            self.create_readme,
        ]
        
        for test in tests:
            test()
            time.sleep(1)  # Brief pause between tests
        
        print("\n" + "=" * 60)
        print("🎉 ALL AUTOMATION TESTS COMPLETED!")
        print("=" * 60)
        
        # Final report
        print("\n📋 CAPABILITIES DEMONSTRATED:")
        print("  ✅ Safe system information")
        print("  ✅ Web scraping with BeautifulSoup")
        print("  ✅ API testing & automation")
        print("  ✅ Advanced file management")
        print("  ✅ Performance testing")
        print("  ✅ Project documentation")
        print("  ✅ Error handling & logging")
        
        print(f"\n🕐 Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def main():
    """Main execution"""
    try:
        # Create automation instance
        automation = AdvancedAutomation()
        
        # Run complete test suite
        automation.run_complete_suite()
        
        # Generate final report
        report_data = {
            'project': 'Advanced Termux Automation',
            'completion_time': datetime.now().isoformat(),
            'status': 'success',
            'environment': 'Termux Android',
            'tests_completed': [
                'safe_system_info',
                'web_scraping', 
                'api_automation',
                'file_management',
                'performance_test',
                'documentation'
            ]
        }
        
        with open('exports/final_report.json', 'w') as f:
            json.dump(report_data, f, indent=2)
        
        print("\n💾 Final report saved: exports/final_report.json")
        print("🚀 Your Termux automation project is ready!")
        print("📁 Project structure created successfully!")
        
    except KeyboardInterrupt:
        print("\n⏹️  Automation stopped by user")
    except Exception as e:
        print(f"💥 Critical error: {e}")

if __name__ == "__main__":
    main()
