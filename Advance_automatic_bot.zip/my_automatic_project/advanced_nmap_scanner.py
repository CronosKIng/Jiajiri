#!/usr/bin/env python3
"""
ADVANCED NMAP SCANNER - FULLY FIXED
Comprehensive network reconnaissance with advanced features
"""

import subprocess
import json
import re
import time
from urllib.parse import urlparse
from datetime import datetime

class AdvancedNmapScanner:
    def __init__(self):
        self.scan_results = {}
        self.target_host = None
        
    def extract_hostname(self, url):
        """Extract hostname from URL - FIXED VERSION"""
        try:
            # Remove protocol if exists
            if '://' in url:
                # Extract hostname from URL
                parsed = urlparse(url)
                hostname = parsed.hostname
                
                # Handle localhost cases
                if hostname in ['localhost', '127.0.0.1', '0.0.0.0']:
                    return '127.0.0.1'
                elif hostname:
                    return hostname
                else:
                    return url.split('://')[1].split('/')[0]
            else:
                # Direct IP/hostname
                return url.split('/')[0]
        except Exception as e:
            print(f"❌ Error extracting hostname from {url}: {e}")
            return '127.0.0.1'  # Fallback to localhost
        
    def comprehensive_scan(self, target_url):
        """Perform comprehensive Nmap scanning with progress tracking"""
        print("🚀 STARTING ADVANCED NMAP SCANNING")
        print("=" * 50)
        
        # Extract hostname from URL
        self.target_host = self.extract_hostname(target_url)
        print(f"🎯 Target: {self.target_host}")
        print(f"🔗 Original URL: {target_url}")
        
        # Define scan sequence with progress weights
        scan_sequence = [
            {'name': 'Host Discovery', 'method': self.host_discovery, 'weight': 10},
            {'name': 'Quick Port Scan', 'method': self.quick_scan, 'weight': 15},
            {'name': 'Full Port Scan', 'method': self.full_port_scan, 'weight': 25},
            {'name': 'Service Detection', 'method': self.service_detection, 'weight': 20},
            {'name': 'OS Fingerprinting', 'method': self.os_detection, 'weight': 10},
            {'name': 'Vulnerability Scan', 'method': self.vulnerability_scan, 'weight': 15},
            {'name': 'SSL Security Scan', 'method': self.ssl_scan, 'weight': 5}
        ]
        
        total_weight = sum(scan['weight'] for scan in scan_sequence)
        current_progress = 0
        
        for scan in scan_sequence:
            print(f"\n🔍 Phase: {scan['name']}")
            print("-" * 30)
            
            try:
                scan['method']()
                current_progress += scan['weight']
                progress_percent = (current_progress / total_weight) * 100
                print(f"📊 Progress: {progress_percent:.1f}%")
                
                time.sleep(1)  # Be polite between scans
            except Exception as e:
                print(f"❌ {scan['name']} failed: {e}")
                continue
        
        return self.generate_scan_report()
    
    def host_discovery(self):
        """Host discovery and availability check"""
        print("🔎 Checking host availability...")
        
        cmd = ['nmap', '-sn', self.target_host]
        result = self.run_nmap_command(cmd, "Host Discovery")
        
        if result:
            is_alive = self.parse_host_status(result['output'])
            self.scan_results['host_discovery'] = result
            self.scan_results['host_status'] = 'Alive' if is_alive else 'Dead'
            print(f"✅ Host status: {'Alive' if is_alive else 'Dead'}")
    
    def quick_scan(self):
        """Quick port scan on common ports"""
        cmd = ['nmap', '-T4', '-F', '--open', self.target_host]
        result = self.run_nmap_command(cmd, "Quick Scan")
        
        if result:
            open_ports = self.parse_open_ports(result['output'])
            self.scan_results['quick_scan'] = result
            self.scan_results['quick_open_ports'] = open_ports
            print(f"✅ Found {len(open_ports)} open ports (quick scan)")
    
    def full_port_scan(self):
        """Comprehensive all-port scanning"""
        print("🔄 Scanning all 65535 ports...")
        
        cmd = ['nmap', '-T4', '-p-', '--open', '--min-rate', '1000', self.target_host]
        result = self.run_nmap_command(cmd, "Full Port Scan", timeout=900)
        
        if result:
            open_ports = self.parse_open_ports(result['output'])
            self.scan_results['full_scan'] = result
            self.scan_results['open_ports'] = open_ports
            print(f"✅ Found {len(open_ports)} open ports (full scan)")
    
    def service_detection(self):
        """Service version detection with scripts"""
        if not self.scan_results.get('open_ports'):
            print("❌ No open ports found for service detection")
            return
        
        ports = ','.join(self.scan_results['open_ports'])
        print(f"🔧 Detecting services on ports: {ports}")
        
        cmd = ['nmap', '-sV', '-sC', '-A', '-p', ports, self.target_host]
        result = self.run_nmap_command(cmd, "Service Detection", timeout=300)
        
        if result:
            services = self.parse_detailed_services(result['output'])
            self.scan_results['services'] = services
            self.scan_results['service_scan'] = result
            print(f"✅ Detected {len(services)} services with versions")
    
    def os_detection(self):
        """Advanced OS fingerprinting"""
        cmd = ['nmap', '-O', '--osscan-guess', '--fuzzy', self.target_host]
        result = self.run_nmap_command(cmd, "OS Detection")
        
        if result:
            os_info = self.parse_os_info(result['output'])
            self.scan_results['os_detection'] = result
            self.scan_results['os_info'] = os_info
            print(f"✅ OS Detection: {os_info}")
    
    def vulnerability_scan(self):
        """Comprehensive vulnerability scanning"""
        print("🛡️ Running vulnerability scripts...")
        
        cmd = [
            'nmap', '--script', 'vuln,safe,auth',
            '--script-args', 'unsafe=1',
            self.target_host
        ]
        result = self.run_nmap_command(cmd, "Vulnerability Scan", timeout=600)
        
        if result:
            vulnerabilities = self.parse_vulnerabilities(result['output'])
            self.scan_results['vulnerability_scan'] = result
            self.scan_results['vulnerabilities'] = vulnerabilities
            print(f"✅ Found {len(vulnerabilities)} potential vulnerabilities")
    
    def ssl_scan(self):
        """SSL/TLS comprehensive security scan"""
        # Check if SSL ports are open
        ssl_ports = ['443', '8443', '993', '995', '465']
        open_ssl_ports = []
        
        if self.scan_results.get('open_ports'):
            open_ssl_ports = [port for port in ssl_ports if port in self.scan_results.get('open_ports', [])]
        
        if not open_ssl_ports:
            print("ℹ️ No SSL ports open")
            return
        
        print(f"🔐 Scanning SSL ports: {', '.join(open_ssl_ports)}")
        
        ports = ','.join(open_ssl_ports)
        cmd = [
            'nmap', '--script', 'ssl-enum-ciphers,ssl-cert,ssl-heartbleed,ssl-poodle,ssl-dh-params',
            '-p', ports, self.target_host
        ]
        result = self.run_nmap_command(cmd, "SSL Security Scan")
        
        if result:
            ssl_info = self.parse_ssl_security(result['output'])
            self.scan_results['ssl_scan'] = result
            self.scan_results['ssl_info'] = ssl_info
            print("✅ SSL/TLS security assessment completed")
    
    def run_nmap_command(self, cmd, scan_name, timeout=300):
        """Execute Nmap command with enhanced error handling"""
        try:
            print(f"🔄 Running: {' '.join(cmd)}")
            start_time = time.time()
            
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                timeout=timeout
            )
            
            duration = time.time() - start_time
            
            return {
                'scan_name': scan_name,
                'command': ' '.join(cmd),
                'output': result.stdout,
                'errors': result.stderr,
                'return_code': result.returncode,
                'duration': f"{duration:.2f}s",
                'timestamp': datetime.now().isoformat()
            }
            
        except subprocess.TimeoutExpired:
            print(f"⏰ {scan_name} timeout after {timeout}s")
            return {
                'scan_name': scan_name,
                'error': f'Timeout after {timeout}s',
                'command': ' '.join(cmd)
            }
        except Exception as e:
            print(f"❌ {scan_name} error: {e}")
            return {
                'scan_name': scan_name,
                'error': str(e),
                'command': ' '.join(cmd)
            }
    
    def parse_host_status(self, nmap_output):
        """Parse host status from Nmap output"""
        return 'Host is up' in nmap_output
    
    def parse_open_ports(self, nmap_output):
        """Parse open ports from Nmap output"""
        open_ports = []
        lines = nmap_output.split('\n')
        
        for line in lines:
            if '/tcp' in line and 'open' in line:
                port_match = re.search(r'(\d+)/tcp', line)
                if port_match:
                    open_ports.append(port_match.group(1))
        
        return sorted(open_ports, key=int)
    
    def parse_detailed_services(self, nmap_output):
        """Parse detailed service information"""
        services = {}
        lines = nmap_output.split('\n')
        current_port = None
        
        for line in lines:
            # Find port lines
            if '/tcp' in line and 'open' in line:
                parts = line.split()
                if len(parts) >= 4:
                    port = parts[0].split('/')[0]
                    service = parts[2] if len(parts) > 2 else 'unknown'
                    version = ' '.join(parts[3:]) if len(parts) > 3 else 'unknown'
                    
                    services[port] = {
                        'service': service,
                        'version': version,
                        'state': 'open',
                        'details': []
                    }
                    current_port = port
            
            # Add service details
            elif current_port and line.strip() and not line.startswith('|'):
                clean_line = line.strip()
                if clean_line and not clean_line.startswith('Nmap scan report'):
                    services[current_port]['details'].append(clean_line)
        
        return services
    
    def parse_os_info(self, nmap_output):
        """Parse detailed OS information"""
        lines = nmap_output.split('\n')
        os_details = []
        
        for line in lines:
            if 'OS details:' in line:
                os_details.append(line.split('OS details:')[-1].strip())
            elif 'Aggressive OS guesses:' in line:
                os_details.append(line.split('Aggressive OS guesses:')[-1].strip())
            elif 'Running:' in line:
                os_details.append(line.split('Running:')[-1].strip())
        
        return ' | '.join(os_details) if os_details else "Unknown OS"
    
    def parse_vulnerabilities(self, nmap_output):
        """Parse vulnerability information with severity"""
        vulnerabilities = []
        lines = nmap_output.split('\n')
        current_vuln = None
        
        for line in lines:
            if 'VULNERABLE:' in line:
                current_vuln = {'type': 'VULNERABLE', 'description': line.strip()}
                vulnerabilities.append(current_vuln)
            elif 'CVE-' in line.upper():
                if current_vuln:
                    current_vuln['cves'] = current_vuln.get('cves', []) + [line.strip()]
                else:
                    vulnerabilities.append({'type': 'CVE', 'description': line.strip()})
            elif 'State:' in line and 'VULNERABLE' in line:
                if current_vuln:
                    current_vuln['state'] = line.strip()
        
        return vulnerabilities
    
    def parse_ssl_security(self, nmap_output):
        """Parse SSL/TLS security information"""
        ssl_info = {}
        lines = nmap_output.split('\n')
        current_port = None
        
        for line in lines:
            # Find SSL service lines
            if 'ssl' in line.lower() and 'open' in line:
                port_match = re.search(r'(\d+)/tcp', line)
                if port_match:
                    current_port = port_match.group(1)
                    ssl_info[current_port] = {'ciphers': [], 'cert_info': []}
            
            # Parse cipher information
            elif current_port and 'TLS_' in line:
                ssl_info[current_port]['ciphers'].append(line.strip())
            
            # Parse certificate information
            elif current_port and 'Subject:' in line:
                ssl_info[current_port]['cert_info'].append(line.strip())
            elif current_port and 'Issuer:' in line:
                ssl_info[current_port]['cert_info'].append(line.strip())
            elif current_port and 'Public Key type:' in line:
                ssl_info[current_port]['cert_info'].append(line.strip())
        
        return ssl_info
    
    def generate_scan_report(self):
        """Generate comprehensive scan report with risk assessment"""
        print("\n📊 Generating Advanced Nmap Scan Report...")
        
        # Risk assessment
        risk_level = self.assess_risk_level()
        
        report = {
            'target': self.target_host,
            'original_url': getattr(self, 'original_target', self.target_host),
            'scan_date': datetime.now().isoformat(),
            'scan_results': self.scan_results,
            'summary': {
                'host_status': self.scan_results.get('host_status', 'Unknown'),
                'open_ports_count': len(self.scan_results.get('open_ports', [])),
                'services_count': len(self.scan_results.get('services', {})),
                'vulnerabilities_count': len(self.scan_results.get('vulnerabilities', [])),
                'os_info': self.scan_results.get('os_info', 'Unknown'),
                'risk_level': risk_level['level'],
                'risk_score': risk_level['score'],
                'recommendations': risk_level['recommendations']
            }
        }
        
        # Save detailed report
        filename = f"advanced_nmap_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"💾 Advanced Nmap report saved: {filename}")
        self.display_comprehensive_summary(report)
        
        return report
    
    def assess_risk_level(self):
        """Assess overall risk level based on scan results"""
        risk_score = 0
        
        # Port exposure scoring
        open_ports = len(self.scan_results.get('open_ports', []))
        if open_ports > 20:
            risk_score += 3
        elif open_ports > 10:
            risk_score += 2
        elif open_ports > 5:
            risk_score += 1
        
        # Vulnerability scoring
        vuln_count = len(self.scan_results.get('vulnerabilities', []))
        risk_score += min(vuln_count, 5)  # Max 5 points for vulnerabilities
        
        # Service risk scoring
        services = self.scan_results.get('services', {})
        high_risk_services = ['ftp', 'telnet', 'rpc', 'netbios', 'smtp']
        for service_info in services.values():
            service_name = service_info.get('service', '').lower()
            if any(risk_service in service_name for risk_service in high_risk_services):
                risk_score += 2
        
        # Determine risk level
        if risk_score >= 8:
            level = "CRITICAL"
            recommendations = [
                "Immediate action required",
                "Close unnecessary ports",
                "Patch vulnerable services",
                "Implement network segmentation"
            ]
        elif risk_score >= 5:
            level = "HIGH" 
            recommendations = [
                "Priority remediation needed",
                "Review open ports",
                "Update service versions",
                "Implement security controls"
            ]
        elif risk_score >= 3:
            level = "MEDIUM"
            recommendations = [
                "Security improvements recommended",
                "Regular vulnerability scanning",
                "Network hardening"
            ]
        else:
            level = "LOW"
            recommendations = [
                "Maintain current security posture",
                "Regular monitoring recommended"
            ]
        
        return {
            'level': level,
            'score': risk_score,
            'recommendations': recommendations
        }
    
    def display_comprehensive_summary(self, report):
        """Display comprehensive scan summary"""
        print("\n" + "=" * 70)
        print("🎯 ADVANCED NMAP SCAN COMPREHENSIVE SUMMARY")
        print("=" * 70)
        print(f"🎯 Target: {report['target']}")
        print(f"🔗 Original: {report['original_url']}")
        print(f"📅 Scan Date: {report['scan_date']}")
        print(f"🖥️ Host Status: {report['summary']['host_status']}")
        print(f"🔓 Open Ports: {report['summary']['open_ports_count']}")
        print(f"🛠️ Services Detected: {report['summary']['services_count']}")
        print(f"⚠️ Vulnerabilities: {report['summary']['vulnerabilities_count']}")
        print(f"💻 OS: {report['summary']['os_info']}")
        print(f"🚨 Risk Level: {report['summary']['risk_level']} (Score: {report['summary']['risk_score']}/10)")
        
        # Display critical findings
        if report['summary']['open_ports_count'] > 0:
            print(f"\n📡 OPEN PORTS:")
            services = self.scan_results.get('services', {})
            for port, info in list(services.items())[:8]:
                service = info.get('service', 'unknown')
                version = info.get('version', 'unknown')
                print(f"   • Port {port}: {service} - {version}")
        
        if report['summary']['vulnerabilities_count'] > 0:
            print(f"\n🚨 TOP VULNERABILITIES:")
            vulnerabilities = self.scan_results.get('vulnerabilities', [])
            for vuln in vulnerabilities[:5]:
                if isinstance(vuln, dict):
                    desc = vuln.get('description', 'Unknown')[:100]
                else:
                    desc = str(vuln)[:100]
                print(f"   • {desc}")
        
        print(f"\n💡 SECURITY RECOMMENDATIONS:")
        for rec in report['summary']['recommendations']:
            print(f"   • {rec}")

def main():
    """Main function for standalone testing"""
    print("🚀 ADVANCED NMAP SCANNER - FULLY FIXED")
    print("=" * 60)
    
    target = input("🎯 Enter target URL or IP: ").strip()
    
    scanner = AdvancedNmapScanner()
    
    try:
        start_time = time.time()
        report = scanner.comprehensive_scan(target)
        duration = time.time() - start_time
        
        print(f"\n⏱️ Total scan duration: {duration:.2f} seconds")
        print("🎉 ADVANCED NMAP SCAN COMPLETED SUCCESSFULLY!")
        
    except KeyboardInterrupt:
        print("\n⏹️ Scan interrupted by user")
    except Exception as e:
        print(f"💥 Scan failed: {e}")

if __name__ == "__main__":
    main()
