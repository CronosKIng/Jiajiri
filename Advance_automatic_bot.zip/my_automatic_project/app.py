#!/usr/bin/env python3
"""
ETHICAL PENETRATION GHOST TESTER PLATFORM - ADVANCED VERSION
Integrated with ALL advanced penetration testing tools
"""

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
import sqlite3
import os
import threading
import json
from datetime import datetime
from urllib.parse import urlparse

# Import ALL your advanced bots
from url_advance_sqlmap_penetration import AdvancedReconBot
from url_only_penetration_test import AutonomousPentestBot
from advance_cracking_login_password import UltimateCredentialCracker
from pdf_report import PDFReportGenerator
from advanced_nmap_scanner import AdvancedNmapScanner
from advanced_login_detector import AdvancedLoginDetector
from advanced_subdomain_enum import AdvancedSubdomainEnum
from advanced_waf_detector import AdvancedWAFDetector

app = Flask(__name__)
app.secret_key = 'ghost_tester_advanced_secret_2024'
app.config['DATABASE'] = 'ghost_tester_advanced.db'

# Initialize database
def init_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  email TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    # Scan results table
    c.execute('''CREATE TABLE IF NOT EXISTS scan_results
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  target_url TEXT NOT NULL,
                  scan_type TEXT NOT NULL,
                  results TEXT,
                  status TEXT DEFAULT 'pending',
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    conn.commit()
    conn.close()

init_db()

# Database helper functions
def get_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row
    return conn

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('signup.html')
        
        # Password strength check (min 6 characters)
        if len(password) < 6:
            flash('Password must be at least 6 characters!', 'error')
            return render_template('signup.html')
        
        conn = get_db()
        try:
            conn.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                        (username, email, password))
            conn.commit()
            flash('Account created successfully! Please login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists!', 'error')
        finally:
            conn.close()
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                           (username, password)).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials!', 'error')
    
    return render_template('login.html')

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        # In a real app, you'd send a password reset email
        flash('If this email exists, a reset link has been sent.', 'info')
        return redirect(url_for('login'))
    
    return render_template('forgot_password.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scans = conn.execute('''
        SELECT * FROM scan_results 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 10
    ''', (session['user_id'],)).fetchall()
    conn.close()
    
    return render_template('dashboard.html', scans=scans, username=session['username'])

@app.route('/start-scan', methods=['POST'])
def start_scan():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    target_url = request.json.get('target_url')
    scan_type = request.json.get('scan_type')
    
    if not target_url:
        return jsonify({'error': 'Target URL required'}), 400
    
    # Save scan to database
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO scan_results (user_id, target_url, scan_type, status)
        VALUES (?, ?, ?, ?)
    ''', (session['user_id'], target_url, scan_type, 'running'))
    scan_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    # Start scan in background thread
    threading.Thread(target=run_advanced_scan, args=(scan_id, target_url, scan_type)).start()
    
    return jsonify({'message': 'Scan started', 'scan_id': scan_id})

def run_advanced_scan(scan_id, target_url, scan_type):
    """Run the actual penetration test with ALL advanced tools"""
    conn = get_db()
    
    try:
        results = {}
        
        if scan_type == 'sql_injection':
            bot = AdvancedReconBot()
            results = bot.automated_sqlmap_attack(target_url)
            
        elif scan_type == 'full_pentest':
            bot = AutonomousPentestBot()
            results = bot.autonomous_pentest(target_url)
            
        elif scan_type == 'credential_cracking':
            bot = UltimateCredentialCracker()
            results = bot.ultimate_credential_attack(target_url)
            
        elif scan_type == 'nmap_scan':
            scanner = AdvancedNmapScanner()
            results = scanner.comprehensive_scan(target_url)
            
        elif scan_type == 'login_detection':
            detector = AdvancedLoginDetector()
            results = detector.comprehensive_login_discovery(target_url)
            
        elif scan_type == 'subdomain_enum':
            enumerator = AdvancedSubdomainEnum()
            results = enumerator.comprehensive_enumeration(target_url)
            
        elif scan_type == 'waf_detection':
            detector = AdvancedWAFDetector()
            results = detector.comprehensive_waf_detection(target_url)
            
        elif scan_type == 'comprehensive_audit':
            # Run multiple scans for comprehensive audit
            comprehensive_results = {}
            
            # Nmap Scan
            nmap_scanner = AdvancedNmapScanner()
            comprehensive_results['nmap'] = nmap_scanner.comprehensive_scan(target_url)
            time.sleep(2)
            
            # Login Detection
            login_detector = AdvancedLoginDetector()
            comprehensive_results['login_detection'] = login_detector.comprehensive_login_discovery(target_url)
            time.sleep(2)
            
            # WAF Detection
            waf_detector = AdvancedWAFDetector()
            comprehensive_results['waf_detection'] = waf_detector.comprehensive_waf_detection(target_url)
            time.sleep(2)
            
            # Subdomain Enumeration
            sub_enum = AdvancedSubdomainEnum()
            comprehensive_results['subdomain_enum'] = sub_enum.comprehensive_enumeration(target_url)
            
            results = comprehensive_results
            
        else:
            results = {'error': 'Unknown scan type'}
        
        # Update database with results
        conn.execute('''
            UPDATE scan_results 
            SET results = ?, status = ? 
            WHERE id = ?
        ''', (json.dumps(results), 'completed', scan_id))
        
    except Exception as e:
        conn.execute('''
            UPDATE scan_results 
            SET results = ?, status = ? 
            WHERE id = ?
        ''', (json.dumps({'error': str(e)}), 'failed', scan_id))
    
    conn.commit()
    conn.close()

@app.route('/scan-results/<int:scan_id>')
def scan_results(scan_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scan = conn.execute('''
        SELECT * FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        flash('Scan not found!', 'error')
        return redirect(url_for('dashboard'))
    
    results = json.loads(scan['results']) if scan['results'] else {}
    return render_template('scan_results.html', scan=scan, results=results)

# PDF Download Route
@app.route('/download-pdf/<int:scan_id>')
def download_pdf(scan_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scan = conn.execute('''
        SELECT * FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        flash('Scan not found!', 'error')
        return redirect(url_for('dashboard'))
    
    results = json.loads(scan['results']) if scan['results'] else {}
    
    # Generate PDF
    pdf_gen = PDFReportGenerator()
    filename = f"ghost_tester_report_{scan_id}.pdf"
    filepath = os.path.join('exports', filename)
    
    # Create exports directory if not exists
    os.makedirs('exports', exist_ok=True)
    
    try:
        pdf_gen.generate_scan_report(dict(scan), results, filepath)
        
        # Return PDF file for download
        return send_file(filepath, as_attachment=True, download_name=filename)
        
    except Exception as e:
        flash(f'Error generating PDF: {e}', 'error')
        return redirect(url_for('scan_results', scan_id=scan_id))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'info')
    return redirect(url_for('index'))

# API endpoint to get scan status
@app.route('/api/scan-status/<int:scan_id>')
def scan_status(scan_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    conn = get_db()
    scan = conn.execute('''
        SELECT id, status, target_url, scan_type, created_at 
        FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    
    return jsonify(dict(scan))

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('exports', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    os.makedirs('backups', exist_ok=True)
    
    print("🚀 GHOST TESTER ADVANCED PLATFORM STARTING...")
    print("🔧 Integrated Tools:")
    print("   ✅ SQL Injection Scanner")
    print("   ✅ Full Penetration Testing")
    print("   ✅ Credential Cracking")
    print("   ✅ Advanced Nmap Scanning")
    print("   ✅ Login Parameter Detection")
    print("   ✅ Subdomain Enumeration")
    print("   ✅ WAF Detection")
    print("   ✅ Comprehensive Security Audit")
    print("🌍 Server running on http://127.0.0.1:5000")
    
    app.run(host='127.0.0.1', port=5000, debug=True)
