#!/usr/bin/env python3
"""
ADVANCED WAF DETECTION
Detect and fingerprint Web Application Firewalls
"""

import requests
import json
import time
from datetime import datetime

class AdvancedWAFDetector:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36',
        })
        self.waf_signatures = {
            'Cloudflare': {
                'headers': ['server', 'cf-ray'],
                'cookies': ['__cfduid', '__cflb'],
                'patterns': ['cloudflare', 'cf-ray']
            },
            'Akamai': {
                'headers': ['server', 'x-akamai-transformed'],
                'patterns': ['akamai']
            },
            'Imperva': {
                'headers': ['x-cdn', 'server'],
                'cookies': ['incap_ses_', 'visid_incap_'],
                'patterns': ['incapsula']
            },
            'AWS WAF': {
                'headers': ['x-amz-id-2', 'x-amz-request-id'],
                'patterns': ['aws', 'amazon']
            },
            'ModSecurity': {
                'headers': ['server'],
                'patterns': ['mod_security', 'modsecurity']
            },
            'Sucuri': {
                'headers': ['server', 'x-sucuri-id'],
                'patterns': ['sucuri']
            },
            'FortiWeb': {
                'headers': ['server'],
                'patterns': ['fortiweb']
            },
            'F5 BIG-IP': {
                'headers': ['server', 'x-wa-info'],
                'patterns': ['bigip', 'f5']
            }
        }
        
    def comprehensive_waf_detection(self, target_url):
        """Perform comprehensive WAF detection"""
        print("🚀 STARTING ADVANCED WAF DETECTION")
        print("=" * 50)
        print(f"🎯 Target: {target_url}")
        
        detection_methods = [
            self.passive_detection,
            self.active_detection,
            self.payload_testing,
            self.fingerprint_analysis
        ]
        
        waf_findings = {}
        
        for method in detection_methods:
            try:
                findings = method(target_url)
                waf_findings.update(findings)
                time.sleep(1)
            except Exception as e:
                print(f"❌ {method.__name__} failed: {e}")
                continue
        
        return self.generate_waf_report(target_url, waf_findings)
    
    def passive_detection(self, target_url):
        """Passive WAF detection through headers"""
        print("\n🔍 Phase 1: Passive Header Analysis")
        print("-" * 40)
        
        findings = {}
        
        try:
            response = self.session.get(target_url, timeout=10)
            headers = dict(response.headers)
            
            print("📋 Response Headers Analysis:")
            for header, value in headers.items():
                print(f"   {header}: {value}")
                
                # Check for WAF signatures in headers
                for waf_name, signatures in self.waf_signatures.items():
                    if self.check_header_signatures(header, value, signatures):
                        findings[waf_name] = {
                            'detection_method': 'header_analysis',
                            'confidence': 'HIGH',
                            'evidence': f"{header}: {value}"
                        }
                        print(f"✅ WAF Detected: {waf_name} (Header: {header})")
            
            # Check server header specifically
            server_header = headers.get('server', '').lower()
            for waf_name, signatures in self.waf_signatures.items():
                if any(pattern in server_header for pattern in signatures.get('patterns', [])):
                    findings[waf_name] = {
                        'detection_method': 'server_header',
                        'confidence': 'HIGH',
                        'evidence': f"Server: {headers.get('server')}"
                    }
                    print(f"✅ WAF Detected: {waf_name} (Server Header)")
        
        except Exception as e:
            print(f"❌ Passive detection error: {e}")
        
        return findings
    
    def check_header_signatures(self, header, value, signatures):
        """Check if header matches WAF signatures"""
        header_lower = header.lower()
        value_lower = str(value).lower()
        
        # Check header names
        if any(sig_header in header_lower for sig_header in signatures.get('headers', [])):
            return True
        
        # Check header values
        if any(pattern in value_lower for pattern in signatures.get('patterns', [])):
            return True
        
        return False
    
    def active_detection(self, target_url):
        """Active WAF detection through probing"""
        print("\n🔍 Phase 2: Active Probing")
        print("-" * 40)
        
        findings = {}
        
        # Test various malicious payloads
        test_payloads = [
            "../../etc/passwd",
            "<script>alert('XSS')</script>",
            "' OR '1'='1",
            "../../windows/win.ini",
            "union select 1,2,3,4,5"
        ]
        
        for payload in test_payloads:
            try:
                test_url = f"{target_url}?test={payload}"
                response = self.session.get(test_url, timeout=5)
                
                # Analyze response for WAF blocks
                if self.is_waf_block(response):
                    waf_type = self.identify_waf_by_block(response)
                    if waf_type:
                        findings[waf_type] = {
                            'detection_method': 'active_probing',
                            'confidence': 'MEDIUM',
                            'evidence': f"Blocked payload: {payload}",
                            'response_code': response.status_code
                        }
                        print(f"✅ WAF Block Detected: {waf_type} (Payload: {payload})")
                
            except Exception as e:
                continue
        
        return findings
    
    def is_waf_block(self, response):
        """Check if response indicates WAF block"""
        block_indicators = [
            response.status_code in [403, 406, 419, 429, 500, 501, 502, 503],
            'blocked' in response.text.lower(),
            'forbidden' in response.text.lower(),
            'access denied' in response.text.lower(),
            'waf' in response.text.lower(),
            'security' in response.text.lower()
        ]
        
        return any(block_indicators)
    
    def identify_waf_by_block(self, response):
        """Identify WAF by block page characteristics"""
        text_lower = response.text.lower()
        headers_lower = {k.lower(): v.lower() for k, v in response.headers.items()}
        
        if 'cloudflare' in text_lower or 'cf-ray' in headers_lower:
            return 'Cloudflare'
        elif 'akamai' in text_lower:
            return 'Akamai'
        elif 'incapsula' in text_lower:
            return 'Imperva'
        elif 'aws' in text_lower or 'amazon' in text_lower:
            return 'AWS WAF'
        elif 'sucuri' in text_lower:
            return 'Sucuri'
        elif 'fortiweb' in text_lower:
            return 'FortiWeb'
        elif 'bigip' in text_lower or 'f5' in text_lower:
            return 'F5 BIG-IP'
        
        return None
    
    def payload_testing(self, target_url):
        """Advanced payload testing for WAF detection"""
        print("\n🔍 Phase 3: Advanced Payload Testing")
        print("-" * 40)
        
        findings = {}
        
        # SQL Injection payloads
        sql_payloads = [
            "' OR '1'='1'--",
            "'; DROP TABLE users--",
            "UNION SELECT 1,2,3,4,5--",
            "'; EXEC xp_cmdshell('dir')--"
        ]
        
        for payload in sql_payloads:
            try:
                test_url = f"{target_url}?id={payload}"
                response = self.session.post(target_url, data={'input': payload}, timeout=5)
                
                if response.status_code != 200:
                    print(f"🚫 Payload blocked: {payload[:50]}...")
                    findings['Generic WAF'] = {
                        'detection_method': 'sql_injection_test',
                        'confidence': 'MEDIUM',
                        'evidence': f"Blocked SQLi: {payload}"
                    }
                
            except Exception as e:
                continue
        
        return findings
    
    def fingerprint_analysis(self, target_url):
        """Fingerprint WAF based on timing and behavior"""
        print("\n🔍 Phase 4: Behavioral Fingerprinting")
        print("-" * 40)
        
        findings = {}
        
        # Test response timing for WAF processing
        try:
            start_time = time.time()
            response = self.session.get(target_url, timeout=10)
            normal_time = time.time() - start_time
            
            # Test with malicious payload
            start_time = time.time()
            malicious_response = self.session.get(f"{target_url}?test=<script>alert(1)</script>", timeout=10)
            malicious_time = time.time() - start_time
            
            # If malicious request takes significantly longer, possible WAF
            if malicious_time > normal_time * 2:
                findings['Behavioral WAF'] = {
                    'detection_method': 'timing_analysis',
                    'confidence': 'LOW',
                    'evidence': f"Delay detected: {malicious_time:.2f}s vs {normal_time:.2f}s",
                    'normal_response_time': normal_time,
                    'malicious_response_time': malicious_time
                }
                print(f"⏱️ Timing anomaly detected: Possible WAF")
        
        except Exception as e:
            print(f"❌ Fingerprinting error: {e}")
        
        return findings
    
    def generate_waf_report(self, target_url, findings):
        """Generate comprehensive WAF detection report"""
        print("\n📊 Generating WAF Detection Report...")
        
        report = {
            'target_url': target_url,
            'scan_date': datetime.now().isoformat(),
            'waf_detected': len(findings) > 0,
            'detected_wafs': findings,
            'security_implications': self.assess_security_implications(findings)
        }
        
        # Save report
        filename = f"waf_detection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"💾 WAF detection report saved: {filename}")
        self.display_waf_summary(report)
        
        return report
    
    def assess_security_implications(self, findings):
        """Assess security implications of detected WAFs"""
        implications = []
        
        if findings:
            implications.append("✅ Web Application Firewall detected - Enhanced security")
            implications.append("🔒 Additional layer of protection against common attacks")
            implications.append("⚠️ May require advanced techniques for penetration testing")
        else:
            implications.append("❌ No WAF detected - Potential security risk")
            implications.append("🔓 Application may be vulnerable to common web attacks")
            implications.append("💡 Consider implementing WAF for better security")
        
        return implications
    
    def display_waf_summary(self, report):
        """Display WAF detection summary"""
        print("\n" + "=" * 60)
        print("🎯 ADVANCED WAF DETECTION SUMMARY")
        print("=" * 60)
        print(f"🎯 Target: {report['target_url']}")
        print(f"📅 Scan Date: {report['scan_date']}")
        print(f"🛡️ WAF Detected: {'YES' if report['waf_detected'] else 'NO'}")
        
        if report['waf_detected']:
            print(f"\n🔍 DETECTED WAFs:")
            for waf_name, details in report['detected_wafs'].items():
                confidence = details.get('confidence', 'UNKNOWN')
                method = details.get('detection_method', 'UNKNOWN')
                print(f"   • {waf_name} (Confidence: {confidence}, Method: {method})")
        
        print(f"\n💡 SECURITY IMPLICATIONS:")
        for implication in report['security_implications']:
            print(f"   • {implication}")

def main():
    """Main function for standalone testing"""
    print("🚀 ADVANCED WAF DETECTOR")
    print("=" * 50)
    
    target = input("🎯 Enter target URL: ").strip()
    
    if not target.startswith(('http://', 'https://')):
        target = 'http://' + target
    
    detector = AdvancedWAFDetector()
    
    try:
        start_time = time.time()
        report = detector.comprehensive_waf_detection(target)
        duration = time.time() - start_time
        
        print(f"\n⏱️ Detection duration: {duration:.2f} seconds")
        print("🎉 WAF DETECTION COMPLETED!")
        
    except KeyboardInterrupt:
        print("\n⏹️ Detection interrupted by user")
    except Exception as e:
        print(f"💥 Detection failed: {e}")

if __name__ == "__main__":
    main()
