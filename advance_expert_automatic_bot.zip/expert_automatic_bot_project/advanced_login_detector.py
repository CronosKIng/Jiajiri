#!/usr/bin/env python3
"""
ADVANCED LOGIN PARAMETER DETECTOR - FULLY FIXED
Inapata parameters zote za login kwenye mfumo wowote kwa njia za hali ya juu
Bila kutumia lxml - inafanya kazi kikamilifu kwenye Termux
"""

import requests
import re
import json
import time
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, parse_qs
from datetime import datetime
import threading
from concurrent.futures import ThreadPoolExecutor

class AdvancedLoginDetector:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36',
        })
        self.discovered_parameters = {}
        self.login_endpoints = []
        self.all_forms_data = []
        
    def comprehensive_login_discovery(self, target_url):
        """Comprehensive login parameter discovery"""
        print("🚀 STARTING ADVANCED LOGIN PARAMETER DISCOVERY")
        print("=" * 60)
        print(f"🎯 Target: {target_url}")
        
        discovery_methods = [
            self.html_form_analysis,
            self.javascript_analysis,
            self.api_endpoint_discovery,
            self.common_login_paths,
            self.parameter_bruteforce,
            self.redirect_analysis,
            self.session_analysis
        ]
        
        for method in discovery_methods:
            try:
                method(target_url)
                time.sleep(1)
            except Exception as e:
                print(f"❌ {method.__name__} failed: {e}")
                continue
        
        return self.generate_login_report(target_url)
    
    def html_form_analysis(self, target_url):
        """Advanced HTML form analysis - FIXED VERSION"""
        print("\n🔍 Phase 1: Advanced HTML Form Analysis")
        print("-" * 40)
        
        try:
            response = self.session.get(target_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Analyze all forms
            forms = soup.find_all('form')
            print(f"📝 Found {len(forms)} forms")
            
            for i, form in enumerate(forms):
                form_data = self.analyze_form_structure(form, target_url)
                if form_data and form_data['parameters']:
                    form_id = f"form_{i+1}"
                    self.discovered_parameters[form_id] = form_data
                    self.all_forms_data.append(form_data)
                    print(f"✅ Form {i+1}: {len(form_data['parameters'])} parameters")
                    
                    # Display form details immediately
                    print(f"   📋 Action: {form_data['action']}")
                    print(f"   📝 Method: {form_data['method']}")
                    for param in form_data['parameters']:
                        if param['login_confidence'] == 'HIGH':
                            print(f"   🔑 Login Field: {param['name']} ({param['type']})")
        
        except Exception as e:
            print(f"❌ HTML form analysis error: {e}")
    
    def analyze_form_structure(self, form, base_url):
        """Analyze form structure in detail - FIXED VERSION"""
        form_action = form.get('action', '')
        form_method = form.get('method', 'get').upper()
        
        form_info = {
            'action': form_action,
            'method': form_method,
            'full_url': urljoin(base_url, form_action),
            'parameters': [],
            'login_indicators': [],
            'is_login_form': False
        }
        
        # Extract all input fields
        inputs = form.find_all('input')
        textareas = form.find_all('textarea')
        selects = form.find_all('select')
        
        # Process input fields
        for inp in inputs:
            param_info = {
                'name': inp.get('name', ''),
                'type': inp.get('type', 'text'),
                'value': inp.get('value', ''),
                'placeholder': inp.get('placeholder', ''),
                'id': inp.get('id', ''),
                'class': ' '.join(inp.get('class', [])),
                'login_confidence': 'LOW'
            }
            
            # Detect login-related parameters
            if self.is_login_parameter(param_info):
                param_info['login_confidence'] = 'HIGH'
                form_info['login_indicators'].append(param_info['name'])
            
            form_info['parameters'].append(param_info)
        
        # Process textareas
        for textarea in textareas:
            param_info = {
                'name': textarea.get('name', ''),
                'type': 'textarea',
                'value': textarea.get_text(strip=True),
                'placeholder': textarea.get('placeholder', ''),
                'id': textarea.get('id', ''),
                'class': ' '.join(textarea.get('class', [])),
                'login_confidence': 'LOW'
            }
            
            if self.is_login_parameter(param_info):
                param_info['login_confidence'] = 'HIGH'
                form_info['login_indicators'].append(param_info['name'])
            
            form_info['parameters'].append(param_info)
        
        # Process select fields
        for select in selects:
            param_info = {
                'name': select.get('name', ''),
                'type': 'select',
                'value': '',
                'options': [option.get('value', '') for option in select.find_all('option')],
                'id': select.get('id', ''),
                'class': ' '.join(select.get('class', [])),
                'login_confidence': 'LOW'
            }
            
            if self.is_login_parameter(param_info):
                param_info['login_confidence'] = 'HIGH'
                form_info['login_indicators'].append(param_info['name'])
            
            form_info['parameters'].append(param_info)
        
        # Check if this is likely a login form
        form_info['is_login_form'] = self.detect_login_form(form_info)
        
        return form_info
    
    def is_login_parameter(self, param_info):
        """Determine if parameter is login-related - ENHANCED"""
        login_keywords = [
            'user', 'pass', 'login', 'auth', 'email', 'username', 
            'password', 'pwd', 'secret', 'key', 'token', 'code',
            'pin', 'credential', 'signin', 'sign-in', 'captcha',
            'recaptcha', 'security', 'verify', 'authentication'
        ]
        
        param_name = param_info['name'].lower()
        param_type = param_info['type'].lower()
        param_placeholder = param_info['placeholder'].lower()
        
        # Check parameter name
        if any(keyword in param_name for keyword in login_keywords):
            return True
        
        # Check placeholder text
        if any(keyword in param_placeholder for keyword in login_keywords):
            return True
        
        # Check input type
        if param_type == 'password':
            return True
        
        # Check for email fields
        if param_type == 'email':
            return True
        
        return False
    
    def detect_login_form(self, form_info):
        """Detect if form is a login form - ENHANCED"""
        score = 0
        
        # Check for password fields
        password_fields = [p for p in form_info['parameters'] if p['type'] == 'password']
        if password_fields:
            score += 3
        
        # Check for username/email fields
        username_fields = [p for p in form_info['parameters'] 
                          if any(keyword in p['name'].lower() for keyword in ['user', 'email'])]
        if username_fields:
            score += 2
        
        # Check for high confidence login parameters
        high_confidence_params = [p for p in form_info['parameters'] if p['login_confidence'] == 'HIGH']
        if len(high_confidence_params) >= 2:
            score += 2
        
        # Check form action for login indicators
        action = form_info['action'].lower()
        login_indicators = ['login', 'auth', 'signin', 'authenticate', 'verify']
        if any(indicator in action for indicator in login_indicators):
            score += 2
        
        return score >= 4  # Higher threshold for better accuracy
    
    def javascript_analysis(self, target_url):
        """Analyze JavaScript for login endpoints - FIXED"""
        print("\n🔍 Phase 2: JavaScript Endpoint Analysis")
        print("-" * 40)
        
        try:
            response = self.session.get(target_url, timeout=10)
            
            # Find JavaScript files
            soup = BeautifulSoup(response.text, 'html.parser')
            script_tags = soup.find_all('script')
            
            js_endpoints = []
            inline_js = []
            
            for script in script_tags:
                # External JS files
                if script.get('src'):
                    js_url = urljoin(target_url, script['src'])
                    js_endpoints.append(js_url)
                    print(f"📜 Found JS: {js_url}")
                
                # Inline JavaScript
                if script.string:
                    inline_js.append(script.string)
            
            # Analyze inline JavaScript for endpoints
            for js_content in inline_js[:3]:  # Limit to first 3 inline scripts
                self.extract_js_endpoints(js_content, target_url)
            
            # Analyze external JavaScript files
            for js_url in js_endpoints[:2]:  # Limit analysis to 2 external scripts
                try:
                    js_response = self.session.get(js_url, timeout=10)
                    self.extract_js_endpoints(js_response.text, target_url)
                except:
                    continue
                    
        except Exception as e:
            print(f"❌ JS analysis error: {e}")
    
    def extract_js_endpoints(self, js_content, base_url):
        """Extract API endpoints from JavaScript code - ENHANCED"""
        if not js_content:
            return
            
        # Patterns for common API endpoints
        patterns = [
            r'[\'"](\/api\/[^\'"]*login[^\'"]*)[\'"]',
            r'[\'"](\/auth\/[^\'"]*)[\'"]',
            r'[\'"](\/login[^\'"]*)[\'"]',
            r'[\'"](\/signin[^\'"]*)[\'"]',
            r'[\'"](\/authenticate[^\'"]*)[\'"]',
            r'[\'"](\/verify[^\'"]*)[\'"]',
            r'[\'"](\/oauth[^\'"]*)[\'"]',
            r'[\'"](\/token[^\'"]*)[\'"]',
            r'url:\s*[\'"]([^\'"]*login[^\'"]*)[\'"]',
            r'endpoint:\s*[\'"]([^\'"]*auth[^\'"]*)[\'"]',
            r'fetch\([\'"]([^\'"]*login[^\'"]*)[\'"]',
            r'ajax\([^)]*url:\s*[\'"]([^\'"]*auth[^\'"]*)[\'"]'
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, js_content, re.IGNORECASE)
            for match in matches:
                full_url = urljoin(base_url, match)
                if full_url not in self.login_endpoints:
                    self.login_endpoints.append(full_url)
                    print(f"✅ JS API Endpoint: {full_url}")
    
    def api_endpoint_discovery(self, target_url):
        """Discover API login endpoints - ENHANCED"""
        print("\n🔍 Phase 3: API Endpoint Discovery")
        print("-" * 40)
        
        common_api_paths = [
            '/api/login', '/api/auth', '/api/authenticate', '/api/verify',
            '/auth/login', '/auth/signin', '/oauth/token', '/oauth/authorize',
            '/rest/auth', '/graphql', '/api/v1/login', '/api/v2/auth',
            '/json/auth', '/xml/login', '/api/user/login', '/api/account/signin',
            '/admin/login', '/user/auth', '/member/login', '/account/login'
        ]
        
        discovered_apis = []
        
        for path in common_api_paths:
            api_url = urljoin(target_url, path)
            try:
                # Try GET request
                response = self.session.get(api_url, timeout=5)
                if response.status_code != 404:
                    discovered_apis.append({
                        'url': api_url,
                        'method': 'GET',
                        'status': response.status_code,
                        'content_type': response.headers.get('content-type', '')
                    })
                    print(f"✅ API Endpoint: {api_url} (GET - {response.status_code})")
                
                # Try POST request
                response_post = self.session.post(api_url, timeout=5)
                if response_post.status_code != 404 and response_post.status_code != response.status_code:
                    discovered_apis.append({
                        'url': api_url,
                        'method': 'POST', 
                        'status': response_post.status_code,
                        'content_type': response_post.headers.get('content-type', '')
                    })
                    print(f"✅ API Endpoint: {api_url} (POST - {response_post.status_code})")
                    
            except:
                continue
        
        self.discovered_parameters['api_endpoints'] = discovered_apis
    
    def common_login_paths(self, target_url):
        """Check common login page paths - ENHANCED"""
        print("\n🔍 Phase 4: Common Login Paths")
        print("-" * 40)
        
        common_paths = [
            '/login', '/signin', '/auth', '/authenticate', '/verify',
            '/admin', '/administrator', '/wp-login.php', '/user/login',
            '/account/signin', '/member/login', '/secure/auth', '/portal/login',
            '/dashboard', '/console', '/manager/html', '/phpmyadmin',
            '/cpanel', '/webmail', '/admin.php', '/login.php'
        ]
        
        discovered_logins = []
        
        for path in common_paths:
            login_url = urljoin(target_url, path)
            try:
                response = self.session.get(login_url, timeout=5)
                if response.status_code == 200:
                    # Check if page contains login indicators
                    login_score = self.analyze_login_page(response.text)
                    if login_score >= 2:  # At least 2 login indicators
                        discovered_logins.append({
                            'url': login_url,
                            'status': response.status_code,
                            'title': self.extract_page_title(response.text),
                            'login_score': login_score
                        })
                        print(f"✅ Login Page: {login_url} (Score: {login_score})")
            except:
                continue
        
        self.discovered_parameters['login_pages'] = discovered_logins
    
    def analyze_login_page(self, html_content):
        """Analyze page for login form indicators - ENHANCED"""
        score = 0
        content_lower = html_content.lower()
        
        login_indicators = [
            'password', 'login', 'sign in', 'username', 'email',
            'user', 'pass', 'pwd', 'auth', 'authenticate', 'verify',
            'captcha', 'recaptcha', 'credentials', 'log in'
        ]
        
        for indicator in login_indicators:
            if indicator in content_lower:
                score += 1
        
        # Check for form elements
        if '<form' in html_content and 'password' in content_lower:
            score += 2
        
        return score
    
    def extract_page_title(self, html_content):
        """Extract page title from HTML"""
        soup = BeautifulSoup(html_content, 'html.parser')
        title_tag = soup.find('title')
        return title_tag.text.strip() if title_tag else 'No Title'
    
    def parameter_bruteforce(self, target_url):
        """Bruteforce parameter discovery - ENHANCED"""
        print("\n🔍 Phase 5: Parameter Bruteforce")
        print("-" * 40)
        
        common_parameters = [
            'username', 'user', 'email', 'login', 'auth_user',
            'password', 'pass', 'pwd', 'auth_password', 'passwd',
            'token', 'csrf', 'csrf_token', '_token', 'authenticity_token',
            'remember', 'remember_me', 'stay_signed_in', 'captcha',
            'recaptcha', 'g-recaptcha-response', 'security_code',
            'redirect', 'return_url', 'next', 'callback', 'continue'
        ]
        
        discovered_params = []
        
        # Test parameters in URL
        for param in common_parameters:
            test_url = f"{target_url}?{param}=test"
            try:
                response = self.session.get(test_url, timeout=5)
                # If parameter is reflected in response or doesn't cause error
                if response.status_code == 200 and param in response.text:
                    discovered_params.append({
                        'parameter': param,
                        'type': 'GET',
                        'reflected': True
                    })
                    print(f"✅ Parameter: {param} (GET - Reflected)")
                elif response.status_code == 200:
                    discovered_params.append({
                        'parameter': param, 
                        'type': 'GET',
                        'reflected': False
                    })
                    print(f"✅ Parameter: {param} (GET)")
            except:
                continue
        
        self.discovered_parameters['bruteforced_params'] = discovered_params
    
    def redirect_analysis(self, target_url):
        """Analyze redirect behavior for login - ENHANCED"""
        print("\n🔍 Phase 6: Redirect Analysis")
        print("-" * 40)
        
        test_paths = ['/admin', '/dashboard', '/profile', '/settings', '/account']
        redirect_findings = []
        
        for path in test_paths:
            test_url = urljoin(target_url, path)
            try:
                response = self.session.get(test_url, timeout=5, allow_redirects=False)
                if response.status_code in [301, 302, 303, 307, 308]:
                    redirect_url = response.headers.get('Location', '')
                    redirect_info = {
                        'protected_path': test_url,
                        'redirect_to': redirect_url,
                        'status_code': response.status_code
                    }
                    
                    # Check if redirect is to login page
                    if any(login_indicator in redirect_url.lower() for login_indicator in ['login', 'auth', 'signin']):
                        redirect_info['login_redirect'] = True
                        redirect_findings.append(redirect_info)
                        print(f"✅ Login Redirect: {test_url} → {redirect_url}")
                    else:
                        redirect_info['login_redirect'] = False
                        redirect_findings.append(redirect_info)
                        print(f"🔀 General Redirect: {test_url} → {redirect_url}")
            except:
                continue
        
        self.discovered_parameters['redirects'] = redirect_findings
    
    def session_analysis(self, target_url):
        """Analyze session and cookie parameters - ENHANCED"""
        print("\n🔍 Phase 7: Session & Cookie Analysis")
        print("-" * 40)
        
        try:
            response = self.session.get(target_url, timeout=10)
            cookies = self.session.cookies
            headers = response.headers
            
            session_params = []
            
            # Analyze cookies
            for cookie in cookies:
                cookie_info = {
                    'name': cookie.name,
                    'value_sample': cookie.value[:30] + '...' if len(cookie.value) > 30 else cookie.value,
                    'domain': cookie.domain,
                    'path': cookie.path,
                    'type': 'cookie'
                }
                session_params.append(cookie_info)
                print(f"🍪 Cookie: {cookie.name}")
            
            # Analyze headers for session tokens
            session_headers = ['set-cookie', 'authorization', 'x-csrf-token', 'x-auth-token']
            for header in session_headers:
                if header in headers:
                    session_params.append({
                        'name': header,
                        'value_sample': headers[header][:50] + '...',
                        'type': 'header'
                    })
                    print(f"📋 Session Header: {header}")
            
            self.discovered_parameters['session_data'] = session_params
            
        except Exception as e:
            print(f"❌ Session analysis error: {e}")
    
    def generate_login_report(self, target_url):
        """Generate comprehensive login parameter report - ENHANCED"""
        print("\n📊 Generating Advanced Login Discovery Report...")
        
        # Calculate discovery statistics
        total_forms = len([k for k in self.discovered_parameters.keys() if k.startswith('form_')])
        total_login_forms = len([f for f in self.all_forms_data if f.get('is_login_form', False)])
        total_parameters = sum(len(f['parameters']) for f in self.all_forms_data)
        
        # Find all login-related parameters
        login_parameters = []
        for form_data in self.all_forms_data:
            for param in form_data['parameters']:
                if param['login_confidence'] == 'HIGH':
                    login_parameters.append({
                        'form_action': form_data['action'],
                        'parameter_name': param['name'],
                        'parameter_type': param['type'],
                        'login_confidence': param['login_confidence']
                    })
        
        report = {
            'target_url': target_url,
            'scan_date': datetime.now().isoformat(),
            'discovery_summary': {
                'total_forms_analyzed': total_forms,
                'login_forms_identified': total_login_forms,
                'total_parameters_found': total_parameters,
                'login_parameters_found': len(login_parameters),
                'api_endpoints_found': len(self.discovered_parameters.get('api_endpoints', [])),
                'login_pages_found': len(self.discovered_parameters.get('login_pages', [])),
                'redirects_found': len(self.discovered_parameters.get('redirects', []))
            },
            'detailed_findings': self.discovered_parameters,
            'login_parameters': login_parameters,
            'login_endpoints': self.login_endpoints,
            'all_forms': self.all_forms_data
        }
        
        # Save report
        filename = f"login_discovery_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"💾 Login discovery report saved: {filename}")
        self.display_comprehensive_summary(report)
        
        return report
    
    def display_comprehensive_summary(self, report):
        """Display comprehensive discovery summary - ENHANCED"""
        print("\n" + "=" * 70)
        print("🎯 ADVANCED LOGIN PARAMETER DISCOVERY SUMMARY")
        print("=" * 70)
        print(f"🎯 Target: {report['target_url']}")
        print(f"📅 Scan Date: {report['scan_date']}")
        
        summary = report['discovery_summary']
        print(f"📝 Forms Analyzed: {summary['total_forms_analyzed']}")
        print(f"🔐 Login Forms: {summary['login_forms_identified']}")
        print(f"🎯 Total Parameters: {summary['total_parameters_found']}")
        print(f"🔑 Login Parameters: {summary['login_parameters_found']}")
        print(f"🌐 API Endpoints: {summary['api_endpoints_found']}")
        print(f"📄 Login Pages: {summary['login_pages_found']}")
        print(f"🔄 Login Redirects: {summary['redirects_found']}")
        
        # Display critical login parameters
        if report.get('login_parameters'):
            print(f"\n🔑 CRITICAL LOGIN PARAMETERS FOUND:")
            for param in report['login_parameters'][:10]:  # Show first 10
                print(f"   • {param['parameter_name']} ({param['parameter_type']})")
                print(f"     Form: {param['form_action']}")
        
        # Display login forms
        print(f"\n📝 LOGIN FORMS IDENTIFIED:")
        for form_data in self.all_forms_data:
            if form_data.get('is_login_form', False):
                print(f"   • {form_data['full_url']}")
                print(f"     Method: {form_data['method']}")
                for param in form_data['parameters']:
                    if param['login_confidence'] == 'HIGH':
                        print(f"     🔐 {param['name']} ({param['type']})")
        
        # Display security assessment
        print(f"\n💡 SECURITY ASSESSMENT:")
        if summary['login_forms_identified'] > 0:
            print("   ✅ Login mechanisms successfully identified")
            print("   🔓 Ready for credential testing")
        else:
            print("   ⚠️ No clear login forms detected")
            print("   💡 Try manual inspection or different target")
        
        if summary['api_endpoints_found'] > 0:
            print("   ✅ API authentication endpoints discovered")
        
        if summary['redirects_found'] > 0:
            print("   ✅ Protected areas with login redirects identified")

def main():
    """Main function for standalone testing"""
    print("🚀 ADVANCED LOGIN PARAMETER DETECTOR - ENHANCED")
    print("=" * 60)
    
    target = input("🎯 Enter target URL: ").strip()
    
    # Clean the URL
    target = target.replace('"', '').replace("'", "")
    
    if not target.startswith(('http://', 'https://')):
        target = 'http://' + target
    
    detector = AdvancedLoginDetector()
    
    try:
        start_time = time.time()
        report = detector.comprehensive_login_discovery(target)
        duration = time.time() - start_time
        
        print(f"\n⏱️ Discovery duration: {duration:.2f} seconds")
        print("🎉 LOGIN PARAMETER DISCOVERY COMPLETED!")
        
        # Show immediate results
        if report['discovery_summary']['login_parameters_found'] > 0:
            print(f"\n🚀 READY FOR PASSWORD CRACKING!")
            print("Use these parameters with the credential cracker bot:")
            for param in report['login_parameters'][:5]:
                print(f"   🔑 {param['parameter_name']}")
        
    except KeyboardInterrupt:
        print("\n⏹️ Discovery interrupted by user")
    except Exception as e:
        print(f"💥 Discovery failed: {e}")

if __name__ == "__main__":
    main()
