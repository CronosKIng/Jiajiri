#!/usr/bin/env python3
"""
PDF Report Generator for Ghost Tester
"""

from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from datetime import datetime
import json

class PDFReportGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        
    def generate_scan_report(self, scan_data, results, filename):
        """Generate PDF report for scan results"""
        doc = SimpleDocTemplate(filename, pagesize=letter)
        story = []
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=30,
            textColor=colors.darkblue
        )
        
        title = Paragraph(f"👻 GHOST TESTER SECURITY SCAN REPORT", title_style)
        story.append(title)
        
        # Scan Information
        story.append(Paragraph("<b>Scan Information:</b>", self.styles['Heading2']))
        
        scan_info = [
            ["Target URL:", scan_data['target_url']],
            ["Scan Type:", scan_data['scan_type'].replace('_', ' ').title()],
            ["Scan Date:", scan_data['created_at']],
            ["Status:", scan_data['status'].title()]
        ]
        
        scan_table = Table(scan_info, colWidths=[1.5*inch, 4*inch])
        scan_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightblue),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('BACKGROUND', (1, 0), (1, -1), colors.white),
        ]))
        
        story.append(scan_table)
        story.append(Spacer(1, 20))
        
        # Results Summary
        story.append(Paragraph("<b>Results Summary:</b>", self.styles['Heading2']))
        
        if isinstance(results, dict):
            # Credential Cracking Results
            if 'credentials_found' in results:
                creds_found = results['credentials_found']
                story.append(Paragraph(f"Credentials Found: <b>{creds_found}</b>", self.styles['Normal']))
                
                if creds_found > 0 and 'found_credentials' in results:
                    story.append(Spacer(1, 10))
                    story.append(Paragraph("<b>Cracked Credentials:</b>", self.styles['Heading3']))
                    
                    cred_data = [["Username", "Password", "Status"]]
                    for cred in results['found_credentials']:
                        cred_data.append([
                            cred.get('username', 'N/A'),
                            cred.get('password', 'N/A'),
                            "ACCESS GRANTED"
                        ])
                    
                    cred_table = Table(cred_data, colWidths=[2*inch, 2*inch, 1.5*inch])
                    cred_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
                        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, -1), 9),
                        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black)
                    ]))
                    story.append(cred_table)
            
            # SQL Injection Results
            elif 'vulnerable_sites_found' in results:
                vuln_count = results['vulnerable_sites_found']
                story.append(Paragraph(f"SQL Injection Vulnerabilities Found: <b>{vuln_count}</b>", self.styles['Normal']))
                
                if vuln_count > 0 and 'vulnerable_sites' in results:
                    story.append(Spacer(1, 10))
                    story.append(Paragraph("<b>Vulnerable Sites:</b>", self.styles['Heading3']))
                    
                    for i, site in enumerate(results['vulnerable_sites'], 1):
                        story.append(Paragraph(f"{i}. {site.get('url', 'N/A')}", self.styles['Normal']))
                        story.append(Paragraph(f"   Parameter: {site.get('parameter', 'N/A')}", self.styles['Normal']))
                        story.append(Paragraph(f"   Databases: {', '.join(site.get('databases', []))}", self.styles['Normal']))
                        story.append(Spacer(1, 5))
            
            # Full Penetration Test Results
            elif 'vulnerabilities_found' in results:
                vuln_count = results['vulnerabilities_found']
                security_score = results.get('security_score', 'N/A')
                risk_level = results.get('risk_level', 'N/A')
                
                story.append(Paragraph(f"Vulnerabilities Found: <b>{vuln_count}</b>", self.styles['Normal']))
                story.append(Paragraph(f"Security Score: <b>{security_score}/100</b>", self.styles['Normal']))
                story.append(Paragraph(f"Risk Level: <b>{risk_level}</b>", self.styles['Normal']))
                
                if vuln_count > 0 and 'vulnerabilities' in results:
                    story.append(Spacer(1, 10))
                    story.append(Paragraph("<b>Vulnerability Breakdown:</b>", self.styles['Heading3']))
                    
                    vuln_types = {}
                    for vuln in results['vulnerabilities']:
                        vuln_type = vuln.get('type', 'Unknown')
                        vuln_types[vuln_type] = vuln_types.get(vuln_type, 0) + 1
                    
                    vuln_data = [["Vulnerability Type", "Count"]]
                    for vuln_type, count in vuln_types.items():
                        vuln_data.append([vuln_type, str(count)])
                    
                    vuln_table = Table(vuln_data, colWidths=[3.5*inch, 1*inch])
                    vuln_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), colors.darkgreen),
                        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, -1), 9),
                        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black)
                    ]))
                    story.append(vuln_table)
            
            # Error case
            elif 'error' in results:
                story.append(Paragraph(f"<b>Error during scan:</b> {results['error']}", self.styles['Normal']))
        
        else:
            story.append(Paragraph("No detailed results available.", self.styles['Normal']))
        
        # Recommendations
        story.append(Spacer(1, 20))
        story.append(Paragraph("<b>Security Recommendations:</b>", self.styles['Heading2']))
        
        recommendations = [
            "• Change default passwords and use strong, unique passwords",
            "• Keep all software and systems updated",
            "• Implement proper input validation and sanitization",
            "• Use HTTPS encryption for all web traffic",
            "• Regular security testing and monitoring",
            "• Implement proper access controls",
            "• Backup data regularly"
        ]
        
        for rec in recommendations:
            story.append(Paragraph(rec, self.styles['Normal']))
        
        # Footer
        story.append(Spacer(1, 30))
        story.append(Paragraph(f"Generated by Ghost Tester on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 
                             self.styles['Italic']))
        
        doc.build(story)
        return filename
