#!/usr/bin/env python3
"""
Registration Form PDF Generator for Ethical Ghost Tester
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from datetime import datetime
import os

def generate_registration_form():
    """Generate PDF registration form"""
    try:
        # Create templates directory if not exists
        os.makedirs('templates', exist_ok=True)
        
        filename = os.path.join('templates', 'Ethical_Ghost_Tester_Registration_Form.pdf')
        doc = SimpleDocTemplate(filename, pagesize=letter)
        story = []
        styles = getSampleStyleSheet()
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=colors.darkblue,
            alignment=1,  # Center aligned
            spaceAfter=30
        )
        
        title = Paragraph("ETHICAL GHOST TESTER - REGISTRATION FORM", title_style)
        story.append(title)
        
        # Personal Information Section
        story.append(Paragraph("<b>PERSONAL INFORMATION</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        personal_info = [
            ["Full Name (as in NIDA):", "________________________________________"],
            ["NIDA Number:", "________________________________________"],
            ["Phone Number:", "________________________________________"]
        ]
        
        personal_table = Table(personal_info, colWidths=[2*inch, 4*inch])
        personal_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(personal_table)
        story.append(Spacer(1, 20))
        
        # Account Information Section
        story.append(Paragraph("<b>ACCOUNT INFORMATION</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        account_info = [
            ["Email Address:", "________________________________________"],
            ["Username:", "________________________________________"],
            ["Password:", "________________________________________"],
            ["Confirm Password:", "________________________________________"]
        ]
        
        account_table = Table(account_info, colWidths=[2*inch, 4*inch])
        account_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(account_table)
        story.append(Spacer(1, 20))
        
        # System Information Section
        story.append(Paragraph("<b>SYSTEM INFORMATION</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        system_info = [
            ["Your System Domain/URL:", "________________________________________"]
        ]
        
        system_table = Table(system_info, colWidths=[2*inch, 4*inch])
        system_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(system_table)
        story.append(Spacer(1, 20))
        
        # Required Documents Section
        story.append(Paragraph("<b>REQUIRED DOCUMENTS</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        documents = [
            ["□ Passport Size Photo", "(Attach clear photo)"],
            ["□ NIDA ID Document", "(Copy of your NIDA card)"],
            ["□ Completed Registration Form", "(This form after filling)"]
        ]
        
        docs_table = Table(documents, colWidths=[2.5*inch, 3.5*inch])
        docs_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
        ]))
        story.append(docs_table)
        story.append(Spacer(1, 20))
        
        # Ethical Oath Agreement
        story.append(Paragraph("<b>ETHICAL OATH AGREEMENT</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        oath_text = """
        <b>NIMEKUBALI NA KUKIRIDHIKA KWAMBA:</b><br/>
        1. Mimi ________________________________ nimejikubalisha kufanya penetration test ya mfumo wangu mwenyewe pekee.<br/>
        2. Nimehakikisha kuwa mfumo ninachotaka kufanyiwa ukaguzi ni wangu mwenyewe na mimi ndiye mmiliki halali.<br/>
        3. Nikijaribu kufanya ukaguzi wa mfumo wowote ambao haunihusu, nipo tayari kukubali adhabu yoyote itakayotolewa na serikali ya Tanzania.<br/>
        4. Nimekubaliana na malipo ya huduma kupitia namba: <b>0772186012</b> jina la akaunti: <b>Ismail Ali</b> kampuni: <b>M-Pesa</b><br/>
        """
        
        story.append(Paragraph(oath_text, styles['Normal']))
        story.append(Spacer(1, 15))
        
        # Signature Section
        signature_info = [
            ["Signature:", "_________________________"],
            ["Date:", "_________________________"],
            ["Fingerprint:", "[Space for thumb print]"]
        ]
        
        signature_table = Table(signature_info, colWidths=[1.5*inch, 4.5*inch])
        signature_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica-Bold', 12),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightblue),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
        ]))
        story.append(signature_table)
        story.append(Spacer(1, 20))
        
        # Footer
        footer = Paragraph(f"<i>Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Ethical Ghost Tester Platform</i>", styles['Italic'])
        story.append(footer)
        
        # Build PDF
        doc.build(story)
        print(f"✅ PDF registration form generated: {filename}")
        return filename
        
    except Exception as e:
        print(f"❌ Error generating PDF: {e}")
        return None

if __name__ == "__main__":
    generate_registration_form()
