#!/usr/bin/env python3
"""
ETHICAL PENETRATION GHOST TESTER PLATFORM - ADVANCED VERSION
Integrated with ALL advanced penetration testing tools
NA USAJILI WA HALI YA JUU NA UTHIBITISHJI WA MKURUGENZI
"""

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
import sqlite3
import os
import threading
import json
import hashlib
import re
import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from urllib.parse import urlparse
from werkzeug.utils import secure_filename
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.units import inch

# Import ALL your advanced bots
from url_advance_sqlmap_penetration import AdvancedReconBot
from url_only_penetration_test import AutonomousPentestBot
from advance_cracking_login_password import UltimateCredentialCracker
from pdf_report import PDFReportGenerator
from advanced_nmap_scanner import AdvancedNmapScanner
from advanced_login_detector import AdvancedLoginDetector
from advanced_subdomain_enum import AdvancedSubdomainEnum
from advanced_waf_detector import AdvancedWAFDetector
from config import RECAPTCHA_CONFIG, EMAIL_CONFIG

app = Flask(__name__)
app.secret_key = 'ghost_tester_advanced_secret_2024'
app.config['DATABASE'] = 'ghost_tester_advanced.db'
app.config['UPLOAD_FOLDER'] = 'user_uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf', 'doc', 'docx'}

# Initialize database
def init_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    c = conn.cursor()
    
    # Users table - UPDATED WITH NEW FIELDS
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  full_name TEXT NOT NULL,
                  nida_number TEXT UNIQUE NOT NULL,
                  phone_number TEXT NOT NULL,
                  email TEXT UNIQUE NOT NULL,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  passport_photo TEXT,
                  id_document TEXT,
                  registration_form TEXT,
                  fingerprint_data TEXT,
                  oath_accepted BOOLEAN DEFAULT FALSE,
                  domain_ownership_verified BOOLEAN DEFAULT FALSE,
                  payment_verified BOOLEAN DEFAULT FALSE,
                  account_verified BOOLEAN DEFAULT FALSE,
                  verification_code TEXT,
                  reset_token TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    # Scan results table
    c.execute('''CREATE TABLE IF NOT EXISTS scan_results
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  target_url TEXT NOT NULL,
                  scan_type TEXT NOT NULL,
                  results TEXT,
                  status TEXT DEFAULT 'pending',
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    # Oath agreements table
    c.execute('''CREATE TABLE IF NOT EXISTS oath_agreements
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  oath_text TEXT NOT NULL,
                  signature_data TEXT,
                  accepted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    conn.commit()
    conn.close()

init_db()

# Database helper functions
def get_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row
    return conn

# PDF Registration Form Generator
def generate_registration_form():
    """Generate PDF registration form"""
    try:
        filename = os.path.join('templates', 'Ethical_Ghost_Tester_Registration_Form.pdf')
        doc = SimpleDocTemplate(filename, pagesize=letter)
        story = []
        styles = getSampleStyleSheet()
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=colors.darkblue,
            alignment=1,
            spaceAfter=30
        )
        
        title = Paragraph("ETHICAL GHOST TESTER - REGISTRATION FORM", title_style)
        story.append(title)
        
        # Personal Information Section
        story.append(Paragraph("<b>PERSONAL INFORMATION</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        personal_info = [
            ["Full Name (as in NIDA):", "________________________________________"],
            ["NIDA Number:", "________________________________________"],
            ["Phone Number:", "________________________________________"]
        ]
        
        personal_table = Table(personal_info, colWidths=[2*inch, 4*inch])
        personal_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(personal_table)
        story.append(Spacer(1, 20))
        
        # Account Information Section
        story.append(Paragraph("<b>ACCOUNT INFORMATION</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        account_info = [
            ["Email Address:", "________________________________________"],
            ["Username:", "________________________________________"],
            ["Password:", "________________________________________"]
        ]
        
        account_table = Table(account_info, colWidths=[2*inch, 4*inch])
        account_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(account_table)
        story.append(Spacer(1, 20))
        
        # System Information Section
        story.append(Paragraph("<b>SYSTEM INFORMATION</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        system_info = [
            ["Your System Domain/URL:", "________________________________________"]
        ]
        
        system_table = Table(system_info, colWidths=[2*inch, 4*inch])
        system_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(system_table)
        story.append(Spacer(1, 20))
        
        # Required Documents Section
        story.append(Paragraph("<b>REQUIRED DOCUMENTS</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        documents = [
            ["□ Passport Size Photo", "(Attach clear photo)"],
            ["□ NIDA ID Document", "(Copy of your NIDA card)"],
            ["□ Completed Registration Form", "(This form after filling)"]
        ]
        
        docs_table = Table(documents, colWidths=[2.5*inch, 3.5*inch])
        docs_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica', 10),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
        ]))
        story.append(docs_table)
        story.append(Spacer(1, 20))
        
        # Ethical Oath Agreement
        story.append(Paragraph("<b>ETHICAL OATH AGREEMENT</b>", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        oath_text = """
        <b>NIMEKUBALI NA KUKIRIDHIKA KWAMBA:</b><br/>
        1. Mimi ________________________ nimejikubalisha kufanya penetration test ya mfumo wangu mwenyewe pekee.<br/>
        2. Nimehakikisha kuwa mfumo ninachotaka kufanyiwa ukaguzi ni wangu mwenyewe na mimi ndiye mmiliki halali.<br/>
        3. Nikijaribu kufanya ukaguzi wa mfumo wowote ambao haunihusu, nipo tayari kukubali adhabu yoyote itakayotolewa na serikali ya Tanzania.<br/>
        4. Nimekubaliana na malipo ya huduma kupitia namba: <b>0772186012</b> jina la akaunti: <b>Ismail Ali</b> kampuni: <b>M-Pesa</b><br/>
        """
        
        story.append(Paragraph(oath_text, styles['Normal']))
        story.append(Spacer(1, 15))
        
        # Signature Section
        signature_info = [
            ["Signature:", "_________________________"],
            ["Date:", "_________________________"],
            ["Fingerprint Area:", "[Place right thumb print here]"]
        ]
        
        signature_table = Table(signature_info, colWidths=[1.5*inch, 4.5*inch])
        signature_table.setStyle(TableStyle([
            ('FONT', (0, 0), (-1, -1), 'Helvetica-Bold', 12),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightblue),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
        ]))
        story.append(signature_table)
        story.append(Spacer(1, 20))
        
        # Footer
        footer = Paragraph(f"<i>Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Ethical Ghost Tester Platform</i>", styles['Italic'])
        story.append(footer)
        
        # Build PDF
        doc.build(story)
        print(f"✅ PDF registration form generated: {filename}")
        return filename
        
    except Exception as e:
        print(f"❌ Error generating PDF: {e}")
        return None

# reCAPTCHA verification function
def verify_recaptcha(recaptcha_response):
    """Verify reCAPTCHA response with Google"""
    try:
        payload = {
            'secret': RECAPTCHA_CONFIG['secret_key'],
            'response': recaptcha_response
        }
        response = requests.post(
            "https://www.google.com/recaptcha/api/siteverify",
            data=payload,
            timeout=10
        )
        result = response.json()
        return result.get('success', False)
    except Exception as e:
        print(f"reCAPTCHA verification error: {e}")
        return True  # Return True during development to bypass reCAPTCHA

# Password strength validation
def validate_password_strength(password):
    """Validate password meets strength requirements"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter"
    
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter"
    
    if not re.search(r"\d", password):
        return False, "Password must contain at least one number"
    
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        return False, "Password must contain at least one special character"
    
    return True, "Password is strong"

# File upload validation
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Email sending function
def send_verification_email(email, verification_code):
    """Send verification email to user"""
    try:
        # Email configuration
        smtp_server = EMAIL_CONFIG['smtp_server']
        port = EMAIL_CONFIG['port']
        sender_email = EMAIL_CONFIG['sender_email']
        password = EMAIL_CONFIG['password']
        
        # Check if email password is configured
        if not password:
            print("❌ Email password not configured in .env file")
            return False
            
        # Create message
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = email
        message["Subject"] = "Email Verification - Ethical Ghost Tester"
        
        # Email body
        body = f"""
        Karibu kwenye Ethical Penetration Ghost Tester Platform!
        
        Tafadhali thibitisha barua pepe yako kwa kutumia msimbo wafuatayo:
        
        Msimbo wa Uthibitishaji: {verification_code}
        
        Au bofya kiungo hiki: 
        http://127.0.0.1:5000/verify-email?code={verification_code}&email={email}
        
        Usishiriki msimbo huu na mtu yeyote.
        
        Kwa usaidizi, wasiliana nasi kupitia ethicalpenetrationghosttester@gmail.com
        
        - Timu ya Ethical Ghost Tester
        """
        
        message.attach(MIMEText(body, "plain"))
        
        # Send email
        server = smtplib.SMTP(smtp_server, port)
        server.starttls()
        server.login(sender_email, password)
        server.send_message(message)
        server.quit()
        
        print(f"✅ Verification email sent to: {email}")
        return True
    except Exception as e:
        print(f"❌ Email sending error: {e}")
        return False

def send_password_reset_email(email, reset_token):
    """Send password reset email"""
    try:
        smtp_server = EMAIL_CONFIG['smtp_server']
        port = EMAIL_CONFIG['port']
        sender_email = EMAIL_CONFIG['sender_email']
        password = EMAIL_CONFIG['password']
        
        # Check if email password is configured
        if not password:
            print("❌ Email password not configured in .env file")
            return False
        
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = email
        message["Subject"] = "Password Reset - Ethical Ghost Tester"
        
        body = f"""
        Umepokea ombi la kubadilisha nenosiri la akaunti yako ya Ethical Ghost Tester.
        
        Bofya kiungo hiki kubadilisha nenosiri lako:
        http://127.0.0.1:5000/reset-password?token={reset_token}
        
        Kiungo hiki kitakwisha muda wa saa 1.
        
        Ikiwa hukuomba kubadilisha nenosiri, tafadhali puuza ujumbe huu.
        
        - Timu ya Ethical Ghost Tester
        """
        
        message.attach(MIMEText(body, "plain"))
        
        server = smtplib.SMTP(smtp_server, port)
        server.starttls()
        server.login(sender_email, password)
        server.send_message(message)
        server.quit()
        
        print(f"✅ Password reset email sent to: {email}")
        return True
    except Exception as e:
        print(f"❌ Password reset email error: {e}")
        return False

# Test email configuration
def test_email_config():
    """Test email configuration"""
    print("🔧 Testing email configuration...")
    print(f"SMTP Server: {EMAIL_CONFIG.get('smtp_server')}")
    print(f"Port: {EMAIL_CONFIG.get('port')}")
    print(f"Sender Email: {EMAIL_CONFIG.get('sender_email')}")
    print(f"Password configured: {'YES' if EMAIL_CONFIG.get('password') else 'NO'}")
    
    # Test connection
    try:
        server = smtplib.SMTP(EMAIL_CONFIG['smtp_server'], EMAIL_CONFIG['port'])
        server.starttls()
        server.login(EMAIL_CONFIG['sender_email'], EMAIL_CONFIG['password'])
        print("✅ Email connection successful!")
        server.quit()
        return True
    except Exception as e:
        print(f"❌ Email connection failed: {e}")
        return False

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Verify reCAPTCHA first
        recaptcha_response = request.form.get('g-recaptcha-response')
        if not verify_recaptcha(recaptcha_response):
            flash('Please complete the reCAPTCHA verification!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        # Basic form validation
        full_name = request.form['full_name']
        nida_number = request.form['nida_number']
        phone_number = request.form['phone_number']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        domain_url = request.form['domain_url']
        accept_oath = request.form.get('accept_oath') == 'on'
        signature = request.form.get('signature', '')
        
        # Validate passwords match
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        # Validate password strength
        is_strong, message = validate_password_strength(password)
        if not is_strong:
            flash(message, 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        # Validate oath acceptance
        if not accept_oath:
            flash('You must accept the ethical oath to proceed!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        # Validate signature
        if not signature or signature.strip() == '':
            flash('You must provide your signature!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        # Handle file uploads
        passport_photo = None
        id_document = None
        registration_form = None
        
        if 'passport_photo' in request.files:
            file = request.files['passport_photo']
            if file and allowed_file(file.filename):
                filename = secure_filename(f"passport_{username}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                passport_photo = filename
        
        if 'id_document' in request.files:
            file = request.files['id_document']
            if file and allowed_file(file.filename):
                filename = secure_filename(f"id_{username}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                id_document = filename
        
        if 'registration_form' in request.files:
            file = request.files['registration_form']
            if file and allowed_file(file.filename):
                filename = secure_filename(f"registration_{username}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                registration_form = filename
        
        # Generate verification code
        verification_code = hashlib.sha256(f"{email}{datetime.now()}".encode()).hexdigest()[:8]
        
        # Save to database
        conn = get_db()
        try:
            # Insert user
            cursor = conn.cursor()
            cursor.execute('''INSERT INTO users 
                         (full_name, nida_number, phone_number, email, username, password, 
                          passport_photo, id_document, registration_form, oath_accepted, 
                          verification_code, domain_ownership_verified) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (full_name, nida_number, phone_number, email, username, 
                         hashlib.sha256(password.encode()).hexdigest(),
                         passport_photo, id_document, registration_form, True,
                         verification_code, False))
            
            user_id = cursor.lastrowid
            
            # Save oath agreement
            oath_text = f"""
            ETHICAL OATH AGREEMENT
            
            I, {full_name}, hereby agree and confirm that:
            1. I am authorizing penetration testing on my own system only.
            2. I have verified that the system I want to test is my own and I am the legitimate owner.
            3. If I attempt to test any system that does not belong to me, I am ready to accept any punishment from the Tanzanian government.
            4. I have agreed to payment through: 0772186012 - Ismail Ali - M-Pesa
            
            Signature: {signature}
            Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            """
            
            cursor.execute('INSERT INTO oath_agreements (user_id, oath_text, signature_data) VALUES (?, ?, ?)',
                         (user_id, oath_text, signature))
            
            conn.commit()
            
            # Send verification email
            if send_verification_email(email, verification_code):
                flash('Account created successfully! Please check your email for verification.', 'success')
            else:
                flash('Account created but verification email failed to send. Please check your email configuration.', 'warning')
            
            return redirect(url_for('login'))
            
        except sqlite3.IntegrityError as e:
            if 'nida_number' in str(e):
                flash('NIDA number already registered!', 'error')
            elif 'email' in str(e):
                flash('Email already registered!', 'error')
            elif 'username' in str(e):
                flash('Username already taken!', 'error')
            else:
                flash('Registration failed! User may already exist.', 'error')
        finally:
            conn.close()
    
    return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/download-registration-form')
def download_registration_form():
    """Download the registration form template"""
    try:
        # Generate PDF form
        pdf_path = generate_registration_form()
        
        if pdf_path and os.path.exists(pdf_path):
            return send_file(pdf_path, 
                            as_attachment=True, 
                            download_name='Ethical_Ghost_Tester_Registration_Form.pdf')
        else:
            # Fallback if PDF generation fails
            flash('PDF form will be generated. Please try again.', 'info')
            return redirect(url_for('signup'))
            
    except Exception as e:
        print(f"Registration form error: {e}")
        flash('Form download service is ready. Please try again.', 'info')
        return redirect(url_for('signup'))

@app.route('/verify-email')
def verify_email():
    code = request.args.get('code')
    email = request.args.get('email')
    
    if not code or not email:
        flash('Invalid verification link!', 'error')
        return redirect(url_for('login'))
    
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE email = ? AND verification_code = ?', 
                       (email, code)).fetchone()
    
    if user:
        conn.execute('UPDATE users SET account_verified = TRUE, verification_code = NULL WHERE email = ?', 
                    (email,))
        conn.commit()
        flash('Email verified successfully! You can now login.', 'success')
    else:
        flash('Invalid verification code!', 'error')
    
    conn.close()
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        recaptcha_response = request.form.get('g-recaptcha-response')
        
        # Verify reCAPTCHA
        if not verify_recaptcha(recaptcha_response):
            flash('Please complete the reCAPTCHA verification!', 'error')
            return render_template('login.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        conn = get_db()
        user = conn.execute('''SELECT * FROM users WHERE username = ? AND password = ? 
                            AND account_verified = TRUE''',
                           (username, hashlib.sha256(password.encode()).hexdigest())).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['full_name'] = user['full_name']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials or account not verified!', 'error')
    
    return render_template('login.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        
        if user:
            # Generate reset token
            reset_token = hashlib.sha256(f"{email}{datetime.now()}".encode()).hexdigest()
            
            conn.execute('UPDATE users SET reset_token = ? WHERE email = ?', 
                        (reset_token, email))
            conn.commit()
            
            # Send reset email
            try:
                if send_password_reset_email(email, reset_token):
                    flash('Password reset link sent to your email!', 'success')
                else:
                    # Show reset link directly if email fails
                    reset_url = f"http://127.0.0.1:5000/reset-password?token={reset_token}"
                    flash(f'Email service unavailable. Use this link: {reset_url}', 'info')
            except Exception as e:
                reset_url = f"http://127.0.0.1:5000/reset-password?token={reset_token}"
                flash(f'Email error. Use this link: {reset_url}', 'info')
        else:
            flash('Email not found!', 'error')
        
        conn.close()
        return redirect(url_for('login'))
    
    return render_template('forgot_password.html')

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    token = request.args.get('token')
    
    if not token:
        flash('Invalid reset link!', 'error')
        return redirect(url_for('login'))
    
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE reset_token = ?', (token,)).fetchone()
    
    if not user:
        flash('Invalid or expired reset token!', 'error')
        conn.close()
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        
        if new_password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('reset_password.html', token=token)
        
        # Validate password strength
        is_strong, message = validate_password_strength(new_password)
        if not is_strong:
            flash(message, 'error')
            return render_template('reset_password.html', token=token)
        
        # Update password
        conn.execute('UPDATE users SET password = ?, reset_token = NULL WHERE id = ?',
                    (hashlib.sha256(new_password.encode()).hexdigest(), user['id']))
        conn.commit()
        conn.close()
        
        flash('Password reset successfully! You can now login with your new password.', 'success')
        return redirect(url_for('login'))
    
    conn.close()
    return render_template('reset_password.html', token=token)

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scans = conn.execute('''
        SELECT * FROM scan_results 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMit 10
    ''', (session['user_id'],)).fetchall()
    
    user_info = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    
    return render_template('dashboard.html', 
                         scans=scans, 
                         username=session['username'],
                         user_info=user_info,
                         recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/start-scan', methods=['POST'])
def start_scan():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    target_url = request.json.get('target_url')
    scan_type = request.json.get('scan_type')
    
    if not target_url:
        return jsonify({'error': 'Target URL required'}), 400
    
    # Save scan to database
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO scan_results (user_id, target_url, scan_type, status)
        VALUES (?, ?, ?, ?)
    ''', (session['user_id'], target_url, scan_type, 'running'))
    scan_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    # Start scan in background thread
    threading.Thread(target=run_advanced_scan, args=(scan_id, target_url, scan_type)).start()
    
    return jsonify({'message': 'Scan started', 'scan_id': scan_id})

def run_advanced_scan(scan_id, target_url, scan_type):
    """Run the actual penetration test with ALL advanced tools"""
    conn = get_db()
    
    try:
        results = {}
        
        if scan_type == 'sql_injection':
            bot = AdvancedReconBot()
            results = bot.automated_sqlmap_attack(target_url)
            
        elif scan_type == 'full_pentest':
            bot = AutonomousPentestBot()
            results = bot.autonomous_pentest(target_url)
            
        elif scan_type == 'credential_cracking':
            bot = UltimateCredentialCracker()
            results = bot.ultimate_credential_attack(target_url)
            
        elif scan_type == 'nmap_scan':
            scanner = AdvancedNmapScanner()
            results = scanner.comprehensive_scan(target_url)
            
        elif scan_type == 'login_detection':
            detector = AdvancedLoginDetector()
            results = detector.comprehensive_login_discovery(target_url)
            
        elif scan_type == 'subdomain_enum':
            enumerator = AdvancedSubdomainEnum()
            results = enumerator.comprehensive_enumeration(target_url)
            
        elif scan_type == 'waf_detection':
            detector = AdvancedWAFDetector()
            results = detector.comprehensive_waf_detection(target_url)
            
        elif scan_type == 'comprehensive_audit':
            # Run multiple scans for comprehensive audit
            comprehensive_results = {}
            
            # Nmap Scan
            try:
                nmap_scanner = AdvancedNmapScanner()
                comprehensive_results['nmap'] = nmap_scanner.comprehensive_scan(target_url)
            except Exception as e:
                comprehensive_results['nmap'] = {'error': str(e)}
            
            # Login Detection
            try:
                login_detector = AdvancedLoginDetector()
                comprehensive_results['login_detection'] = login_detector.comprehensive_login_discovery(target_url)
            except Exception as e:
                comprehensive_results['login_detection'] = {'error': str(e)}
            
            # WAF Detection
            try:
                waf_detector = AdvancedWAFDetector()
                comprehensive_results['waf_detection'] = waf_detector.comprehensive_waf_detection(target_url)
            except Exception as e:
                comprehensive_results['waf_detection'] = {'error': str(e)}
            
            # Subdomain Enumeration
            try:
                sub_enum = AdvancedSubdomainEnum()
                comprehensive_results['subdomain_enum'] = sub_enum.comprehensive_enumeration(target_url)
            except Exception as e:
                comprehensive_results['subdomain_enum'] = {'error': str(e)}
            
            results = comprehensive_results
            
        else:
            results = {'error': 'Unknown scan type'}
        
        # Update database with results
        conn.execute('''
            UPDATE scan_results 
            SET results = ?, status = ? 
            WHERE id = ?
        ''', (json.dumps(results), 'completed', scan_id))
        
    except Exception as e:
        conn.execute('''
            UPDATE scan_results 
            SET results = ?, status = ? 
            WHERE id = ?
        ''', (json.dumps({'error': str(e)}), 'failed', scan_id))
    
    conn.commit()
    conn.close()

@app.route('/scan-results/<int:scan_id>')
def scan_results(scan_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scan = conn.execute('''
        SELECT * FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        flash('Scan not found!', 'error')
        return redirect(url_for('dashboard'))
    
    results = json.loads(scan['results']) if scan['results'] else {}
    return render_template('scan_results.html', scan=scan, results=results)

@app.route('/download-pdf/<int:scan_id>')
def download_pdf(scan_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scan = conn.execute('''
        SELECT * FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        flash('Scan not found!', 'error')
        return redirect(url_for('dashboard'))
    
    results = json.loads(scan['results']) if scan['results'] else {}
    
    # Generate PDF
    pdf_gen = PDFReportGenerator()
    filename = f"ghost_tester_report_{scan_id}.pdf"
    filepath = os.path.join('exports', filename)
    
    # Create exports directory if not exists
    os.makedirs('exports', exist_ok=True)
    
    try:
        pdf_gen.generate_scan_report(dict(scan), results, filepath)
        
        # Return PDF file for download
        return send_file(filepath, as_attachment=True, download_name=filename)
        
    except Exception as e:
        flash(f'Error generating PDF: {e}', 'error')
        return redirect(url_for('scan_results', scan_id=scan_id))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'info')
    return redirect(url_for('index'))

# API endpoint to get scan status
@app.route('/api/scan-status/<int:scan_id>')
def scan_status(scan_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    conn = get_db()
    scan = conn.execute('''
        SELECT id, status, target_url, scan_type, created_at 
        FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    
    return jsonify(dict(scan))

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('exports', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    os.makedirs('backups', exist_ok=True)
    os.makedirs('user_uploads', exist_ok=True)
    os.makedirs('templates', exist_ok=True)
    
    print("🚀 GHOST TESTER ADVANCED PLATFORM STARTING...")
    print("🔧 Integrated Tools:")
    print("   ✅ SQL Injection Scanner")
    print("   ✅ Full Penetration Testing")
    print("   ✅ Credential Cracking")
    print("   ✅ Advanced Nmap Scanning")
    print("   ✅ Login Parameter Detection")
    print("   ✅ Subdomain Enumeration")
    print("   ✅ WAF Detection")
    print("   ✅ Comprehensive Security Audit")
    print("   ✅ Advanced User Registration & Verification")
    print("   ✅ reCAPTCHA Integration")
    print("   ✅ PDF Registration Form Generator")
    
    # Test email configuration
    test_email_config()
    
    print("🌍 Server running on http://127.0.0.1:5000")
    
    app.run(host='127.0.0.1', port=5000, debug=True)
