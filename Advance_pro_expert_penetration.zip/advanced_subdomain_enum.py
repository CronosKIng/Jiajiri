#!/usr/bin/env python3
"""
ADVANCED SUBDOMAIN ENUMERATION
Comprehensive subdomain discovery with multiple techniques
"""

import requests
import dns.resolver
import threading
import time
import json
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from datetime import datetime

class AdvancedSubdomainEnum:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36',
        })
        self.discovered_subdomains = set()
        
    def comprehensive_enumeration(self, domain):
        """Perform comprehensive subdomain enumeration"""
        print("🚀 STARTING ADVANCED SUBDOMAIN ENUMERATION")
        print("=" * 50)
        print(f"🎯 Target Domain: {domain}")
        
        # Clean domain
        domain = self.clean_domain(domain)
        
        enumeration_methods = [
            self.crtsh_search,
            self.dns_bruteforce,
            self.common_subdomains,
            self.google_dorking,
            self.dns_zone_transfer,
            self.certificate_transparency
        ]
        
        for method in enumeration_methods:
            try:
                method(domain)
                time.sleep(1)
            except Exception as e:
                print(f"❌ {method.__name__} failed: {e}")
                continue
        
        return self.generate_enumeration_report(domain)
    
    def clean_domain(self, domain):
        """Extract clean domain from URL"""
        if '://' in domain:
            parsed = urlparse(domain)
            domain = parsed.hostname
        return domain
    
    def crtsh_search(self, domain):
        """Search crt.sh for subdomains"""
        print("\n🔍 Phase 1: Certificate Transparency Search")
        print("-" * 40)
        
        try:
            url = f"https://crt.sh/?q=%.{domain}&output=json"
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                for cert in data:
                    common_name = cert.get('common_name', '')
                    if domain in common_name and common_name not in self.discovered_subdomains:
                        self.discovered_subdomains.add(common_name)
                        print(f"✅ CRT.SH: {common_name}")
        except Exception as e:
            print(f"❌ CRT.SH search error: {e}")
    
    def dns_bruteforce(self, domain):
        """DNS bruteforce with common subdomains"""
        print("\n🔍 Phase 2: DNS Bruteforce")
        print("-" * 40)
        
        common_subs = [
            'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop', 'ns1', 'webdisk',
            'ns2', 'cpanel', 'whm', 'autodiscover', 'autoconfig', 'm', 'imap', 'test',
            'ns', 'blog', 'pop3', 'dev', 'www2', 'admin', 'forum', 'news', 'vpn', 'ns3',
            'mail2', 'new', 'mysql', 'old', 'lists', 'support', 'mobile', 'mx', 'static',
            'docs', 'beta', 'shop', 'sql', 'secure', 'demo', 'cp', 'calendar', 'wiki',
            'web', 'media', 'email', 'images', 'img', 'www1', 'intranet', 'portal',
            'video', 'sip', 'dns2', 'api', 'cdn', 'stats', 'dns1', 'ns4', 'www3',
            'chat', 'search', 'apps', 'download', 'remote', 'db', 'forums', 'store',
            'feed', 'files', 'newsletter', 'app', 'assets', 'crm', 'monitor', 'live'
        ]
        
        def check_subdomain(sub):
            full_domain = f"{sub}.{domain}"
            try:
                dns.resolver.resolve(full_domain, 'A')
                if full_domain not in self.discovered_subdomains:
                    self.discovered_subdomains.add(full_domain)
                    print(f"✅ DNS: {full_domain}")
            except:
                pass
        
        with ThreadPoolExecutor(max_workers=20) as executor:
            executor.map(check_subdomain, common_subs)
    
    def common_subdomains(self, domain):
        """Check very common subdomains"""
        print("\n🔍 Phase 3: Common Subdomains Check")
        print("-" * 40)
        
        very_common = ['www', 'mail', 'ftp', 'admin', 'test', 'dev', 'staging']
        
        for sub in very_common:
            full_domain = f"{sub}.{domain}"
            try:
                dns.resolver.resolve(full_domain, 'A')
                if full_domain not in self.discovered_subdomains:
                    self.discovered_subdomains.add(full_domain)
                    print(f"✅ Common: {full_domain}")
            except:
                pass
    
    def google_dorking(self, domain):
        """Simple Google dorking simulation"""
        print("\n🔍 Phase 4: Search Engine Discovery")
        print("-" * 40)
        
        # This is a simplified version - real implementation would use APIs
        search_patterns = [
            f"site:*.{domain}",
            f"inurl:{domain}",
            f"intitle:{domain}"
        ]
        
        print("ℹ️ Search engine discovery requires API keys for full implementation")
    
    def dns_zone_transfer(self, domain):
        """Attempt DNS zone transfer"""
        print("\n🔍 Phase 5: DNS Zone Transfer Attempt")
        print("-" * 40)
        
        nameservers = ['ns1', 'ns2', 'ns3', 'ns4', 'dns1', 'dns2']
        
        for ns in nameservers:
            ns_domain = f"{ns}.{domain}"
            try:
                # Try AXFR request
                resolver = dns.resolver.Resolver()
                resolver.nameservers = [str(dns.resolver.resolve(ns_domain, 'A')[0])]
                
                try:
                    answers = resolver.resolve(domain, 'AXFR')
                    for record in answers:
                        if hasattr(record, 'target'):
                            subdomain = str(record.target)
                            if domain in subdomain and subdomain not in self.discovered_subdomains:
                                self.discovered_subdomains.add(subdomain)
                                print(f"🎉 ZONE TRANSFER: {subdomain}")
                except:
                    pass
                    
            except:
                continue
    
    def certificate_transparency(self, domain):
        """Additional certificate transparency sources"""
        print("\n🔍 Phase 6: Additional Certificate Search")
        print("-" * 40)
        
        # Additional CT log sources could be implemented here
        ct_sources = [
            f"https://api.certspotter.com/v1/issuances?domain={domain}&include_subdomains=true&expand=dns_names"
        ]
        
        for source in ct_sources:
            try:
                response = self.session.get(source, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    # Parse response for subdomains
                    print(f"✅ CertSpotter: Found {len(data) if isinstance(data, list) else 0} certificates")
            except:
                continue
    
    def generate_enumeration_report(self, domain):
        """Generate comprehensive enumeration report"""
        print("\n📊 Generating Subdomain Enumeration Report...")
        
        report = {
            'target_domain': domain,
            'scan_date': datetime.now().isoformat(),
            'subdomains_found': len(self.discovered_subdomains),
            'discovered_subdomains': list(self.discovered_subdomains),
            'enumeration_stats': {
                'unique_subdomains': len(self.discovered_subdomains),
                'scan_duration': 'N/A'
            }
        }
        
        # Save report
        filename = f"subdomain_enum_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"💾 Subdomain report saved: {filename}")
        self.display_enumeration_summary(report)
        
        return report
    
    def display_enumeration_summary(self, report):
        """Display enumeration summary"""
        print("\n" + "=" * 60)
        print("🎯 ADVANCED SUBDOMAIN ENUMERATION SUMMARY")
        print("=" * 60)
        print(f"🎯 Target: {report['target_domain']}")
        print(f"📅 Scan Date: {report['scan_date']}")
        print(f"🔍 Subdomains Found: {report['subdomains_found']}")
        
        if report['subdomains_found'] > 0:
            print(f"\n📡 DISCOVERED SUBDOMAINS:")
            for subdomain in report['discovered_subdomains'][:15]:  # Show first 15
                print(f"   • {subdomain}")
            
            if report['subdomains_found'] > 15:
                print(f"   • ... and {report['subdomains_found'] - 15} more")
        
        print(f"\n💡 SECURITY INSIGHTS:")
        if report['subdomains_found'] > 10:
            print("   ⚠️ Large attack surface detected")
            print("   🔍 Multiple subdomains require security assessment")
        elif report['subdomains_found'] > 0:
            print("   ✅ Moderate attack surface")
            print("   🔒 Regular subdomain monitoring recommended")
        else:
            print("   ✅ Minimal attack surface detected")

def main():
    """Main function for standalone testing"""
    print("🚀 ADVANCED SUBDOMAIN ENUMERATION")
    print("=" * 50)
    
    domain = input("🎯 Enter target domain: ").strip()
    
    enumerator = AdvancedSubdomainEnum()
    
    try:
        start_time = time.time()
        report = enumerator.comprehensive_enumeration(domain)
        duration = time.time() - start_time
        
        print(f"\n⏱️ Enumeration duration: {duration:.2f} seconds")
        print("🎉 SUBDOMAIN ENUMERATION COMPLETED!")
        
    except KeyboardInterrupt:
        print("\n⏹️ Enumeration interrupted by user")
    except Exception as e:
        print(f"💥 Enumeration failed: {e}")

if __name__ == "__main__":
    main()
