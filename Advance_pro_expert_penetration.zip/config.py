import os
from dotenv import load_dotenv

load_dotenv()

# Email Configuration
EMAIL_CONFIG = {
    'smtp_server': 'smtp.gmail.com',
    'port': 587,
    'sender_email': 'ethicalpenetrationghosttester@gmail.com',
    'password': os.getenv('EMAIL_PASSWORD')
}

# reCAPTCHA Configuration - TEST KEYS (No registration needed)
RECAPTCHA_CONFIG = {
    'site_key': '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI',
    'secret_key': '6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe'
}

# Payment Configuration
PAYMENT_CONFIG = {
    'phone_number': '0772186012',
    'account_name': 'Ismail Ali',
    'provider': 'M-Pesa'
}

# Demo sites URLs
DEMO_SITES = {
    "sauce_demo": "https://www.saucedemo.com/",
    "orangehrm": "https://opensource-demo.orangehrmlive.com/",
    "practice_site": "https://example.com"
}

# Demo credentials
DEMO_CREDENTIALS = {
    "sauce_demo": {
        "username": "standard_user",
        "password": "secret_sauce"
    },
    "orangehrm": {
        "username": "Admin",
        "password": "admin123"
    }
}
