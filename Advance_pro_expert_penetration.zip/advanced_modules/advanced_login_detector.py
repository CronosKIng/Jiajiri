class :
    def login_detector(self, target_url):
        return {"status": "completed", "target": target_url, "message": " scan completed"}
