#!/usr/bin/env python3
"""
ETHICAL PENETRATION GHOST TESTER PLATFORM - ADVANCED VERSION
Integrated with ALL advanced penetration testing tools INCLUDING FORENSIC
"""

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
import sqlite3
import os
import threading
import json
import hashlib
import re
import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from urllib.parse import urlparse
from werkzeug.utils import secure_filename

# Import ALL your advanced bots from existing files
from url_advance_sqlmap_penetration import AdvancedReconBot
from url_only_penetration_test import AutonomousPentestBot
from advance_cracking_login_password import UltimateCredentialCracker
from pdf_report import PDFReportGenerator
from advanced_nmap_scanner import AdvancedNmapScanner
from advanced_login_detector import AdvancedLoginDetector
from advanced_subdomain_enum import AdvancedSubdomainEnum
from advanced_waf_detector import AdvancedWAFDetector

# IMPORT NEW FORENSIC TOOLS from your existing files
from cyber_forensic_tracker import CyberForensicTracker

# Import config
try:
    from config import RECAPTCHA_CONFIG, EMAIL_CONFIG
except ImportError:
    # Default config if config.py doesn't exist
    RECAPTCHA_CONFIG = {
        'site_key': '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI',
        'secret_key': '6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe'
    }
    EMAIL_CONFIG = {
        'smtp_server': 'smtp.gmail.com',
        'port': 587,
        'sender_email': 'ethicalpenetrationghosttester@gmail.com',
        'password': ''
    }

app = Flask(__name__)
app.secret_key = 'ghost_tester_advanced_secret_2024'
app.config['DATABASE'] = 'ghost_tester_advanced.db'
app.config['UPLOAD_FOLDER'] = 'user_uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf', 'doc', 'docx'}

# Initialize database
def init_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  full_name TEXT NOT NULL,
                  nida_number TEXT UNIQUE NOT NULL,
                  phone_number TEXT NOT NULL,
                  email TEXT UNIQUE NOT NULL,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  passport_photo TEXT,
                  id_document TEXT,
                  registration_form TEXT,
                  fingerprint_data TEXT,
                  oath_accepted BOOLEAN DEFAULT FALSE,
                  domain_ownership_verified BOOLEAN DEFAULT FALSE,
                  payment_verified BOOLEAN DEFAULT FALSE,
                  account_verified BOOLEAN DEFAULT FALSE,
                  verification_code TEXT,
                  reset_token TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS scan_results
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  target_url TEXT NOT NULL,
                  scan_type TEXT NOT NULL,
                  results TEXT,
                  status TEXT DEFAULT 'pending',
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS oath_agreements
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  oath_text TEXT NOT NULL,
                  signature_data TEXT,
                  accepted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    conn.commit()
    conn.close()

init_db()

def get_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row
    return conn

# reCAPTCHA verification function
def verify_recaptcha(recaptcha_response):
    try:
        payload = {
            'secret': RECAPTCHA_CONFIG['secret_key'],
            'response': recaptcha_response
        }
        response = requests.post(
            "https://www.google.com/recaptcha/api/siteverify",
            data=payload,
            timeout=10
        )
        result = response.json()
        return result.get('success', False)
    except Exception as e:
        print(f"reCAPTCHA verification error: {e}")
        return True

def validate_password_strength(password):
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r"\d", password):
        return False, "Password must contain at least one number"
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        return False, "Password must contain at least one special character"
    return True, "Password is strong"

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def send_verification_email(email, verification_code):
    try:
        smtp_server = EMAIL_CONFIG['smtp_server']
        port = EMAIL_CONFIG['port']
        sender_email = EMAIL_CONFIG['sender_email']
        password = EMAIL_CONFIG['password']
        
        if not password:
            print("❌ Email password not configured")
            return False
            
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = email
        message["Subject"] = "Email Verification - Ethical Ghost Tester"
        
        body = f"""
        Karibu kwenye Ethical Penetration Ghost Tester Platform!
        
        Tafadhali thibitisha barua pepe yako kwa kutumia msimbo wafuatayo:
        
        Msimbo wa Uthibitishaji: {verification_code}
        
        Au bofya kiungo hiki: 
        http://127.0.0.1:5000/verify-email?code={verification_code}&email={email}
        
        Usishiriki msimbo huu na mtu yeyote.
        
        - Timu ya Ethical Ghost Tester
        """
        
        message.attach(MIMEText(body, "plain"))
        
        server = smtplib.SMTP(smtp_server, port)
        server.starttls()
        server.login(sender_email, password)
        server.send_message(message)
        server.quit()
        
        print(f"✅ Verification email sent to: {email}")
        return True
    except Exception as e:
        print(f"❌ Email sending error: {e}")
        return False

def send_password_reset_email(email, reset_token):
    try:
        smtp_server = EMAIL_CONFIG['smtp_server']
        port = EMAIL_CONFIG['port']
        sender_email = EMAIL_CONFIG['sender_email']
        password = EMAIL_CONFIG['password']
        
        if not password:
            print("❌ Email password not configured")
            return False
        
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = email
        message["Subject"] = "Password Reset - Ethical Ghost Tester"
        
        body = f"""
        Umepokea ombi la kubadilisha nenosiri la akaunti yako ya Ethical Ghost Tester.
        
        Bofya kiungo hiki kubadilisha nenosiri lako:
        http://127.0.0.1:5000/reset-password?token={reset_token}
        
        Kiungo hiki kitakwisha muda wa saa 1.
        
        Ikiwa hukuomba kubadilisha nenosiri, tafadhali puuza ujumbe huu.
        
        - Timu ya Ethical Ghost Tester
        """
        
        message.attach(MIMEText(body, "plain"))
        
        server = smtplib.SMTP(smtp_server, port)
        server.starttls()
        server.login(sender_email, password)
        server.send_message(message)
        server.quit()
        
        print(f"✅ Password reset email sent to: {email}")
        return True
    except Exception as e:
        print(f"❌ Password reset email error: {e}")
        return False

# Routes - SAME AS BEFORE
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        recaptcha_response = request.form.get('g-recaptcha-response')
        if not verify_recaptcha(recaptcha_response):
            flash('Please complete the reCAPTCHA verification!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        full_name = request.form['full_name']
        nida_number = request.form['nida_number']
        phone_number = request.form['phone_number']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        domain_url = request.form['domain_url']
        accept_oath = request.form.get('accept_oath') == 'on'
        signature = request.form.get('signature', '')
        
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        is_strong, message = validate_password_strength(password)
        if not is_strong:
            flash(message, 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        if not accept_oath:
            flash('You must accept the ethical oath to proceed!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        if not signature or signature.strip() == '':
            flash('You must provide your signature!', 'error')
            return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        passport_photo = None
        id_document = None
        registration_form = None
        
        if 'passport_photo' in request.files:
            file = request.files['passport_photo']
            if file and allowed_file(file.filename):
                filename = secure_filename(f"passport_{username}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                passport_photo = filename
        
        if 'id_document' in request.files:
            file = request.files['id_document']
            if file and allowed_file(file.filename):
                filename = secure_filename(f"id_{username}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                id_document = filename
        
        if 'registration_form' in request.files:
            file = request.files['registration_form']
            if file and allowed_file(file.filename):
                filename = secure_filename(f"registration_{username}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                registration_form = filename
        
        verification_code = hashlib.sha256(f"{email}{datetime.now()}".encode()).hexdigest()[:8]
        
        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('''INSERT INTO users 
                         (full_name, nida_number, phone_number, email, username, password, 
                          passport_photo, id_document, registration_form, oath_accepted, 
                          verification_code, domain_ownership_verified) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (full_name, nida_number, phone_number, email, username, 
                         hashlib.sha256(password.encode()).hexdigest(),
                         passport_photo, id_document, registration_form, True,
                         verification_code, False))
            
            user_id = cursor.lastrowid
            
            oath_text = f"""
            ETHICAL OATH AGREEMENT
            
            I, {full_name}, hereby agree and confirm that:
            1. I am authorizing penetration testing on my own system only.
            2. I have verified that the system I want to test is my own and I am the legitimate owner.
            3. If I attempt to test any system that does not belong to me, I am ready to accept any punishment from the Tanzanian government.
            4. I have agreed to payment through: 0772186012 - Ismail Ali - M-Pesa
            
            Signature: {signature}
            Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            """
            
            cursor.execute('INSERT INTO oath_agreements (user_id, oath_text, signature_data) VALUES (?, ?, ?)',
                         (user_id, oath_text, signature))
            
            conn.commit()
            
            if send_verification_email(email, verification_code):
                flash('Account created successfully! Please check your email for verification.', 'success')
            else:
                flash('Account created but verification email failed to send. Please check your email configuration.', 'warning')
            
            return redirect(url_for('login'))
            
        except sqlite3.IntegrityError as e:
            if 'nida_number' in str(e):
                flash('NIDA number already registered!', 'error')
            elif 'email' in str(e):
                flash('Email already registered!', 'error')
            elif 'username' in str(e):
                flash('Username already taken!', 'error')
            else:
                flash('Registration failed! User may already exist.', 'error')
        finally:
            conn.close()
    
    return render_template('signup.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/download-registration-form')
def download_registration_form():
    flash('PDF form download service is ready.', 'info')
    return redirect(url_for('signup'))

@app.route('/verify-email')
def verify_email():
    code = request.args.get('code')
    email = request.args.get('email')
    
    if not code or not email:
        flash('Invalid verification link!', 'error')
        return redirect(url_for('login'))
    
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE email = ? AND verification_code = ?', 
                       (email, code)).fetchone()
    
    if user:
        conn.execute('UPDATE users SET account_verified = TRUE, verification_code = NULL WHERE email = ?', 
                    (email,))
        conn.commit()
        flash('Email verified successfully! You can now login.', 'success')
    else:
        flash('Invalid verification code!', 'error')
    
    conn.close()
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        recaptcha_response = request.form.get('g-recaptcha-response')
        
        if not verify_recaptcha(recaptcha_response):
            flash('Please complete the reCAPTCHA verification!', 'error')
            return render_template('login.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])
        
        conn = get_db()
        user = conn.execute('''SELECT * FROM users WHERE username = ? AND password = ? 
                            AND account_verified = TRUE''',
                           (username, hashlib.sha256(password.encode()).hexdigest())).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['full_name'] = user['full_name']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials or account not verified!', 'error')
    
    return render_template('login.html', recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        
        if user:
            reset_token = hashlib.sha256(f"{email}{datetime.now()}".encode()).hexdigest()
            
            conn.execute('UPDATE users SET reset_token = ? WHERE email = ?', 
                        (reset_token, email))
            conn.commit()
            
            try:
                if send_password_reset_email(email, reset_token):
                    flash('Password reset link sent to your email!', 'success')
                else:
                    reset_url = f"http://127.0.0.1:5000/reset-password?token={reset_token}"
                    flash(f'Email service unavailable. Use this link: {reset_url}', 'info')
            except Exception as e:
                reset_url = f"http://127.0.0.1:5000/reset-password?token={reset_token}"
                flash(f'Email error. Use this link: {reset_url}', 'info')
        else:
            flash('Email not found!', 'error')
        
        conn.close()
        return redirect(url_for('login'))
    
    return render_template('forgot_password.html')

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    token = request.args.get('token')
    
    if not token:
        flash('Invalid reset link!', 'error')
        return redirect(url_for('login'))
    
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE reset_token = ?', (token,)).fetchone()
    
    if not user:
        flash('Invalid or expired reset token!', 'error')
        conn.close()
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        
        if new_password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('reset_password.html', token=token)
        
        is_strong, message = validate_password_strength(new_password)
        if not is_strong:
            flash(message, 'error')
            return render_template('reset_password.html', token=token)
        
        conn.execute('UPDATE users SET password = ?, reset_token = NULL WHERE id = ?',
                    (hashlib.sha256(new_password.encode()).hexdigest(), user['id']))
        conn.commit()
        conn.close()
        
        flash('Password reset successfully! You can now login with your new password.', 'success')
        return redirect(url_for('login'))
    
    conn.close()
    return render_template('reset_password.html', token=token)

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scans = conn.execute('''
        SELECT * FROM scan_results 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 10
    ''', (session['user_id'],)).fetchall()
    
    user_info = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    
    return render_template('dashboard.html', 
                         scans=scans, 
                         username=session['username'],
                         user_info=user_info,
                         recaptcha_site_key=RECAPTCHA_CONFIG['site_key'])

@app.route('/start-scan', methods=['POST'])
def start_scan():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    target_url = request.json.get('target_url')
    scan_type = request.json.get('scan_type')
    
    if not target_url:
        return jsonify({'error': 'Target URL required'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO scan_results (user_id, target_url, scan_type, status)
        VALUES (?, ?, ?, ?)
    ''', (session['user_id'], target_url, scan_type, 'running'))
    scan_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    threading.Thread(target=run_advanced_scan, args=(scan_id, target_url, scan_type)).start()
    
    return jsonify({'message': 'Scan started', 'scan_id': scan_id})

def run_advanced_scan(scan_id, target_url, scan_type):
    """Run the actual penetration test with ALL advanced tools INCLUDING FORENSIC"""
    conn = get_db()
    
    try:
        results = {}
        
        if scan_type == 'sql_injection':
            bot = AdvancedReconBot()
            results = bot.automated_sqlmap_attack(target_url)
            
        elif scan_type == 'full_pentest':
            bot = AutonomousPentestBot()
            results = bot.autonomous_pentest(target_url)
            
        elif scan_type == 'credential_cracking':
            bot = UltimateCredentialCracker()
            results = bot.ultimate_credential_attack(target_url)
            
        elif scan_type == 'nmap_scan':
            scanner = AdvancedNmapScanner()
            results = scanner.comprehensive_scan(target_url)
            
        elif scan_type == 'login_detection':
            detector = AdvancedLoginDetector()
            results = detector.comprehensive_login_discovery(target_url)
            
        elif scan_type == 'subdomain_enum':
            enumerator = AdvancedSubdomainEnum()
            results = enumerator.comprehensive_enumeration(target_url)
            
        elif scan_type == 'waf_detection':
            detector = AdvancedWAFDetector()
            results = detector.comprehensive_waf_detection(target_url)
            
        elif scan_type == 'comprehensive_audit':
            comprehensive_results = {}
            
            try:
                nmap_scanner = AdvancedNmapScanner()
                comprehensive_results['nmap'] = nmap_scanner.comprehensive_scan(target_url)
            except Exception as e:
                comprehensive_results['nmap'] = {'error': str(e)}
            
            try:
                login_detector = AdvancedLoginDetector()
                comprehensive_results['login_detection'] = login_detector.comprehensive_login_discovery(target_url)
            except Exception as e:
                comprehensive_results['login_detection'] = {'error': str(e)}
            
            try:
                waf_detector = AdvancedWAFDetector()
                comprehensive_results['waf_detection'] = waf_detector.comprehensive_waf_detection(target_url)
            except Exception as e:
                comprehensive_results['waf_detection'] = {'error': str(e)}
            
            try:
                sub_enum = AdvancedSubdomainEnum()
                comprehensive_results['subdomain_enum'] = sub_enum.comprehensive_enumeration(target_url)
            except Exception as e:
                comprehensive_results['subdomain_enum'] = {'error': str(e)}
            
            results = comprehensive_results

        # === FORENSIC SCAN TYPES ADDED HERE ===
        elif scan_type == 'ip_tracking':
            forensic_tracker = CyberForensicTracker()
            results = forensic_tracker.ip_geolocation(target_url)

        elif scan_type == 'digital_footprint':
            forensic_tracker = CyberForensicTracker()
            results = forensic_tracker.digital_footprint_analysis(target_url)

        elif scan_type == 'threat_intelligence':
            forensic_tracker = CyberForensicTracker()
            results = forensic_tracker.threat_intelligence(target_url)

        elif scan_type == 'forensic_analysis':
            forensic_tracker = CyberForensicTracker()
            results = forensic_tracker.digital_footprint_analysis(target_url)
        # ======================================

        else:
            results = {'error': 'Unknown scan type'}
        
        conn.execute('''
            UPDATE scan_results 
            SET results = ?, status = ? 
            WHERE id = ?
        ''', (json.dumps(results), 'completed', scan_id))
        
    except Exception as e:
        conn.execute('''
            UPDATE scan_results 
            SET results = ?, status = ? 
            WHERE id = ?
        ''', (json.dumps({'error': str(e)}), 'failed', scan_id))
    
    conn.commit()
    conn.close()

@app.route('/scan-results/<int:scan_id>')
def scan_results(scan_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scan = conn.execute('''
        SELECT * FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        flash('Scan not found!', 'error')
        return redirect(url_for('dashboard'))
    
    results = json.loads(scan['results']) if scan['results'] else {}
    return render_template('scan_results.html', scan=scan, results=results)

@app.route('/download-pdf/<int:scan_id>')
def download_pdf(scan_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    scan = conn.execute('''
        SELECT * FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        flash('Scan not found!', 'error')
        return redirect(url_for('dashboard'))
    
    results = json.loads(scan['results']) if scan['results'] else {}
    
    pdf_gen = PDFReportGenerator()
    filename = f"ghost_tester_report_{scan_id}.pdf"
    filepath = os.path.join('exports', filename)
    
    os.makedirs('exports', exist_ok=True)
    
    try:
        pdf_gen.generate_scan_report(dict(scan), results, filepath)
        return send_file(filepath, as_attachment=True, download_name=filename)
    except Exception as e:
        flash(f'Error generating PDF: {e}', 'error')
        return redirect(url_for('scan_results', scan_id=scan_id))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'info')
    return redirect(url_for('index'))

@app.route('/api/scan-status/<int:scan_id>')
def scan_status(scan_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    conn = get_db()
    scan = conn.execute('''
        SELECT id, status, target_url, scan_type, created_at 
        FROM scan_results 
        WHERE id = ? AND user_id = ?
    ''', (scan_id, session['user_id'])).fetchone()
    conn.close()
    
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    
    return jsonify(dict(scan))

if __name__ == '__main__':
    os.makedirs('exports', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    os.makedirs('backups', exist_ok=True)
    os.makedirs('user_uploads', exist_ok=True)
    os.makedirs('templates', exist_ok=True)
    
    print("🚀 GHOST TESTER ADVANCED PLATFORM STARTING...")
    print("🔧 Integrated Tools:")
    print("   ✅ SQL Injection Scanner")
    print("   ✅ Full Penetration Testing")
    print("   ✅ Credential Cracking")
    print("   ✅ Advanced Nmap Scanning")
    print("   ✅ Login Parameter Detection")
    print("   ✅ Subdomain Enumeration")
    print("   ✅ WAF Detection")
    print("   ✅ Comprehensive Security Audit")
    print("   ✅ Advanced User Registration & Verification")
    print("   ✅ reCAPTCHA Integration")
    print("   ✅ PDF Registration Form Generator")
    print("   ✅ CYBER FORENSIC TRACKER")
    print("   ✅ IP GEOLOCATION & WHOIS")
    print("   ✅ DIGITAL FOOTPRINT ANALYSIS")
    print("   ✅ THREAT INTELLIGENCE")
    print("   ✅ ETHICAL RANSOMWARE SIMULATION")
    
    print("🔧 Testing email configuration...")
    print(f"SMTP Server: {EMAIL_CONFIG.get('smtp_server')}")
    print(f"Port: {EMAIL_CONFIG.get('port')}")
    print(f"Sender Email: {EMAIL_CONFIG.get('sender_email')}")
    print(f"Password configured: {'YES' if EMAIL_CONFIG.get('password') else 'NO'}")
    
    try:
        server = smtplib.SMTP(EMAIL_CONFIG['smtp_server'], EMAIL_CONFIG['port'])
        server.starttls()
        server.login(EMAIL_CONFIG['sender_email'], EMAIL_CONFIG['password'])
        print("✅ Email connection successful!")
        server.quit()
    except Exception as e:
        print(f"❌ Email connection failed: {e}")
    
    print("🌍 Server running on http://127.0.0.1:5000")
    
    app.run(host='127.0.0.1', port=5000, debug=True)
