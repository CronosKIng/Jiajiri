"""
OSINT DIGITAL FOOTPRINT TRACKER
Integrated with Ghost Tester System
"""

import sqlite3
import requests
import json
import hashlib
import re
from datetime import datetime
from urllib.parse import urlparse, quote
import dns.resolver

class OSINTDigitalTracker:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.setup_database()
        
    def setup_database(self):
        """Setup database for storing OSINT intelligence"""
        self.conn = sqlite3.connect('ghost_tester_advanced.db', check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        # Create OSINT tables if they don't exist
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS osint_targets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                email TEXT,
                phone TEXT,
                target_hash TEXT UNIQUE,
                first_seen DATETIME,
                last_seen DATETIME,
                risk_score INTEGER,
                status TEXT DEFAULT 'active',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS osint_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_hash TEXT,
                platform TEXT,
                platform_exists BOOLEAN,
                url TEXT,
                details TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (target_hash) REFERENCES osint_targets (target_hash)
            )
        ''')
        
        self.conn.commit()

    def generate_target_hash(self, identifier):
        """Generate unique hash for target tracking"""
        return hashlib.md5(identifier.encode()).hexdigest()

    def search_username_across_platforms(self, username):
        """Search username across social media platforms"""
        platforms = {
            'GitHub': f'https://github.com/{username}',
            'Twitter': f'https://twitter.com/{username}',
            'Instagram': f'https://instagram.com/{username}',
            'Facebook': f'https://facebook.com/{username}',
            'LinkedIn': f'https://linkedin.com/in/{username}',
            'Reddit': f'https://reddit.com/user/{username}',
            'YouTube': f'https://youtube.com/@{username}',
            'TikTok': f'https://tiktok.com/@{username}'
        }
        
        results = {}
        for platform, url in platforms.items():
            try:
                response = self.session.get(url, timeout=5, allow_redirects=False)
                if response.status_code == 200:
                    results[platform] = {'url': url, 'exists': True, 'status': 'Active'}
                elif response.status_code == 404:
                    results[platform] = {'url': url, 'exists': False, 'status': 'Not found'}
                else:
                    results[platform] = {'url': url, 'exists': 'Unknown', 'status': f'HTTP {response.status_code}'}
            except Exception as e:
                results[platform] = {'url': url, 'exists': 'Error', 'status': str(e)}
        
        return results

    def analyze_digital_footprint(self, identifiers, user_id=None):
        """Comprehensive digital footprint analysis"""
        print(f"🔍 Starting OSINT analysis for: {identifiers}")
        
        profile = {
            'identifiers': identifiers,
            'platform_presence': {},
            'breach_history': {},
            'risk_assessment': {},
            'tracking_recommendations': [],
            'analysis_timestamp': datetime.now().isoformat()
        }
        
        # Check each identifier
        for identifier_type, identifier_value in identifiers.items():
            if identifier_type == 'username':
                profile['platform_presence'] = self.search_username_across_platforms(identifier_value)
        
        # Risk assessment
        active_platforms = sum(1 for p in profile['platform_presence'].values() if p.get('exists') == True)
        risk_score = active_platforms * 10
        
        if risk_score >= 40:
            risk_level = "🚨 HIGH"
            priority = "IMMEDIATE"
        elif risk_score >= 20:
            risk_level = "⚠️ MEDIUM"
            priority = "HIGH"
        else:
            risk_level = "✅ LOW" 
            priority = "MONITOR"
        
        profile['risk_assessment'] = {
            'risk_score': risk_score,
            'risk_level': risk_level,
            'priority': priority,
            'active_platforms': active_platforms
        }
        
        # Generate recommendations
        if active_platforms > 0:
            profile['tracking_recommendations'].extend([
                "🔍 Monitor social media activity patterns",
                "📊 Analyze posting frequency and timing",
                "🌐 Check for connected accounts and networks",
                "🕒 Track activity hours for behavioral analysis"
            ])
        
        # Store results in database
        self.store_osint_results(identifiers, profile, user_id)
        
        return {
            'status': 'completed',
            'digital_profile': profile,
            'summary': {
                'platforms_checked': len(profile['platform_presence']),
                'active_platforms': active_platforms,
                'risk_level': risk_level,
                'breach_status': False,
                'priority': priority
            }
        }

    def store_osint_results(self, identifiers, profile, user_id):
        """Store OSINT results in database"""
        try:
            target_hash = self.generate_target_hash(str(identifiers))
            
            # Insert/update target
            self.cursor.execute('''
                INSERT OR REPLACE INTO osint_targets 
                (user_id, username, email, phone, target_hash, first_seen, last_seen, risk_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user_id,
                identifiers.get('username'),
                identifiers.get('email'), 
                identifiers.get('phone'),
                target_hash,
                datetime.now(),
                datetime.now(),
                profile['risk_assessment']['risk_score']
            ))
            
            # Store platform results
            for platform, data in profile['platform_presence'].items():
                self.cursor.execute('''
                    INSERT INTO osint_results 
                    (target_hash, platform, platform_exists, url, details)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    target_hash,
                    platform,
                    data.get('exists'),
                    data.get('url'),
                    json.dumps(data)
                ))
            
            self.conn.commit()
            print(f"✅ OSINT results stored for target: {identifiers}")
            
        except Exception as e:
            print(f"❌ Database storage error: {e}")

    def get_user_osint_history(self, user_id):
        """Get OSINT history for a user"""
        try:
            self.cursor.execute('''
                SELECT * FROM osint_targets 
                WHERE user_id = ? 
                ORDER BY last_seen DESC 
                LIMIT 10
            ''', (user_id,))
            
            targets = self.cursor.fetchall()
            return targets
            
        except Exception as e:
            print(f"❌ Error fetching OSINT history: {e}")
            return []
