import requests
import json
import re
import hashlib
import time
from datetime import datetime, timedelta
import os
import sqlite3
from urllib.parse import urlparse, quote
import dns.resolver

class AdvancedOSINTTracker:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.setup_database()
        
    def setup_database(self):
        """Setup database for storing target intelligence"""
        self.conn = sqlite3.connect('osint_intelligence.db', check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS targets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                email TEXT,
                phone TEXT,
                target_hash TEXT UNIQUE,
                first_seen DATETIME,
                last_seen DATETIME,
                vpn_detected BOOLEAN,
                behavior_patterns TEXT,
                risk_score INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS activities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_hash TEXT,
                activity_type TEXT,
                platform TEXT,
                details TEXT,
                timestamp DATETIME,
                ip_address TEXT,
                location_data TEXT,
                FOREIGN KEY (target_hash) REFERENCES targets (target_hash)
            )
        ''')
        
        self.conn.commit()

    def generate_target_hash(self, identifier):
        """Generate unique hash for target tracking"""
        return hashlib.md5(identifier.encode()).hexdigest()

    # ==================== USERNAME & EMAIL OSINT ====================

    def search_username_across_platforms(self, username):
        """Search username across multiple platforms"""
        platforms = {
            'GitHub': f'https://github.com/{username}',
            'Twitter': f'https://twitter.com/{username}',
            'Instagram': f'https://instagram.com/{username}',
            'Facebook': f'https://facebook.com/{username}',
            'LinkedIn': f'https://linkedin.com/in/{username}',
            'Reddit': f'https://reddit.com/user/{username}',
            'YouTube': f'https://youtube.com/@{username}',
            'TikTok': f'https://tiktok.com/@{username}'
        }
        
        results = {}
        for platform, url in platforms.items():
            try:
                response = self.session.get(url, timeout=5, allow_redirects=False)
                if response.status_code == 200:
                    results[platform] = {
                        'url': url,
                        'exists': True,
                        'status': 'Active'
                    }
                elif response.status_code == 404:
                    results[platform] = {
                        'url': url,
                        'exists': False,
                        'status': 'Not found'
                    }
                else:
                    results[platform] = {
                        'url': url,
                        'exists': 'Unknown',
                        'status': f'HTTP {response.status_code}'
                    }
            except Exception as e:
                results[platform] = {
                    'url': url,
                    'exists': 'Error',
                    'status': str(e)
                }
        
        return results

    def email_breach_check(self, email):
        """Check if email appears in known data breaches"""
        try:
            # Using Have I Been Pwned API (anonymous)
            url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{quote(email)}"
            headers = {
                'User-Agent': 'EthicalOSINT-Tracker-v1.0',
                'hibp-api-key': ''  # Free tier doesn't require key for limited requests
            }
            
            response = self.session.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                breaches = response.json()
                return {
                    'breached': True,
                    'breach_count': len(breaches),
                    'breaches': [b['Name'] for b in breaches],
                    'message': f'Email found in {len(breaches)} data breaches'
                }
            elif response.status_code == 404:
                return {
                    'breached': False,
                    'breach_count': 0,
                    'breaches': [],
                    'message': 'Email not found in known breaches'
                }
            else:
                return {'breached': 'Unknown', 'message': 'API limit or error'}
                
        except Exception as e:
            return {'breached': 'Error', 'message': str(e)}

    def domain_intelligence(self, domain):
        """Gather intelligence about a domain"""
        try:
            # WHOIS-like information (using external APIs)
            domain_info = {}
            
            # DNS information
            try:
                a_records = dns.resolver.resolve(domain, 'A')
                domain_info['ip_addresses'] = [str(ip) for ip in a_records]
            except:
                domain_info['ip_addresses'] = []
            
            try:
                mx_records = dns.resolver.resolve(domain, 'MX')
                domain_info['mail_servers'] = [str(mx.exchange) for mx in mx_records]
            except:
                domain_info['mail_servers'] = []
            
            # SSL certificate info (basic)
            try:
                import ssl
                context = ssl.create_default_context()
                with socket.create_connection((domain, 443), timeout=5) as sock:
                    with context.wrap_socket(sock, server_hostname=domain) as ssock:
                        cert = ssock.getpeercert()
                        domain_info['ssl_issuer'] = dict(x[0] for x in cert['issuer'])['organizationName']
                        domain_info['ssl_valid_from'] = cert['notBefore']
                        domain_info['ssl_valid_to'] = cert['notAfter']
            except:
                domain_info['ssl_info'] = 'Not available'
            
            return domain_info
            
        except Exception as e:
            return {'error': f'Domain intelligence failed: {str(e)}'}

    # ==================== BEHAVIORAL PATTERN ANALYSIS ====================

    def analyze_behavioral_patterns(self, target_data):
        """Analyze behavioral patterns for tracking"""
        patterns = {
            'activity_times': [],
            'common_platforms': [],
            'content_interests': [],
            'posting_frequency': 'Unknown',
            'behavior_consistency': 'Unknown'
        }
        
        # Analyze activity times (if available)
        if 'activities' in target_data:
            activities = target_data['activities']
            times = [datetime.fromisoformat(a['timestamp'].replace('Z', '+00:00')).hour for a in activities if 'timestamp' in a]
            if times:
                patterns['activity_times'] = sorted(set(times))
                patterns['likely_timezone'] = self.estimate_timezone(times)
        
        # Analyze platform preferences
        if 'platform_activity' in target_data:
            platforms = target_data['platform_activity']
            patterns['common_platforms'] = [p for p, count in platforms.items() if count > 2]
        
        return patterns

    def estimate_timezone(self, activity_hours):
        """Estimate timezone based on activity patterns"""
        if not activity_hours:
            return "Unknown"
        
        # Simple timezone estimation based on activity peaks
        hour_counts = {}
        for hour in activity_hours:
            hour_counts[hour] = hour_counts.get(hour, 0) + 1
        
        peak_hour = max(hour_counts, key=hour_counts.get)
        
        # Map peak hour to likely timezone (simplified)
        if 6 <= peak_hour <= 18:  # Daytime activity
            return "Likely local daytime (9 AM - 9 PM)"
        else:  # Evening/night activity
            return "Likely evening/night owl"
        
        return "Unknown"

    # ==================== DIGITAL FOOTPRINT CORRELATION ====================

    def correlate_digital_identity(self, identifiers):
        """Correlate multiple identifiers to build digital profile"""
        profile = {
            'identifiers': identifiers,
            'platform_presence': {},
            'breach_history': {},
            'behavioral_patterns': {},
            'risk_assessment': {},
            'tracking_recommendations': []
        }
        
        # Check each identifier
        for identifier_type, identifier_value in identifiers.items():
            if identifier_type == 'username':
                profile['platform_presence'] = self.search_username_across_platforms(identifier_value)
            
            elif identifier_type == 'email':
                profile['breach_history'] = self.email_breach_check(identifier_value)
                
                # Extract possible username from email
                email_username = identifier_value.split('@')[0]
                profile['platform_presence'].update(
                    self.search_username_across_platforms(email_username)
                )
            
            elif identifier_type == 'phone':
                profile['phone_carrier'] = self.analyze_phone_number(identifier_value)
        
        # Behavioral analysis
        profile['behavioral_patterns'] = self.analyze_behavioral_patterns(profile)
        
        # Risk assessment
        profile['risk_assessment'] = self.assess_risk_level(profile)
        
        # Tracking recommendations
        profile['tracking_recommendations'] = self.generate_tracking_recommendations(profile)
        
        # Store in database
        self.store_target_intelligence(identifiers, profile)
        
        return profile

    def analyze_phone_number(self, phone_number):
        """Basic phone number analysis (carrier, country)"""
        # Remove non-digit characters
        clean_phone = re.sub(r'\D', '', phone_number)
        
        # Simple country code detection
        country_codes = {
            '255': 'Tanzania',
            '254': 'Kenya', 
            '256': 'Uganda',
            '250': 'Rwanda',
            '257': 'Burundi',
            '211': 'South Sudan',
            '27': 'South Africa',
            '234': 'Nigeria',
            '233': 'Ghana',
            '20': 'Egypt'
        }
        
        country = "Unknown"
        for code, country_name in country_codes.items():
            if clean_phone.startswith(code):
                country = country_name
                break
        
        return {
            'clean_number': clean_phone,
            'likely_country': country,
            'analysis': 'Basic carrier detection available with premium services'
        }

    def assess_risk_level(self, profile):
        """Assess risk level based on digital footprint"""
        risk_score = 0
        risk_factors = []
        
        # Platform presence factor
        active_platforms = sum(1 for p in profile['platform_presence'].values() if p.get('exists') == True)
        if active_platforms > 3:
            risk_score += 20
            risk_factors.append(f"Active on {active_platforms} platforms")
        
        # Breach history factor
        if profile['breach_history'].get('breached'):
            risk_score += 30
            risk_factors.append(f"Email in {profile['breach_history'].get('breach_count', 0)} breaches")
        
        # Behavioral patterns factor
        if profile['behavioral_patterns'].get('activity_times'):
            risk_score += 10
            risk_factors.append("Clear behavioral patterns detected")
        
        # Determine risk level
        if risk_score >= 40:
            risk_level = "🚨 HIGH"
            investigation_priority = "🚨 IMMEDIATE"
        elif risk_score >= 20:
            risk_level = "⚠️ MEDIUM" 
            investigation_priority = "🔍 HIGH PRIORITY"
        else:
            risk_level = "📋 LOW"
            investigation_priority = "👀 MONITOR"
        
        return {
            'risk_score': risk_score,
            'risk_level': risk_level,
            'risk_factors': risk_factors,
            'investigation_priority': investigation_priority
        }

    def generate_tracking_recommendations(self, profile):
        """Generate tracking recommendations based on profile"""
        recommendations = []
        
        # Platform-based recommendations
        active_platforms = [p for p, data in profile['platform_presence'].items() if data.get('exists') == True]
        
        if 'GitHub' in active_platforms:
            recommendations.append("🔍 Monitor GitHub for code patterns and project interests")
        if 'Twitter' in active_platforms:
            recommendations.append("🐦 Analyze Twitter for real-time activity and connections")
        if 'Instagram' in active_platforms:
            recommendations.append("📸 Check Instagram for location tags and visual content")
        if 'LinkedIn' in active_platforms:
            recommendations.append("💼 Review LinkedIn for professional background and network")
        
        # Behavioral recommendations
        if profile['behavioral_patterns'].get('activity_times'):
            peak_hours = profile['behavioral_patterns']['activity_times']
            recommendations.append(f"🕒 Focus monitoring during hours: {', '.join(map(str, peak_hours))}")
        
        # General recommendations
        recommendations.extend([
            "🌐 Correlate findings with network traffic patterns",
            "📧 Check for password reuse across platforms",
            "🔗 Look for connected accounts and social graphs",
            "📱 Monitor for mobile app usage patterns"
        ])
        
        return recommendations

    def store_target_intelligence(self, identifiers, profile):
        """Store target intelligence in database"""
        try:
            target_hash = self.generate_target_hash(str(identifiers))
            
            # Insert/update target
            self.cursor.execute('''
                INSERT OR REPLACE INTO targets 
                (username, email, phone, target_hash, first_seen, last_seen, vpn_detected, behavior_patterns, risk_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                identifiers.get('username'),
                identifiers.get('email'), 
                identifiers.get('phone'),
                target_hash,
                datetime.now(),
                datetime.now(),
                False,  # VPN detection would be updated separately
                json.dumps(profile['behavioral_patterns']),
                profile['risk_assessment']['risk_score']
            ))
            
            # Store platform activities
            for platform, data in profile['platform_presence'].items():
                if data.get('exists') == True:
                    self.cursor.execute('''
                        INSERT INTO activities 
                        (target_hash, activity_type, platform, details, timestamp, ip_address, location_data)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        target_hash,
                        'Platform Presence',
                        platform,
                        json.dumps(data),
                        datetime.now(),
                        'N/A',  # IP would come from network monitoring
                        'N/A'   # Location from IP analysis
                    ))
            
            self.conn.commit()
            
        except Exception as e:
            print(f"Database storage error: {e}")

    # ==================== COMPREHENSIVE OSINT ANALYSIS ====================

    def comprehensive_osint_analysis(self, identifiers):
        """Comprehensive OSINT analysis with behavioral tracking"""
        print("🕵️‍♂️ Starting comprehensive OSINT analysis...")
        print("=" * 60)
        
        # Validate input
        if not any(identifiers.values()):
            return {"error": "At least one identifier (username, email, or phone) is required"}
        
        # Step 1: Digital footprint correlation
        print("📊 Correlating digital identity...")
        profile = self.correlate_digital_identity(identifiers)
        
        # Step 2: Behavioral analysis
        print("🔍 Analyzing behavioral patterns...")
        
        # Step 3: Risk assessment
        print("🎯 Assessing risk level...")
        
        return {
            "status": "completed",
            "analysis_timestamp": datetime.now().isoformat(),
            "identifiers_analyzed": identifiers,
            "digital_profile": profile,
            "summary": {
                "platforms_checked": len(profile['platform_presence']),
                "active_platforms": sum(1 for p in profile['platform_presence'].values() if p.get('exists') == True),
                "breach_status": profile['breach_history'].get('breached', False),
                "risk_level": profile['risk_assessment']['risk_level']
            }
        }


# ==================== MAIN EXECUTION ====================

def main():
    print("🌐 ADVANCED OSINT & BEHAVIORAL TRACKING SYSTEM")
    print("==============================================")
    print("⚠️  LEGAL DISCLAIMER: Use only for authorized:")
    print("   - Ethical penetration testing")
    print("   - Criminal investigations (with proper authority)") 
    print("   - Personal security research (on your own data)")
    print("==============================================")
    
    tracker = AdvancedOSINTTracker()
    
    while True:
        print("\n🎯 Enter target identifiers (leave blank to skip):")
        
        username = input("Username: ").strip()
        email = input("Email: ").strip()
        phone = input("Phone: ").strip()
        
        if not any([username, email, phone]):
            print("❌ Please provide at least one identifier")
            continue
        
        identifiers = {
            'username': username,
            'email': email,
            'phone': phone
        }
        
        print(f"\n🔍 Starting OSINT analysis...")
        print("=" * 50)
        
        result = tracker.comprehensive_osint_analysis(identifiers)
        
        if result.get("error"):
            print(f"❌ {result['error']}")
            continue
        
        profile = result.get("digital_profile", {})
        summary = result.get("summary", {})
        
        # Display results
        print(f"\n📊 DIGITAL FOOTPRINT SUMMARY:")
        print(f"   📧 Email Breach Check: {'🔴 BREACHED' if summary.get('breach_status') else '✅ CLEAN'}")
        print(f"   🌐 Platforms Active: {summary.get('active_platforms', 0)}/{summary.get('platforms_checked', 0)}")
        print(f"   🎯 Risk Level: {summary.get('risk_level', 'Unknown')}")
        
        print(f"\n🔎 PLATFORM PRESENCE:")
        platform_data = profile.get('platform_presence', {})
        for platform, data in platform_data.items():
            status = "✅ ACTIVE" if data.get('exists') == True else "❌ NOT FOUND" if data.get('exists') == False else "❓ UNKNOWN"
            print(f"   {platform}: {status}")
        
        print(f"\n🛡️ RISK ASSESSMENT:")
        risk_data = profile.get('risk_assessment', {})
        print(f"   📈 Risk Score: {risk_data.get('risk_score', 0)}/100")
        print(f"   ⚠️  Risk Factors: {', '.join(risk_data.get('risk_factors', []))}")
        print(f"   🚨 Priority: {risk_data.get('investigation_priority', 'Unknown')}")
        
        print(f"\n💡 TRACKING RECOMMENDATIONS:")
        for i, recommendation in enumerate(profile.get('tracking_recommendations', []), 1):
            print(f"   {i}. {recommendation}")
        
        print(f"\n📁 Data stored in: osint_intelligence.db")
        print(f"🕒 Analysis completed: {result.get('analysis_timestamp', 'Unknown')}")
        print("=" * 50)
        
        # Ask to continue
        cont = input("\n🔍 Analyze another target? (y/n): ").strip().lower()
        if cont != 'y':
            break

if __name__ == "__main__":
    main()
