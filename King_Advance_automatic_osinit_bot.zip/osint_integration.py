"""
OSINT TRACKER INTEGRATION FOR GHOST TESTER SYSTEM
Integrated with existing forensic and penetration testing modules
"""

import sqlite3
import json
from datetime import datetime

class OSINTIntegration:
    def __init__(self):
        self.ghost_db = 'ghost_tester.db'
        self.advanced_db = 'ghost_tester_advanced.db' 
        self.osint_db = 'osint_intelligence.db'
        
    def connect_ghost_database(self):
        """Connect to existing Ghost Tester database"""
        try:
            conn = sqlite3.connect(self.ghost_db)
            return conn
        except:
            return None
            
    def connect_advanced_database(self):
        """Connect to advanced database"""
        try:
            conn = sqlite3.connect(self.advanced_db)
            return conn
        except:
            return None
            
    def get_recent_targets(self):
        """Get recent targets from existing system"""
        targets = []
        
        # Try ghost_tester.db first
        conn = self.connect_ghost_database()
        if conn:
            try:
                cursor = conn.cursor()
                # Look for common target tables
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%target%' OR name LIKE '%scan%'")
                tables = cursor.fetchall()
                
                for table in tables:
                    try:
                        cursor.execute(f"SELECT * FROM {table[0]} LIMIT 5")
                        rows = cursor.fetchall()
                        if rows:
                            targets.extend(rows)
                    except:
                        continue
            except:
                pass
            finally:
                conn.close()
                
        return targets
        
    def integrate_with_forensic_tracker(self, target_data):
        """Integrate with existing forensic tracker"""
        try:
            from cyber_forensic_tracker import CyberForensicTracker
            tracker = CyberForensicTracker()
            
            # If target has IP, do forensic analysis
            if 'ip_address' in target_data:
                forensic_result = tracker.comprehensive_forensic_analysis(target_data['ip_address'])
                return forensic_result
        except ImportError:
            return {"error": "Forensic tracker not available"}
            
    def create_unified_report(self, target_identifier):
        """Create unified report combining OSINT and existing system data"""
        report = {
            "target": target_identifier,
            "timestamp": datetime.now().isoformat(),
            "data_sources": [],
            "findings": {}
        }
        
        # Get OSINT data
        try:
            from advanced_osint_tracker import AdvancedOSINTTracker
            osint_tracker = AdvancedOSINTTracker()
            osint_result = osint_tracker.comprehensive_osint_analysis({
                'username': target_identifier if not '.' in target_identifier else None,
                'email': target_identifier if '@' in target_identifier else None
            })
            report["findings"]["osint"] = osint_result
            report["data_sources"].append("OSINT Tracker")
        except ImportError:
            report["findings"]["osint"] = {"error": "OSINT tracker not available"}
            
        # Get forensic data if it's an IP
        if '.' in target_identifier and len(target_identifier.split('.')) == 4:
            try:
                forensic_data = self.integrate_with_forensic_tracker({'ip_address': target_identifier})
                report["findings"]["forensic"] = forensic_data
                report["data_sources"].append("Forensic Tracker")
            except:
                report["findings"]["forensic"] = {"error": "Forensic analysis failed"}
                
        return report

def main():
    """Main integration test"""
    integration = OSINTIntegration()
    
    print("🔗 OSINT INTEGRATION WITH GHOST TESTER")
    print("=====================================")
    
    # Test database connections
    ghost_conn = integration.connect_ghost_database()
    advanced_conn = integration.connect_advanced_database()
    
    print(f"✅ Ghost DB Connection: {'Success' if ghost_conn else 'Failed'}")
    print(f"✅ Advanced DB Connection: {'Success' if advanced_conn else 'Failed'}")
    
    # Get recent targets
    targets = integration.get_recent_targets()
    print(f"📊 Recent targets in system: {len(targets)}")
    
    # Test unified report
    test_target = "example_user"
    report = integration.create_unified_report(test_target)
    print(f"📄 Unified report created for: {test_target}")
    print(f"📋 Data sources: {report['data_sources']}")

if __name__ == "__main__":
    main()
