#!/usr/bin/env python3
"""
UNIFIED OSINT LAUNCHER FOR GHOST TESTER
Provides seamless integration with existing system
"""

import sys
import os

def main():
    print("🎯 GHOST TESTER - UNIFIED OSINT LAUNCHER")
    print("========================================")
    print("1. OSINT Target Analysis")
    print("2. Forensic IP Analysis") 
    print("3. Unified Report (OSINT + Forensic)")
    print("4. Integration Test")
    print("5. Exit")
    
    choice = input("\nSelect option (1-5): ").strip()
    
    if choice == "1":
        # OSINT Analysis
        try:
            from advanced_osint_tracker import AdvancedOSINTTracker
            tracker = AdvancedOSINTTracker()
            
            print("\n🔍 OSINT TARGET ANALYSIS")
            print("----------------------")
            username = input("Username: ").strip()
            email = input("Email (optional): ").strip()
            phone = input("Phone (optional): ").strip()
            
            identifiers = {}
            if username: identifiers['username'] = username
            if email: identifiers['email'] = email  
            if phone: identifiers['phone'] = phone
            
            if not identifiers:
                print("❌ Please provide at least one identifier")
                return
                
            result = tracker.comprehensive_osint_analysis(identifiers)
            print(f"\n✅ OSINT Analysis Complete!")
            print(f"📊 Platforms Found: {result.get('summary', {}).get('active_platforms', 0)}")
            print(f"🎯 Risk Level: {result.get('summary', {}).get('risk_level', 'Unknown')}")
            
        except ImportError as e:
            print(f"❌ OSINT tracker not available: {e}")
            
    elif choice == "2":
        # Forensic Analysis
        try:
            from cyber_forensic_tracker import CyberForensicTracker
            tracker = CyberForensicTracker()
            
            print("\n🔍 FORENSIC IP ANALYSIS")
            print("---------------------")
            ip_address = input("IP Address: ").strip()
            
            if not ip_address:
                print("❌ Please provide an IP address")
                return
                
            result = tracker.comprehensive_forensic_analysis(ip_address)
            analysis = result.get("comprehensive_analysis", {})
            
            print(f"\n✅ Forensic Analysis Complete!")
            print(f"📍 Location: {analysis.get('geolocation', {}).get('country', 'Unknown')}")
            print(f"🛡️ Threat Level: {analysis.get('threat_intelligence', {}).get('threat_level', 'Unknown')}")
            
        except ImportError as e:
            print(f"❌ Forensic tracker not available: {e}")
            
    elif choice == "3":
        # Unified Report
        try:
            from osint_integration import OSINTIntegration
            integration = OSINTIntegration()
            
            print("\n🔗 UNIFIED OSINT + FORENSIC ANALYSIS")
            print("-----------------------------------")
            target = input("Enter target (username, email, or IP): ").strip()
            
            if not target:
                print("❌ Please provide a target")
                return
                
            report = integration.create_unified_report(target)
            
            print(f"\n✅ Unified Report Generated!")
            print(f"📋 Data Sources: {', '.join(report['data_sources'])}")
            print(f"📄 Findings saved in integrated database")
            
        except ImportError as e:
            print(f"❌ Integration module not available: {e}")
            
    elif choice == "4":
        # Integration Test
        try:
            from osint_integration import OSINTIntegration
            integration = OSINTIntegration()
            integration.main()
        except ImportError as e:
            print(f"❌ Integration test failed: {e}")
            
    elif choice == "5":
        print("👋 Exiting...")
        sys.exit(0)
        
    else:
        print("❌ Invalid choice")

if __name__ == "__main__":
    main()
