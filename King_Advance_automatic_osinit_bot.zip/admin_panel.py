#!/usr/bin/env python3
"""
Admin Panel for Ethical Ghost Tester
"""

import sqlite3
import os
from datetime import datetime

def admin_panel():
    """Simple admin panel to view database"""
    db_path = 'ghost_tester_advanced.db'
    
    if not os.path.exists(db_path):
        print("❌ Database file not found!")
        return
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    while True:
        print("\n" + "="*60)
        print("👑 ETHICAL GHOST TESTER - ADMIN PANEL")
        print("="*60)
        print("1. View All Users")
        print("2. View User Details")
        print("3. View Scan Results")
        print("4. View Oath Agreements")
        print("5. Database Statistics")
        print("6. Exit")
        print("="*60)
        
        choice = input("Choose option (1-6): ").strip()
        
        if choice == '1':
            # View all users
            print("\n📋 ALL REGISTERED USERS:")
            print("-" * 80)
            users = c.execute('''
                SELECT id, username, email, full_name, phone_number, 
                       account_verified, created_at 
                FROM users ORDER BY created_at DESC
            ''').fetchall()
            
            if users:
                print(f"{'ID':<3} {'Username':<15} {'Email':<20} {'Full Name':<20} {'Verified':<8} {'Created'}")
                print("-" * 80)
                for user in users:
                    verified = "✅" if user['account_verified'] else "❌"
                    created = user['created_at'][:16] if user['created_at'] else "N/A"
                    print(f"{user['id']:<3} {user['username']:<15} {user['email']:<20} {user['full_name']:<20} {verified:<8} {created}")
            else:
                print("❌ No users found!")
                
        elif choice == '2':
            # View specific user details
            user_id = input("Enter User ID: ").strip()
            if user_id.isdigit():
                user = c.execute('''
                    SELECT * FROM users WHERE id = ?
                ''', (user_id,)).fetchone()
                
                if user:
                    print(f"\n👤 USER DETAILS (ID: {user['id']}):")
                    print("-" * 40)
                    for key in user.keys():
                        if key != 'password':  # Don't show password
                            value = user[key] if user[key] else "Not set"
                            print(f"{key:25}: {value}")
                else:
                    print("❌ User not found!")
            else:
                print("❌ Invalid user ID!")
                
        elif choice == '3':
            # View scan results
            print("\n🔍 SCAN RESULTS:")
            print("-" * 80)
            scans = c.execute('''
                SELECT sr.id, u.username, sr.target_url, sr.scan_type, 
                       sr.status, sr.created_at 
                FROM scan_results sr
                JOIN users u ON sr.user_id = u.id
                ORDER BY sr.created_at DESC
                LIMIT 20
            ''').fetchall()
            
            if scans:
                print(f"{'ID':<3} {'User':<15} {'Target':<20} {'Type':<15} {'Status':<10} {'Created'}")
                print("-" * 80)
                for scan in scans:
                    created = scan['created_at'][:16] if scan['created_at'] else "N/A"
                    print(f"{scan['id']:<3} {scan['username']:<15} {scan['target_url'][:18]:<20} {scan['scan_type']:<15} {scan['status']:<10} {created}")
            else:
                print("❌ No scan results found!")
                
        elif choice == '4':
            # View oath agreements
            print("\n⚖️ OATH AGREEMENTS:")
            print("-" * 60)
            oaths = c.execute('''
                SELECT oa.id, u.username, u.full_name, oa.accepted_at 
                FROM oath_agreements oa
                JOIN users u ON oa.user_id = u.id
                ORDER BY oa.accepted_at DESC
            ''').fetchall()
            
            if oaths:
                print(f"{'ID':<3} {'Username':<15} {'Full Name':<20} {'Accepted'}")
                print("-" * 60)
                for oath in oaths:
                    accepted = oath['accepted_at'][:16] if oath['accepted_at'] else "N/A"
                    print(f"{oath['id']:<3} {oath['username']:<15} {oath['full_name']:<20} {accepted}")
                    
                # Show oath text for specific user
                oath_id = input("\nEnter Oath ID to view details (or press Enter to skip): ").strip()
                if oath_id.isdigit():
                    oath_detail = c.execute('''
                        SELECT oath_text FROM oath_agreements WHERE id = ?
                    ''', (oath_id,)).fetchone()
                    if oath_detail:
                        print(f"\n📜 OATH TEXT:")
                        print("-" * 40)
                        print(oath_detail['oath_text'])
            else:
                print("❌ No oath agreements found!")
                
        elif choice == '5':
            # Database statistics
            print("\n📊 DATABASE STATISTICS:")
            print("-" * 30)
            
            # User count
            user_count = c.execute('SELECT COUNT(*) as count FROM users').fetchone()['count']
            verified_count = c.execute('SELECT COUNT(*) as count FROM users WHERE account_verified = 1').fetchone()['count']
            
            # Scan count
            scan_count = c.execute('SELECT COUNT(*) as count FROM scan_results').fetchone()['count']
            completed_scans = c.execute('SELECT COUNT(*) as count FROM scan_results WHERE status = "completed"').fetchone()['count']
            
            # Oath count
            oath_count = c.execute('SELECT COUNT(*) as count FROM oath_agreements').fetchone()['count']
            
            print(f"👥 Total Users: {user_count}")
            print(f"✅ Verified Users: {verified_count}")
            print(f"❌ Unverified Users: {user_count - verified_count}")
            print(f"🔍 Total Scans: {scan_count}")
            print(f"✅ Completed Scans: {completed_scans}")
            print(f"⚖️ Oath Agreements: {oath_count}")
            
        elif choice == '6':
            print("👋 Exiting admin panel...")
            break
            
        else:
            print("❌ Invalid choice! Please select 1-6.")
        
        input("\nPress Enter to continue...")
    
    conn.close()

if __name__ == "__main__":
    admin_panel()
