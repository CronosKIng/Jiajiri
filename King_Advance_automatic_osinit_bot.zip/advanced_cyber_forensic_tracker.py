import requests
import json
import socket
import dns.resolver
import subprocess
import os
from datetime import datetime

class AdvancedCyberForensicTracker:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        # Free forensic APIs (no API key required)
        self.apis = {
            'ipapi': 'http://ip-api.com/json/',
            'ipapi_co': 'https://ipapi.co/{}/json/',
            'ipinfo': 'https://ipinfo.io/{}/json',
            'threatcrowd': 'https://www.threatcrowd.org/searchApi/v2/ip/report/?ip={}'
        }

    def validate_ip(self, ip_address):
        """Validate IP address format"""
        try:
            parts = ip_address.split('.')
            if len(parts) != 4:
                return False
            for part in parts:
                if not part.isdigit() or not 0 <= int(part) <= 255:
                    return False
            return True
        except:
            return False

    # ==================== VPN DETECTION METHODS ====================
    
    def detect_vpn_proxy(self, ip_address):
        """Detect if IP is using VPN/Proxy/Tor"""
        try:
            # VPN API.io (Free - no API key needed)
            vpn_response = self.session.get(f'https://vpnapi.io/api/{ip_address}', timeout=5)
            
            if vpn_response.status_code == 200:
                vpn_data = vpn_response.json()
                security = vpn_data.get('security', {})
                
                return {
                    "vpn": security.get('vpn', False),
                    "proxy": security.get('proxy', False),
                    "tor": security.get('tor', False),
                    "relay": security.get('relay', False),
                    "service": vpn_data.get('network', {}).get('autonomous_system_organization', 'Unknown'),
                    "vpn_confidence": "High" if security.get('vpn') else "Low"
                }
        except Exception as e:
            pass
        
        # Fallback: Check common VPN datacenter ranges
        vpn_indicators = self.check_vpn_behavioral(ip_address)
        return {
            "vpn": vpn_indicators["likely_vpn"],
            "proxy": "Unknown",
            "tor": "Unknown", 
            "relay": "Unknown",
            "service": vpn_indicators.get("hosting_company", "Unknown"),
            "vpn_confidence": vpn_indicators.get("confidence", "Medium")
        }

    def check_vpn_behavioral(self, ip_address):
        """Behavioral analysis for VPN detection"""
        # Known VPN/Proxy datacenter IP ranges
        vpn_ranges = [
            '194.68.', '195.181.', '209.95.', '216.244.', '185.107.', 
            '192.145.', '203.123.', '198.18.', '172.64.', '172.65.',
            '104.16.', '104.17.', '104.18.', '104.19.', '108.162.',
            '162.158.', '172.68.', '173.245.', '188.114.', '190.93.',
            '197.234.', '198.41.', '5.188.', '5.189.', '91.108.',
            '91.109.', '149.154.', '185.76.'  # Telegram & common VPNs
        ]
        
        hosting_companies = [
            'DIGITALOCEAN', 'AMAZON', 'GOOGLE', 'CLOUDFLARE', 'MICROSOFT',
            'OVH', 'LINODE', 'VULTR', 'HETZNER', 'ALIBABA'
        ]
        
        likely_vpn = False
        hosting_company = "Unknown"
        confidence = "Low"
        
        # Check if IP matches known VPN ranges
        for vpn_range in vpn_ranges:
            if ip_address.startswith(vpn_range):
                likely_vpn = True
                confidence = "High"
                break
        
        # Get ISP/organization info
        try:
            ip_data = self.get_real_ip_data(ip_address)
            isp = ip_data.get('isp', '').upper()
            org = ip_data.get('org', '').upper()
            
            # Check if ISP is known hosting/VPN provider
            for company in hosting_companies:
                if company in isp or company in org:
                    hosting_company = company
                    likely_vpn = True
                    confidence = "High"
                    break
                    
        except:
            pass
        
        return {
            "likely_vpn": likely_vpn,
            "hosting_company": hosting_company,
            "confidence": confidence,
            "analysis_method": "IP Range + ISP Analysis"
        }

    def check_dns_leaks(self, ip_address):
        """Check for DNS leaks that can reveal real location"""
        try:
            dns_servers = ['8.8.8.8', '1.1.1.1', '208.67.222.222']
            resolver = dns.resolver.Resolver()
            resolver.nameservers = dns_servers
            
            test_domains = ['google.com', 'whatsapp.com', 'facebook.com']
            resolved_ips = []
            
            for domain in test_domains:
                try:
                    answers = resolver.resolve(domain, 'A')
                    for rdata in answers:
                        resolved_ips.append(str(rdata))
                except:
                    continue
            
            return {
                "dns_servers_used": dns_servers,
                "resolved_ips": resolved_ips,
                "potential_leak": len(resolved_ips) > 0,
                "leak_risk": "High" if len(resolved_ips) > 2 else "Low"
            }
        except Exception as e:
            return {"error": f"DNS analysis failed: {str(e)}"}

    def timezone_analysis(self, ip_data, user_timezone=None):
        """Compare IP timezone with user behavior"""
        ip_timezone = ip_data.get('timezone', 'Unknown')
        
        analysis = {
            "ip_timezone": ip_timezone,
            "user_timezone": user_timezone or "Not provided",
            "mismatch_detected": False,
            "mismatch_reason": "None"
        }
        
        if user_timezone and user_timezone != "Not provided" and ip_timezone != "Unknown":
            # Simple timezone comparison
            if user_timezone != ip_timezone:
                analysis.update({
                    "mismatch_detected": True,
                    "mismatch_reason": f"User TZ ({user_timezone}) ≠ IP TZ ({ip_timezone})"
                })
        
        return analysis

    # ==================== EXISTING FORENSIC METHODS ====================

    def get_real_ip_data(self, ip_address):
        """Get REAL IP data from multiple free APIs"""
        if not self.validate_ip(ip_address):
            return {
                "ip_address": ip_address,
                "country": "Invalid IP",
                "city": "Invalid IP format", 
                "region": "Invalid IP format",
                "isp": "Invalid IP format",
                "org": "Invalid IP format",
                "asn": "Invalid IP format",
                "timezone": "Invalid IP format"
            }
        
        ip_data = {
            "ip_address": ip_address,
            "country": "Unknown",
            "city": "Unknown",
            "region": "Unknown", 
            "isp": "Unknown",
            "org": "Unknown",
            "asn": "Unknown",
            "timezone": "Unknown"
        }
        
        # Try multiple free APIs
        apis_to_try = [
            (f"http://ip-api.com/json/{ip_address}", 'ip-api.com'),
            (f"https://ipapi.co/{ip_address}/json/", 'ipapi.co'),
            (f"https://ipinfo.io/{ip_address}/json", 'ipinfo.io')
        ]
        
        for api_url, api_name in apis_to_try:
            try:
                response = self.session.get(api_url, timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    
                    if api_name == 'ip-api.com' and data.get('status') == 'success':
                        ip_data.update({
                            "country": data.get('country', 'Unknown'),
                            "city": data.get('city', 'Unknown'),
                            "region": data.get('regionName', 'Unknown'),
                            "isp": data.get('isp', 'Unknown'),
                            "org": data.get('org', 'Unknown'),
                            "asn": data.get('as', 'Unknown'),
                            "timezone": data.get('timezone', 'Unknown')
                        })
                        break
                    
                    elif api_name == 'ipapi.co':
                        ip_data.update({
                            "country": data.get('country_name', 'Unknown'),
                            "city": data.get('city', 'Unknown'),
                            "region": data.get('region', 'Unknown'),
                            "isp": data.get('org', 'Unknown'),
                            "asn": data.get('asn', 'Unknown'),
                            "timezone": data.get('timezone', 'Unknown')
                        })
                        break
                    
                    elif api_name == 'ipinfo.io':
                        ip_data.update({
                            "country": data.get('country', 'Unknown'),
                            "city": data.get('city', 'Unknown'),
                            "region": data.get('region', 'Unknown'),
                            "isp": data.get('org', 'Unknown'),
                            "asn": data.get('org', 'Unknown'),
                            "timezone": data.get('timezone', 'Unknown')
                        })
                        break
                        
            except Exception as e:
                continue
        
        return ip_data

    def get_threat_intelligence(self, ip_address):
        """Get REAL threat intelligence"""
        if not self.validate_ip(ip_address):
            return {
                "threat_level": "Invalid IP",
                "malicious_activity": "Invalid IP address format",
                "blacklist_status": "Not checked",
                "risk_score": "N/A",
                "reputation": "Invalid IP"
            }
        
        threat_data = {
            "threat_level": "Unknown",
            "malicious_activity": "No data available",
            "blacklist_status": "Not checked",
            "risk_score": "Unknown",
            "reputation": "Unknown"
        }
        
        # Try Threat Crowd API
        try:
            url = f"https://www.threatcrowd.org/searchApi/v2/ip/report/?ip={ip_address}"
            response = self.session.get(url, timeout=5)
            if response.status_code == 200:
                data = response.json()
                if data.get('response_code') == '1':
                    votes = data.get('votes', {})
                    threat_data.update({
                        "threat_level": "Suspicious" if votes.get('malicious', 0) > 0 else "Clean",
                        "malicious_activity": f"Malicious votes: {votes.get('malicious', 0)}",
                        "blacklist_status": "Listed" if votes.get('malicious', 0) > 0 else "Clean",
                        "risk_score": f"{votes.get('malicious', 0)}/10",
                        "reputation": "Poor" if votes.get('malicious', 0) > 2 else "Good"
                    })
        except:
            pass
        
        return threat_data

    def analyze_network_patterns(self, ip_address):
        """Analyze network patterns and potential usage"""
        if not self.validate_ip(ip_address):
            return {
                "traffic_volume": "Invalid IP",
                "common_ports": "Invalid IP format", 
                "service_types": "Invalid IP format",
                "activity_level": "Invalid IP format",
                "potential_usage": "Invalid IP format"
            }
        
        patterns = {
            "traffic_volume": "Unknown",
            "common_ports": "Unknown", 
            "service_types": "Unknown",
            "activity_level": "Unknown",
            "potential_usage": "Unknown"
        }
        
        # Basic port analysis
        try:
            common_ports = [80, 443, 22, 21, 25, 53, 110, 143]
            open_ports = []
            
            for port in common_ports[:3]:  # Check first 3 ports for speed
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    result = sock.connect_ex((ip_address, port))
                    if result == 0:
                        open_ports.append(port)
                    sock.close()
                except:
                    pass
            
            if open_ports:
                patterns.update({
                    "common_ports": str(open_ports),
                    "service_types": "Web services" if 80 in open_ports or 443 in open_ports else "Other services",
                    "activity_level": "Active" if len(open_ports) > 1 else "Low",
                    "potential_usage": "Web server" if 80 in open_ports else "General internet"
                })
            else:
                patterns.update({
                    "common_ports": "No common ports open",
                    "activity_level": "Low",
                    "potential_usage": "General internet access"
                })
                
        except Exception as e:
            patterns["potential_usage"] = "Analysis failed"
        
        return patterns

    # ==================== ADVANCED COMPREHENSIVE ANALYSIS ====================

    def advanced_forensic_analysis(self, target, user_timezone=None):
        """ADVANCED analysis with VPN detection and real tracking"""
        try:
            if not self.validate_ip(target):
                return {
                    "status": "completed",
                    "comprehensive_analysis": {
                        "target": target,
                        "error": "Invalid IP address format",
                        "valid_examples": ["8.8.8.8", "192.168.1.1", "197.186.2.130"],
                        "message": "Please enter a valid IP address"
                    },
                    "message": "Invalid IP address format"
                }
            
            print(f"🔍 Collecting basic IP data...")
            ip_data = self.get_real_ip_data(target)
            
            print(f"🛡️  Analyzing threat intelligence...")
            threat_data = self.get_threat_intelligence(target)
            
            print(f"📊 Checking network patterns...")
            patterns = self.analyze_network_patterns(target)
            
            print(f"🔎 Detecting VPN/Proxy usage...")
            vpn_detection = self.detect_vpn_proxy(target)
            
            print(f"🌐 Analyzing DNS patterns...")
            dns_analysis = self.check_dns_leaks(target)
            
            print(f"⏰ Checking timezone consistency...")
            timezone_analysis = self.timezone_analysis(ip_data, user_timezone)
            
            # ==================== RISK ASSESSMENT ====================
            risk_factors = []
            
            # VPN Risk
            if vpn_detection.get("vpn") == True:
                risk_factors.append("VPN Detected")
            if vpn_detection.get("proxy") == True:
                risk_factors.append("Proxy Detected")
            if vpn_detection.get("tor") == True:
                risk_factors.append("Tor Network")
                
            # Threat Risk
            if threat_data.get("threat_level") == "Suspicious":
                risk_factors.append("Suspicious Activity")
            if threat_data.get("reputation") == "Poor":
                risk_factors.append("Poor Reputation")
                
            # Behavioral Risk
            if timezone_analysis.get("mismatch_detected"):
                risk_factors.append("Timezone Mismatch")
                
            # DNS Risk
            if dns_analysis.get("leak_risk") == "High":
                risk_factors.append("DNS Leak Risk")
            
            # Calculate overall risk
            risk_score = len(risk_factors)
            if risk_score >= 3:
                risk_level = "🚨 HIGH RISK"
                investigation_priority = "🚨 IMMEDIATE"
            elif risk_score >= 2:
                risk_level = "⚠️ MEDIUM RISK" 
                investigation_priority = "🔍 HIGH PRIORITY"
            elif risk_score >= 1:
                risk_level = "📋 LOW RISK"
                investigation_priority = "👀 MONITOR"
            else:
                risk_level = "✅ CLEAN"
                investigation_priority = "✅ LOW PRIORITY"
            
            # ==================== TRACKING RECOMMENDATIONS ====================
            tracking_recommendations = []
            
            if vpn_detection.get("vpn"):
                tracking_recommendations.extend([
                    "📍 Focus on behavioral patterns rather than IP location",
                    "🕒 Analyze activity timestamps for timezone clues", 
                    "🌍 Check for language/country mismatches",
                    "📱 Look for mobile carrier leaks (if applicable)"
                ])
            else:
                tracking_recommendations.extend([
                    "📍 IP location is likely accurate",
                    "🛡️ Continue standard forensic monitoring",
                    "📊 Monitor for any VPN usage patterns"
                ])
            
            return {
                "status": "completed",
                "comprehensive_analysis": {
                    "target": target,
                    
                    # Basic Information
                    "geolocation": ip_data,
                    "threat_intelligence": threat_data,
                    "network_patterns": patterns,
                    
                    # Advanced VPN Analysis
                    "vpn_detection": {
                        **vpn_detection,
                        **vpn_detection  # Double check this line
                    },
                    "dns_analysis": dns_analysis,
                    "timezone_analysis": timezone_analysis,
                    
                    # Risk Assessment
                    "risk_factors": risk_factors,
                    "risk_score": risk_score,
                    "risk_level": risk_level,
                    "investigation_priority": investigation_priority,
                    
                    # Tracking Recommendations
                    "tracking_recommendations": tracking_recommendations,
                    "data_sources": "Multiple external forensic APIs + VPN detection",
                    "analysis_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                },
                "message": "Advanced forensic analysis with VPN detection completed"
            }
        except Exception as e:
            return {"status": "error", "message": f"Advanced analysis failed: {e}"}

    # ==================== COMPATIBILITY METHODS ====================
    
    def comprehensive_forensic_analysis(self, target):
        """Legacy method for compatibility"""
        return self.advanced_forensic_analysis(target)
        
    def ip_geolocation(self, ip_address):
        """Get REAL IP geolocation with actual data"""
        try:
            real_data = self.get_real_ip_data(ip_address)
            
            return {
                "status": "completed",
                "ip_info": real_data,
                "message": "Real IP geolocation data retrieved from external APIs"
            }
        except Exception as e:
            return {
                "status": "completed",
                "ip_info": {
                    "ip_address": ip_address,
                    "country": "Unknown",
                    "city": "Unknown", 
                    "region": "Unknown",
                    "isp": "Unknown",
                    "org": "Unknown"
                },
                "message": f"Geolocation failed: {str(e)}"
            }

    def threat_intelligence(self, ip_address):
        """Get REAL threat intelligence"""
        try:
            threat_data = self.get_threat_intelligence(ip_address)
            network_patterns = self.analyze_network_patterns(ip_address)
            
            return {
                "status": "completed",
                "threat_data": {
                    **threat_data,
                    **network_patterns,
                    "analysis_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                },
                "message": "Real threat intelligence analysis completed"
            }
        except Exception as e:
            return {"status": "error", "message": f"Threat analysis failed: {e}"}


# ==================== MAIN EXECUTION ====================

if __name__ == "__main__":
    print("🕵️‍♂️ ADVANCED GHOST TESTER - VPN DETECTION & FORENSIC ANALYSIS")
    print("==========================================================")
    print("⚠️  LEGAL DISCLAIMER: Use only for authorized penetration testing")
    print("   and ethical security research with proper consent!")
    print("==========================================================")
    
    tracker = AdvancedCyberForensicTracker()
    
    while True:
        print("\n🌐 Enter IP address to analyze (or 'quit' to exit):")
        user_ip = input("IP Address: ").strip()
        
        if user_ip.lower() == 'quit':
            break
            
        if not user_ip:
            print("❌ Please enter an IP address")
            continue
            
        print(f"\n🔍 Advanced Analysis: {user_ip}")
        print("=" * 60)
        
        # Optional: Get timezone for better analysis
        print("💡 Optional: Enter your timezone (e.g., Africa/Nairobi) or press Enter to skip:")
        user_timezone = input("Timezone: ").strip()
        if not user_timezone:
            user_timezone = None
        
        result = tracker.advanced_forensic_analysis(user_ip, user_timezone)
        analysis = result.get("comprehensive_analysis", {})
        
        if analysis.get("error"):
            print(f"❌ {analysis['error']}")
            print(f"💡 {analysis.get('valid_examples', '')}")
            continue
        
        # ==================== DISPLAY RESULTS ====================
        
        geo = analysis.get('geolocation', {})
        threat = analysis.get('threat_intelligence', {})
        network = analysis.get('network_patterns', {})
        vpn = analysis.get('vpn_detection', {})
        dns = analysis.get('dns_analysis', {})
        tz = analysis.get('timezone_analysis', {})
        
        print(f'📍 BASIC LOCATION:')
        print(f'   🌍 Country: {geo.get("country", "Unknown")}')
        print(f'   🏙️  City: {geo.get("city", "Unknown")}') 
        print(f'   📡 ISP: {geo.get("isp", "Unknown")}')
        print(f'   ⏰ Timezone: {geo.get("timezone", "Unknown")}')
        
        print(f'\n🛡️  THREAT INTELLIGENCE:')
        print(f'   🔴 Threat Level: {threat.get("threat_level", "Unknown")}')
        print(f'   ⭐ Reputation: {threat.get("reputation", "Unknown")}')
        print(f'   📊 Risk Score: {threat.get("risk_score", "Unknown")}')
        
        print(f'\n🔎 VPN/PROXY DETECTION:')
        print(f'   🛡️  VPN: {"✅ DETECTED" if vpn.get("vpn") else "❌ Not detected"}')
        print(f'   🔄 Proxy: {"✅ DETECTED" if vpn.get("proxy") else "❌ Not detected"}')
        print(f'   🧅 Tor: {"✅ DETECTED" if vpn.get("tor") else "❌ Not detected"}')
        print(f'   🏢 Service: {vpn.get("service", "Unknown")}')
        print(f'   📊 Confidence: {vpn.get("vpn_confidence", "Unknown")}')
        
        print(f'\n🌐 NETWORK ANALYSIS:')
        print(f'   📈 Activity: {network.get("activity_level", "Unknown")}')
        print(f'   🔌 Open Ports: {network.get("common_ports", "Unknown")}')
        print(f'   📡 DNS Leak Risk: {dns.get("leak_risk", "Unknown")}')
        print(f'   ⏰ Timezone Match: {"✅ OK" if not tz.get("mismatch_detected") else "❌ MISMATCH"}')
        
        print(f'\n🎯 RISK ASSESSMENT:')
        print(f'   📋 Risk Level: {analysis.get("risk_level", "Unknown")}')
        print(f'   🚨 Priority: {analysis.get("investigation_priority", "Unknown")}')
        print(f'   ⚠️  Factors: {", ".join(analysis.get("risk_factors", []))}')
        
        print(f'\n💡 TRACKING RECOMMENDATIONS:')
        for i, recommendation in enumerate(analysis.get("tracking_recommendations", []), 1):
            print(f'   {i}. {recommendation}')
        
        print(f'\n💬 MESSAGE: {result.get("message", "")}')
        print(f'🕒 Analysis Time: {analysis.get("analysis_timestamp", "")}')
        print("=" * 60)
