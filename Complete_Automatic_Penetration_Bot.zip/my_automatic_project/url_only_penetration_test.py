#!/usr/bin/env python3
"""
AUTONOMOUS PENETRATION TESTING BOT
Inafanya full penetration test kwa kutumia URL pekee
Bila kuhitaji credentials yoyote
"""

import requests
import threading
import time
import json
import re
import random
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from datetime import datetime

class AutonomousPentestBot:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
        })
        self.vulnerabilities_found = []
        self.discovered_urls = []
    
    def crawl_website(self, base_url):
        """Crawl website to discover all pages"""
        print("🕷️ Crawling website for discovery...")
        
        discovered_urls = [base_url]
        
        try:
            response = self.session.get(base_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all links
            for link in soup.find_all('a', href=True):
                href = link['href']
                full_url = urljoin(base_url, href)
                
                if base_url in full_url and full_url not in discovered_urls:
                    discovered_urls.append(full_url)
                    print(f"🔗 Discovered: {full_url}")
            
            # Find forms
            forms = soup.find_all('form')
            for form in forms:
                form_action = form.get('action', '')
                if form_action:
                    form_url = urljoin(base_url, form_action)
                    if form_url not in discovered_urls:
                        discovered_urls.append(form_url)
                        print(f"📝 Form found: {form_url}")
            
            return discovered_urls[:20]  # Limit to first 20 URLs
            
        except Exception as e:
            print(f"❌ Crawling error: {e}")
            return [base_url]
    
    def smart_sql_injection_scan(self, target_url):
        """Smart SQL Injection scanning"""
        print(f"🎯 Scanning {target_url} for SQL Injection...")
        
        sql_payloads = [
            "' OR '1'='1",
            "' OR 1=1--",
            "admin'--", 
            "' UNION SELECT 1,2,3--",
            "' AND SLEEP(5)--"
        ]
        
        # Extract parameters from URL
        parsed_url = urlparse(target_url)
        query_params = parsed_url.query.split('&') if parsed_url.query else []
        
        vulnerabilities = []
        
        for param in query_params:
            if '=' in param:
                param_name = param.split('=')[0]
                
                for payload in sql_payloads:
                    test_url = target_url.replace(
                        f"{param_name}={param.split('=')[1]}", 
                        f"{param_name}={payload}"
                    )
                    
                    try:
                        start_time = time.time()
                        response = self.session.get(test_url, timeout=10)
                        response_time = time.time() - start_time
                        
                        # Detection logic
                        if response_time > 5 or any(error in response.text.lower() for error in ['sql', 'mysql', 'database', 'syntax']):
                            vulnerabilities.append({
                                'url': test_url,
                                'parameter': param_name,
                                'payload': payload,
                                'type': 'SQL Injection',
                                'confidence': 'High' if response_time > 5 else 'Medium'
                            })
                            print(f"✅ SQLi Found: {param_name} in {target_url}")
                            break
                            
                    except:
                        continue
        
        return vulnerabilities
    
    def smart_xss_scan(self, target_url):
        """Smart XSS scanning"""
        print(f"🎯 Scanning {target_url} for XSS...")
        
        xss_payloads = [
            '<script>alert("XSS")</script>',
            '<img src=x onerror=alert("XSS")>',
            '" onmouseover="alert(1)'
        ]
        
        parsed_url = urlparse(target_url)
        query_params = parsed_url.query.split('&') if parsed_url.query else []
        
        vulnerabilities = []
        
        for param in query_params:
            if '=' in param:
                param_name = param.split('=')[0]
                
                for payload in xss_payloads:
                    test_url = target_url.replace(
                        f"{param_name}={param.split('=')[1]}",
                        f"{param_name}={payload}"
                    )
                    
                    try:
                        response = self.session.get(test_url, timeout=10)
                        
                        if payload in response.text:
                            vulnerabilities.append({
                                'url': test_url,
                                'parameter': param_name,
                                'payload': payload,
                                'type': 'Cross-Site Scripting (XSS)',
                                'confidence': 'High'
                            })
                            print(f"✅ XSS Found: {param_name} in {target_url}")
                            break
                            
                    except:
                        continue
        
        return vulnerabilities
    
    def directory_bruteforce(self, base_url):
        """Directory and file bruteforce"""
        print("📁 Bruteforcing directories and files...")
        
        common_paths = [
            'admin', 'administrator', 'login', 'dashboard', 'wp-admin',
            'phpmyadmin', 'config', 'backup', 'uploads', 'images',
            'css', 'js', 'api', 'test', 'dev', 'admin.php',
            'login.php', 'config.php', '.git', '.env', 'robots.txt'
        ]
        
        discovered_paths = []
        
        def check_path(path):
            try:
                test_url = urljoin(base_url, path)
                response = self.session.get(test_url, timeout=5)
                
                if response.status_code == 200:
                    discovered_paths.append({
                        'url': test_url,
                        'status': response.status_code,
                        'type': 'Directory/File'
                    })
                    print(f"✅ Found: {test_url}")
                    
            except:
                pass
        
        threads = []
        for path in common_paths:
            # Try different variations
            variations = [path, f"/{path}", f"{path}/", f"/{path}/"]
            
            for variation in variations:
                thread = threading.Thread(target=check_path, args=(variation,))
                threads.append(thread)
                thread.start()
                
                if len(threads) >= 10:
                    for t in threads:
                        t.join()
                    threads = []
                
                time.sleep(0.1)
        
        for t in threads:
            t.join()
        
        return discovered_paths
    
    def security_headers_scan(self, target_url):
        """Scan security headers"""
        print("🛡️ Checking security headers...")
        
        try:
            response = self.session.get(target_url, timeout=10)
            headers = response.headers
            
            security_issues = []
            required_headers = [
                'Content-Security-Policy',
                'X-Frame-Options',
                'X-Content-Type-Options', 
                'Strict-Transport-Security',
                'X-XSS-Protection'
            ]
            
            for header in required_headers:
                if header not in headers:
                    security_issues.append({
                        'issue': f'Missing {header}',
                        'type': 'Security Headers',
                        'severity': 'Medium'
                    })
            
            # Check for information disclosure
            if 'Server' in headers:
                security_issues.append({
                    'issue': f'Server information exposed: {headers["Server"]}',
                    'type': 'Information Disclosure',
                    'severity': 'Low'
                })
            
            return security_issues
            
        except Exception as e:
            return [{'issue': f'Header scan failed: {e}', 'type': 'Error', 'severity': 'Info'}]
    
    def form_analysis(self, target_url):
        """Analyze forms for vulnerabilities"""
        print(f"📝 Analyzing forms on {target_url}...")
        
        try:
            response = self.session.get(target_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            forms = soup.find_all('form')
            
            form_vulnerabilities = []
            
            for form in forms:
                form_info = {
                    'action': form.get('action', ''),
                    'method': form.get('method', 'get').lower(),
                    'has_csrf': False,
                    'inputs': []
                }
                
                # Check for CSRF protection
                for inp in form.find_all('input'):
                    input_name = inp.get('name', '')
                    if any(token in input_name.lower() for token in ['csrf', 'token', '_token']):
                        form_info['has_csrf'] = True
                    
                    form_info['inputs'].append({
                        'name': input_name,
                        'type': inp.get('type', 'text')
                    })
                
                # Identify vulnerabilities
                if not form_info['has_csrf'] and form_info['method'] == 'post':
                    form_vulnerabilities.append({
                        'url': urljoin(target_url, form_info['action']),
                        'issue': 'Missing CSRF Protection',
                        'type': 'CSRF Vulnerability',
                        'severity': 'Medium'
                    })
                    print(f"✅ CSRF Issue: {form_info['action']}")
            
            return form_vulnerabilities
            
        except Exception as e:
            return []
    
    def port_scan_simple(self, target_url):
        """Simple port scanning"""
        print("🔍 Scanning common ports...")
        
        try:
            hostname = urlparse(target_url).hostname
            common_ports = [21, 22, 23, 25, 53, 80, 443, 3306, 3389]
            
            open_ports = []
            
            def check_port(port):
                try:
                    import socket
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(2)
                    result = sock.connect_ex((hostname, port))
                    sock.close()
                    
                    if result == 0:
                        open_ports.append(port)
                        print(f"✅ Port {port} open")
                except:
                    pass
            
            threads = []
            for port in common_ports:
                thread = threading.Thread(target=check_port, args=(port,))
                threads.append(thread)
                thread.start()
                
                if len(threads) >= 5:
                    for t in threads:
                        t.join()
                    threads = []
            
            for t in threads:
                t.join()
            
            return [{'ports': open_ports, 'type': 'Open Ports', 'severity': 'Info'}]
            
        except Exception as e:
            return [{'issue': f'Port scan failed: {e}', 'type': 'Error', 'severity': 'Info'}]
    
    def autonomous_pentest(self, target_url):
        """Run complete autonomous penetration test"""
        print(f"🚀 STARTING AUTONOMOUS PENETRATION TEST")
        print(f"🎯 TARGET: {target_url}")
        print("=" * 60)
        
        start_time = time.time()
        
        # Phase 1: Discovery
        print("\n📋 PHASE 1: DISCOVERY")
        print("-" * 30)
        
        discovered_urls = self.crawl_website(target_url)
        print(f"📊 Discovered {len(discovered_urls)} URLs")
        
        # Phase 2: Vulnerability Scanning
        print("\n📋 PHASE 2: VULNERABILITY SCANNING")
        print("-" * 30)
        
        all_vulnerabilities = []
        
        # Scan each discovered URL
        for url in discovered_urls:
            print(f"\n🔍 Scanning: {url}")
            
            # SQL Injection scan
            sql_vulns = self.smart_sql_injection_scan(url)
            all_vulnerabilities.extend(sql_vulns)
            
            # XSS scan
            xss_vulns = self.smart_xss_scan(url)
            all_vulnerabilities.extend(xss_vulns)
            
            # Form analysis
            form_vulns = self.form_analysis(url)
            all_vulnerabilities.extend(form_vulns)
            
            time.sleep(1)  # Be polite
        
        # Phase 3: Additional Scans
        print("\n📋 PHASE 3: ADDITIONAL SCANS")
        print("-" * 30)
        
        # Directory bruteforce
        directory_finds = self.directory_bruteforce(target_url)
        all_vulnerabilities.extend(directory_finds)
        
        # Security headers
        header_issues = self.security_headers_scan(target_url)
        all_vulnerabilities.extend(header_issues)
        
        # Port scan
        port_info = self.port_scan_simple(target_url)
        all_vulnerabilities.extend(port_info)
        
        # Phase 4: Reporting
        print("\n📋 PHASE 4: REPORT GENERATION")
        print("-" * 30)
        
        end_time = time.time()
        scan_duration = end_time - start_time
        
        # Generate report
        report = {
            'target_url': target_url,
            'scan_date': datetime.now().isoformat(),
            'scan_duration': f"{scan_duration:.2f} seconds",
            'urls_discovered': len(discovered_urls),
            'vulnerabilities_found': len(all_vulnerabilities),
            'vulnerabilities': all_vulnerabilities,
            'security_score': self.calculate_security_score(all_vulnerabilities),
            'risk_level': self.assess_risk_level(all_vulnerabilities)
        }
        
        # Save report
        filename = f"autonomous_pentest_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"💾 Report saved: {filename}")
        
        # Display summary
        self.display_summary(report)
        
        return report
    
    def calculate_security_score(self, vulnerabilities):
        """Calculate security score based on vulnerabilities"""
        high_severity = sum(1 for v in vulnerabilities if v.get('severity') == 'High')
        medium_severity = sum(1 for v in vulnerabilities if v.get('severity') == 'Medium')
        
        score = 100 - (high_severity * 20 + medium_severity * 10)
        return max(0, score)
    
    def assess_risk_level(self, vulnerabilities):
        """Assess overall risk level"""
        high_count = sum(1 for v in vulnerabilities if v.get('severity') == 'High')
        medium_count = sum(1 for v in vulnerabilities if v.get('severity') == 'Medium')
        
        if high_count > 0:
            return "HIGH"
        elif medium_count > 2:
            return "MEDIUM" 
        elif medium_count > 0:
            return "LOW"
        else:
            return "VERY LOW"
    
    def display_summary(self, report):
        """Display scan summary"""
        print("\n" + "=" * 60)
        print("📊 AUTONOMOUS PENETRATION TEST SUMMARY")
        print("=" * 60)
        print(f"🎯 Target: {report['target_url']}")
        print(f"📅 Scan Date: {report['scan_date']}")
        print(f"⏱️ Duration: {report['scan_duration']}")
        print(f"🔗 URLs Discovered: {report['urls_discovered']}")
        print(f"⚠️ Vulnerabilities Found: {report['vulnerabilities_found']}")
        print(f"🏆 Security Score: {report['security_score']}/100")
        print(f"🚨 Risk Level: {report['risk_level']}")
        
        # Show vulnerability breakdown
        if report['vulnerabilities']:
            print(f"\n🔍 VULNERABILITY BREAKDOWN:")
            vuln_types = {}
            for vuln in report['vulnerabilities']:
                vuln_type = vuln.get('type', 'Unknown')
                vuln_types[vuln_type] = vuln_types.get(vuln_type, 0) + 1
            
            for vuln_type, count in vuln_types.items():
                print(f"   • {vuln_type}: {count}")
        
        print(f"\n💡 RECOMMENDATIONS:")
        if report['security_score'] < 70:
            print("   🚨 Immediate security improvements needed!")
        elif report['security_score'] < 85:
            print("   ⚠️ Security enhancements recommended")
        else:
            print("   ✅ Good security posture maintained")
        
        print("   • Review and fix identified vulnerabilities")
        print("   • Implement missing security headers")
        print("   • Regular security testing recommended")

def main():
    print("🚀 AUTONOMOUS PENETRATION TESTING BOT")
    print("=" * 60)
    print("Fully autonomous security testing - No credentials needed!")
    print("=" * 60)
    
    # Get target URL from user
    target_url = input("🌐 Enter target URL (e.g., http://example.com): ").strip()
    
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'http://' + target_url
    
    # Create bot and run test
    bot = AutonomousPentestBot()
    
    try:
        print(f"\n🎯 Starting autonomous penetration test on: {target_url}")
        print("⏳ This may take a few minutes...")
        
        report = bot.autonomous_pentest(target_url)
        
        print("\n🎉 AUTONOMOUS PENETRATION TEST COMPLETED!")
        print("🔧 No credentials required - Pure URL-based testing!")
        
    except KeyboardInterrupt:
        print("\n⏹️ Scan stopped by user")
    except Exception as e:
        print(f"💥 Scan failed: {e}")

if __name__ == "__main__":
    main()
