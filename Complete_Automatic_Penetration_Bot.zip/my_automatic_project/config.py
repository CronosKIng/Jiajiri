import os
from dotenv import load_dotenv

load_dotenv()

# Demo sites URLs
DEMO_SITES = {
    "sauce_demo": "https://www.saucedemo.com/",
    "orangehrm": "https://opensource-demo.orangehrmlive.com/",
    "practice_site": "https://example.com"
}

# Demo credentials (HII NI DATA YA DEMO TU!)
DEMO_CREDENTIALS = {
    "sauce_demo": {
        "username": "standard_user",
        "password": "secret_sauce"
    },
    "orangehrm": {
        "username": "Admin",
        "password": "admin123"
    }
}
